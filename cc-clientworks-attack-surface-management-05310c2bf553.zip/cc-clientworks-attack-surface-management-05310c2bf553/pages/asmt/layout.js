import React, { useState, useEffect } from "react";
import {
  signInWithEmail,
  handleSignOut,
  getUserSession,
  Cookie,
  supabase,
  listFactors,
  CookieContext,
} from "../../services/index";
import "../../src/app/globals.css";
import SimpleBackdrop from "../../components/loader";
import ASMTComponent from "../../components/ASMTComponent";
import { useRouter } from "next/navigation";
import { useContext } from "react";
import Modal from "@mui/material/Modal";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import { Typography } from "@mui/material";
const Message = (props) => {
  return <p className="color-red">{props.message}</p>;
};
const VerifyMFAComponent = (props) => {
  const { loader, open, handleClose } = props;
  const [error, setError] = React.useState(false);
  const [verifyCode, setVerifyCode] = useState("");
  // const { login, setLogin } = useContext(CookieContext);

  // const [error, setError] = useState("");
  const { push } = useRouter();

  const onSubmitClicked = async () => {
    try {
      const { data, error } = await supabase.auth.mfa.listFactors();
      const factor = data;
      console.log(factor, "fct");
      if (factor.totp[0] != null) {
        const { data, error } = await supabase.auth.mfa.challengeAndVerify({
          factorId: factor.totp[0].id,
          code: verifyCode,
        });
        if (!error) {
          location.reload();
        } else {
          throw error;
        }
      }
    } catch (err) {
      setError(true);
      console.log(err, "mf");
    }
  };

  useEffect(() => {}, []);

  return (
    <Modal
      open={props.open}
      onClose={props.handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        item
        xs={4}
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50% ,-50% )",
          width: "400px",
          height: "300px",
          display: "flex",
          gap: 2,
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          border: 1,
          borderColor: "white",
          borderRadius: 5,
        }}
      >
        <Typography variant="body1" sx={{ fontSize: "18", color: "white" }}>
          Welcome
        </Typography>
        <input
          type="text"
          onChange={(e) => setVerifyCode(e.target.value.trim())}
        />
        <Button onClick={onSubmitClicked}>Submit</Button>
        {error ? <Message message="Code invalid .Try again." /> : ""}
      </Box>
    </Modal>
  );
};

const Layout = () => {
  const { push } = useRouter();
  const [modal, setModal] = React.useState(false);
  const [loader, setLoader] = React.useState(true);
  const [login, setLogin] = React.useState(false);

  // const { login, setLogin } = useContext(CookieContext);
  const handleClose = async () => {
    setLoader(true);
    // await supabase.auth.signOut();
    handleSignOut();
    push("/login");
  };

  useEffect(() => {
    async function MFAState() {
      try {
        const { data, error } =
          await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
        if (error) throw error;
        const { currentLevel, nextLevel, currentAuthenticationMethods } = data;
        console.log(
          currentAuthenticationMethods,
          currentLevel,
          nextLevel,
          "currentAuthenticationMethods"
        );
        if ((currentLevel === "aal1") & (nextLevel === "aal2")) setModal(true);
        else if (currentLevel === "aal2") {
          setLogin(true);
        } else {
          // handleSignOut();
          push("/register/subscribe");
        }
      } catch (error) {
        console.log(error, "aale");
        setModal(false);
      }
    }
    MFAState();
  }, []);

  return (
    <>
      {loader && <SimpleBackdrop />}
      {modal && <VerifyMFAComponent open={modal} handleClose={handleClose} />}
      {login && <ASMTComponent loader={setLoader}></ASMTComponent>}
    </>
  );
};

export default Layout;
