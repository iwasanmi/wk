import React from "react";
import MyApp from "../_app";
import { registerLicense } from "@syncfusion/ej2-base";

// Registering Syncfusion license key
registerLicense(
  "Ngo9BigBOggjHTQxAR8/V1NHaF5cWWBCf1FpRmJGdld5fUVHYVZUTXxaS00DNHVRdkdgWH5edXVXR2heUUZ+WEc="
);

export default function Asmt() {
  return <MyApp></MyApp>;
}
