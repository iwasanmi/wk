export const connectClient = async () => {
  let site = `https://65.0.101.118`;
  let url = `${site}/api/loginAt/`;
  let response = await fetch(url, {
    method: "post",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ username: "admin", password: "1234" }),
  });
  let token = response.headers;
  console.log(token, "csrf");
};
