const express = require("express");
// import { connectClient } from "./rengineClient";
var bodyParser = require("body-parser");
const app = express();
var cors = require("cors");
var request = require("request");
const PORT = 3001;
process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
let site = `https://65.0.94.51`;
// let site = `http://localhost:8000`;
let session = {};
const stripe = require("stripe")(
  "sk_test_51NrW2uSE6gO0eGi59a2sCVTCfjKXWSUZaY0dYwzPfqhW6zxh51vJXFgYTaVMMt6mROixs8G0qKCMAJmiOUbKXKmb00FSoK9Gly"
);

// , {
//   method: "get",
//   mode: "cors",
//   "Access-Control-Expose-Headers": "true",
//   "Access-Control-Allow-Origin": "*",
//   // "Access-Control-Allow-Credentials": "true",
//   "Access-Control-Allow-Methods": "GET,HEAD,OPTIONS,POST,PUT",
//   "Access-Control-Allow-Headers":
//     "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With,X-CSRFToken,Cookie, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers",
// }

const connectClient = async () => {
  let token;
  let cookie;
  let expire;
  let url = `${site}/api/loginAt`;
  try {
    let response = await fetch(url, {
      method: "post",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username: "a", password: "1" }),
    });
    token = response.headers.getSetCookie()[1].split(";")[0].split("=")[1];
    expire = response.headers.getSetCookie()[1].split(";")[1].split("=")[1];
    cookie = response.headers.getSetCookie();
    console.log(cookie, "csrf");
  } catch (error) {
    token = null;
    console.log(error, "ert");
  }
  return { token, cookie };
};

const corsOptions = {
  origin: "*",
  credentials: true, //access-control-allow-credentials:true
  optionSuccessStatus: 200,
};
app.use(cors(corsOptions));
app.use(express.json());

app.post("/", (req, res) => {
  const { name } = req.body;

  res.status(200).send(`Welcome ${name}`);
});

app.get("/site", async (req, res) => {
  res.status(200).send({ site: site });
});

app.get("/token", async (req, res) => {
  let setcookie = ``;
  const { token, cookie } = await connectClient();
  // var endPoint = `${site}/api/listTargets/?orgId=2`;
  for (var i in cookie) {
    setcookie = setcookie.concat(cookie[i].split(";")[0], ";");
  }
  let headers = {
    Cookie: setcookie,
    "X-CSRFToken": token,
  };
  session[token] = headers;
  // let response = await fetch(endPoint, {
  //   method: "get",
  //   headers: {
  //     Cookie: setcookie,
  //     "X-CSRFToken": token,
  //   },
  // });
  // response = await response.json();
  // res.header("cookie", setcookie);
  // res.header("X-CSRFToken", token);
  res.status(200).send({ auth: token });
});

app.post("/v2", async (req, res) => {
  const data = req.body;
  const apiId = data.apiId;
  const params = data.params;
  const method = data.method;
  console.log(data, params, "idap");
  const headers = session[data.token];
  console.log(session, "dsds");
  let url = `${site}${apiId}`;
  let obj = {};
  obj.method = method;
  obj.headers = {
    Accept: "application/json",
    "Content-Type": "application/json",
    ...headers,
  };
  if (params) {
    obj.body = JSON.stringify(params);
  }
  let response = await fetch(url, obj);
  response = await response.json();
  console.log(response, "v2");
  res.status(200).send(response);
});

app.post("/v1", async (req, res) => {
  const data = req.body;
  const apiId = data.apiId;
  const params = data.params;
  const orgId = data.rengine_org_id;
  console.log(data, params, "idap");
  const headers = session[data.token];
  console.log(session, "dsds");
  let context = {};
  context.status = false;
  let url;
  try {
    if (apiId == "listTargets") {
      // let response = await fetch(`${site}/api/listTargets/?slug=default`, {
      let response = await fetch(`${site}/api/listTargets/?slug=${orgId}`, {
        method: "get",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          ...headers,
        },
      });

      response = await response.json();
      // console.log(response, "listTargets");
      context.results = response.results;
      context.status = true;
      res.status(200).send(response);
    } else if (apiId == "addOrg") {
      let response = await fetch(`${site}/api/add/organization`, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          ...headers,
        },
        body: JSON.stringify(params),
      });
      response = await response.json();
      // console.log(response, "addOrg");
      res.status(200).send(response);
    } else if (apiId == "addPro") {
      let response = await fetch(
        `${site}/api/action/create/project?name=${params.name}`,
        {
          method: "get",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            ...headers,
          },
        }
      );
      response = await response.json();
      // console.log(response, "addOrg");
      res.status(200).send(response);
    } else if (apiId == "addTargets") {
      let response = await fetch(`${site}/api/add/target/multiple`, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          ...headers,
        },
        body: JSON.stringify(params),
      });
      response = await response.json();
      // console.log(response, "addTarget");
      res.status(200).send(response);
    } else if (apiId == "scanApi") {
      let response = await fetch(`${site}/api/schedule_start_scan`, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          ...headers,
        },
        body: JSON.stringify(params),
      });
      response = await response.json();
      // console.log(response, "scanApi");
      res.status(200).send(response);
    } else if (apiId == "getScans") {
      let response = await fetch(`${site}/api/get/scans?slug=${orgId}`, {
        method: "get",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          ...headers,
        },
        body: JSON.stringify(params),
      });
      response = await response.json();
      // console.log(response, "scanApi");
      res.status(200).send(response);
    } else if (apiId == "deleteTargets") {
      let response = await fetch(`${site}/api/delete/target/multiple`, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          ...headers,
        },
        body: JSON.stringify(params),
      });
      response = await response.json();
      // console.log(response, "deleteTargets");
      res.status(200).send(response);
    } else if (apiId == "Notification") {
      console.log("nt");
      if (data.get) {
        console.log("get");
        let response = await fetch(
          `${site}/api/notification?project=${orgId}`,
          {
            method: "get",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              ...headers,
            },
          }
        );
        response = await response.json();
        // console.log(response, "getNo");
        res.status(200).send(response);
      }
      if (data.post) {
        console.log("post");
        let response = await fetch(
          `${site}/api/notification?project=${orgId}`,
          {
            method: "post",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              ...headers,
            },
            body: JSON.stringify(params),
          }
        );
        response = await response.json();
        // console.log(response, "postNo");
        res.status(200).send(response);
      }
    } else if (apiId == "Settings") {
      console.log("nt");
      if (data.get) {
        console.log("get");
        let response = await fetch(`${site}/api/settings?project=${orgId}`, {
          method: "get",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            ...headers,
          },
        });
        response = await response.json();
        // console.log(response, "getNo");
        res.status(200).send(response);
      }
      if (data.post) {
        console.log("post");
        let response = await fetch(`${site}/api/settings?project=${orgId}`, {
          method: "post",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            ...headers,
          },
          body: JSON.stringify(params),
        });
        response = await response.json();
        // console.log(response, "postNo");
        res.status(200).send(response);
      }
    } else if (apiId == "Dashboard") {
      let response = await fetch(`${site}/api/dashboard`, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          ...headers,
        },
        body: JSON.stringify(params),
      });
      response = await response.json();
      // console.log(response, "addTarget");
      res.status(200).send(response);
    }
  } catch (error) {
    context.desc = error;
    res.status(200).send(context);
  }
});

app.get("/v1/billing/", async (req, res) => {
  // const data = req.body;
  try {
    const customer = req.query.customer;

    const subscriptions = await stripe.subscriptions.list({
      customer: customer,
    });
    const customerDetails = await stripe.customers.retrieve(customer);
    const paymentMethods = await stripe.customers.listPaymentMethods(customer);
    res.status(200).json({ subscriptions, customerDetails, paymentMethods });
  } catch (error) {
    res.status(500).send({ error: error });
  }
});

app.get("/trial", async (req, res) => {
  const product = await stripe.products.retrieve("prod_OiFsNG8UEznU82");
  const prices = await stripe.prices.list({
    limit: 3,
    product: "prod_OiFsNG8UEznU82",
  });

  const customer = await stripe.customers.retrieve("cus_PBMrSv2iNQxHAT");
  const customercreate = await stripe.customers.create();
  res.status(200).send({ body: { product, prices, customer, customercreate } });
  // console.log(req.body, "atr");
});

app.post("/addOrg", async (req, res) => {
  console.log(req.body, "aor");
  try {
    let obj = {
      name: data?.name,
      desc: data?.desc,
    };
    let response = await fetch(`${site}/api/add/organization/`, {
      method: "post",
      // mode: "no-cors",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(obj),
    });
    let body = await response.json();
    console.log(body, "org");
    res.status(200).json(body);
  } catch (error) {
    res.status(500).send({ error: error });
  }
});

app.post("/v1/updateCustomer/", async (req, res) => {
  try {
    let customer = req.body;
    const story = await stripe.customers.update(customer.id, customer.point);
    res.status(200).json(story);
  } catch (error) {
    res.status(500).send({ error: error });
  }
});

app.post("/v1/removeMethod/", async (req, res) => {
  try {
    let method = req.body.method;
    const paymentMethod = await stripe.paymentMethods.detach(method);
    res.status(200).json(paymentMethod);
  } catch (error) {
    res.status(500).send({ error: error });
  }
});

app.post("/v1/cancelSubscription/", async (req, res) => {
  try {
    let subscription = req.body.id;
    let status = req.body.status;
    let deleted;
    console.log(req.body, "cns");
    if (status == "active") {
      deleted = await stripe.subscriptions.update(subscription, {
        cancel_at_period_end: true,
      });
    }
    if (status == "incomplete") {
      deleted = await stripe.subscriptions.cancel(subscription);
    }
    res.status(200).json(deleted);
  } catch (error) {
    res.status(500).send({ error: error });
  }
});

app.post("/v1/continuePaying/", async (req, res) => {
  try {
    let customer = req.body.customer;
    let addSubscription = req.body.addSubscription;
    console.log(customer, addSubscription, "sdss");
    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [
        {
          price: addSubscription.price,
        },
      ],
      payment_behavior: "default_incomplete",
      payment_settings: { save_default_payment_method: "on_subscription" },
      expand: ["latest_invoice.payment_intent"],
    });
    console.log(subscription, "sdss");
    const updateSubscription = await stripe.subscriptions.update(
      subscription.id,
      {
        metadata: {
          clientSecret:
            subscription.latest_invoice.payment_intent.client_secret,
        },
      }
    );
    console.log(updateSubscription, "ftdfgxfd");
    res.status(200).json(updateSubscription);
  } catch (error) {
    res.status(500).send({ error: error });
  }
});

app.post("/v1/continueDefaultPaying/", async (req, res) => {
  try {
    console.log(req.body, "continueDefaultPaying");
    let customer = req.body.customer;
    let addSubscription = req.body.addSubscription;
    let default_payment_method = req.body.default_payment_method;
    const subscription = await stripe.subscriptions.create({
      customer: customer,
      items: [{ price: addSubscription }],
      default_payment_method: default_payment_method,
    });
    const invoice = await stripe.invoices.pay(subscription.latest_invoice);
    res.status(200).json({ subscription, invoice });
  } catch (error) {
    res.status(500).send({ error: error });
  }
});

app.post("/customer/create", async (req, res) => {
  console.log(req.body, "sub");
  try {
    const customer = await stripe.customers.create({
      email: req.body.owner.email,
      name: req.body.owner.name,
      address: req.body.owner.address,
    });
    console.log(customer, "customer");
    res.status(200).json({ customer });
  } catch (error) {
    console.log(error, "ccr");
  }
});

app.post("/subscribe", async (req, res) => {
  console.log(req.body, "sub");
  try {
    const customer = await stripe.customers.create({
      email: req.body.owner.email,
      name: req.body.owner.name,
      address: req.body.initaddress,
    });
    try {
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [
          {
            price: req.body.initpackage,
          },
        ],
        payment_behavior: "default_incomplete",
        payment_settings: { save_default_payment_method: "on_subscription" },
        expand: ["latest_invoice.payment_intent"],
      });
      const updateSubscription = await stripe.subscriptions.update(
        subscription.id,
        {
          metadata: {
            clientSecret:
              subscription.latest_invoice.payment_intent.client_secret,
          },
        }
      );
      res.status(200).json({
        clientSecret: subscription.latest_invoice.payment_intent.client_secret,
        subscriptionId: subscription.id,
        customerId: customer.id,
      });
    } catch (error) {
      throw error;
    }
  } catch (error) {
    res.status(200).send({ error: error });
  }
});

app.listen(PORT, (error) => {
  if (!error)
    console.log(
      "Server is Successfully Running, and App is listening on port " + PORT
    );
  else console.log("Error occurred, server can't start", error);
});
