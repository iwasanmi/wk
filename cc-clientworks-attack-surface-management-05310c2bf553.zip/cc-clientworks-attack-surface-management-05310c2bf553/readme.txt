Run rengine using following git repo: https://github.com/rohitg459/rengine_master.git
Create admin username and password in rengine
Go to /server folder . Open app.js file
Update line 9 and line 38.
Run [node app.js] command in current directory
Go to root folder and run [npm run dev] command
Go to localhost:3000 in the browser.
