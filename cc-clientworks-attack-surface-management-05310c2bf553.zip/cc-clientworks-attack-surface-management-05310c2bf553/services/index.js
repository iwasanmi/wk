import { createClient } from "@supabase/supabase-js";
import { createPagesServerClient } from "@supabase/auth-helpers-nextjs";

// Create a single supabase client for interacting with your database
export const supabase = createClient(
  "https://utaebcjpxszdgkrdxaml.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV0YWViY2pweHN6ZGdrcmR4YW1sIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTUyMTk3MjIsImV4cCI6MjAxMDc5NTcyMn0.6BhaJOrdm6JPpSRDTRyCQW7EMLqUXxfgVR4AGyPBjwU"
);
import { createContext, useContext, useState, useEffect } from "react";
import React from "react";

// import { setCookie, supabase } from "../services/index";

export const getUserSession = async () => {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const {
    data: { session },
    error,
  } = await supabase.auth.getSession();
  console.log(session, user, "mess");
  const profileInfo = undefined;
  if (user) {
    const { data: profileInfo, error: profileError } = await supabase
      .from("Profile")
      .select()
      .eq("user_id", user.id);
    console.log(profileInfo, user.id, "profile");
  }
  return { session, user, profileInfo };
};
import { useRouter } from "next/navigation";

export const CookieContext = createContext(null);
export function Cookie({ children }) {
  const { push } = useRouter();
  const [login, setLogin] = useState(false);
  // const [logout, setLogout] = useState(true);
  let state = undefined;
  supabase.auth.onAuthStateChange((event, sbSession) => {
    state = event;
    if (event === "SIGNED_OUT" || event === "USER_DELETED") {
      // delete cookies on sign out
      console.log("a");
      const expires = new Date(0).toUTCString();
      localStorage.removeItem("X-CSRFToken");
      document.cookie = `my-access-token=; path=/; expires=${expires}; SameSite=Lax; secure`;
      document.cookie = `my-refresh-token=; path=/; expires=${expires}; SameSite=Lax; secure`;
    } else if (event === "SIGNED_IN" || event === "TOKEN_REFRESHED") {
      const maxAge = 100 * 365 * 24 * 60 * 60; // 100 years, never expires
      console.log("b");
      document.cookie = `my-access-token=${sbSession.access_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
      document.cookie = `my-refresh-token=${sbSession.refresh_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
    }
  });
  useEffect(() => {
    // async function loginRedirect() {
    //   const { session, user, profileInfo } = await getUserSession();
    //   if (!session) push("/login");
    // }
    // loginRedirect();
  }, []);

  return (
    <CookieContext.Provider value={{ login, setLogin }}>
      {children}
    </CookieContext.Provider>
  );
}

export const register_user = async (formData) => {
  try {
    const res = await fetch("http://localhost:3000/api/Auth/register", {
      headers: {
        "Content-Type": "application/json",
      },
      method: "POST",
      body: JSON.stringify(formData),
    });
    const data = res.json();
    return data;
  } catch (error) {
    console.log("Error in register_user (service) => ", error);
    return error.message;
  }
};

export const getUser = async () => {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const {
    data: { session },
    error,
  } = await supabase.auth.getSession();

  console.log(session, user, "mess");
  return { user, session, error };
};

export const verifyMFA = (factorId, verifyCode) => {
  return async () => {
    const challenge = await supabase.auth.mfa.challenge({ factorId });
    if (challenge.error) {
      throw challenge.error;
    }

    const challengeId = challenge.data.id;

    const verify = await supabase.auth.mfa.verify({
      factorId,
      challengeId,
      code: verifyCode,
    });
    if (verify.error) {
      throw verify.error;
    }
  };
};

export const listFactors = async () => {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const { data, error } = await supabase.auth.mfa.listFactors();
  // console.log(data, error, "fct");
  return { data, error };
};

export const enrollMFA = async () => {
  console.log("enrollMFA");
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (user) {
    const { data, error } = await supabase.auth.mfa.enroll({
      factorType: "totp",
    });
    return { user, data, error };
    return { data, error };
  } else throw Error("User not found");
};

export const signInWithEmail = async (formData) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword(formData);
    console.log(data, "data");
    if (error) return false;

    // const { session, user, profileInfo } = await getUserSession();
    // const maxAge = 100 * 365 * 24 * 60 * 60; // 100 years, never expires
    // console.log("b");
    // document.cookie = `my-access-token=${session.access_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
    // document.cookie = `my-refresh-token=${session.refresh_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
    return true;
  } catch (error) {
    console.log("Error in login_user (service) => ", error);
    return false;
  }
};

export async function magicSignUp() {
  const { data, error } = await supabase.auth.signInWithOtp({
    email: "rohitgurkhe0@gmail.com",
    options: {
      emailRedirectTo: "http://localhost:3000/asmt",
    },
  });
  if (error) {
    console.log(error, "mg");
    throw error;
  }
}

export const handleSignOut = async () => {
  await supabase.auth.signOut();
  const expires = new Date(0).toUTCString();
  localStorage.removeItem("X-CSRFToken");
  document.cookie = `my-access-token=; path=/; expires=${expires}; SameSite=Lax; secure`;
  document.cookie = `my-refresh-token=; path=/; expires=${expires}; SameSite=Lax; secure`;
  console.log("lo");
};
