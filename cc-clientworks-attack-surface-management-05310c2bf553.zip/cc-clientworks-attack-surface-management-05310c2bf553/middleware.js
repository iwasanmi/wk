import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
// Create a single supabase client for interacting with your database
const supabase = createClient(
  "https://utaebcjpxszdgkrdxaml.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV0YWViY2pweHN6ZGdrcmR4YW1sIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTUyMTk3MjIsImV4cCI6MjAxMDc5NTcyMn0.6BhaJOrdm6JPpSRDTRyCQW7EMLqUXxfgVR4AGyPBjwU"
  // options
);
// This function can be marked `async` if using `await` inside
export async function middleware(request) {
  const {
    nextUrl: { search },
  } = request;
  const urlSearchParams = new URLSearchParams(search);
  const params = Object.fromEntries(urlSearchParams.entries());

  const allCookies = request.cookies.getAll();
  // console.log(request.url, params, "sds", "cookies"); // => [{ name: 'nextjs', value: 'fast' }]

  let obj = allCookies.find((o) => o.name === "my-access-token");

  console.log(obj?.value, "my-access-token");

  const {
    data: { user },
  } = await supabase.auth.getUser(obj?.value);
  // const { data, error } = await supabase.auth.getUser(obj?.value);
  console.log(user, "xyz");
  if (user) {
    console.log("userFound");
    if (request.nextUrl.pathname.startsWith("/login")) {
      return NextResponse.redirect(new URL("/asmt", request.url));
    }
    return NextResponse.next();
  } else {
    if (request.nextUrl.pathname.startsWith("/login")) {
      return NextResponse.next();
    }
    if (request.nextUrl.pathname.startsWith("/asmt")) {
      return NextResponse.redirect(new URL("/login", request.url));
    }
  }
  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: ["/asmt/:path*", "/login/:path*", "/register/subscribe/:path*"],
};
