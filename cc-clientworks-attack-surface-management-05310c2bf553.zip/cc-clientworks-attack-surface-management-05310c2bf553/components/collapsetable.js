import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import Table from "@mui/material/Table";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import Pagination from "@mui/material/Pagination";
import TableRow from "@mui/material/TableRow";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

function createData(name, calories, fat, carbs, protein, price) {
  return {
    name,
    calories,
    fat,
    carbs,
    protein,
    price,
    history: [
      {
        date: "2020-01-05",
        customerId: "11091700",
        amount: 3,
      },
      {
        date: "2020-01-02",
        customerId: "Anonymous",
        amount: 1,
      },
    ],
  };
}

function Row(props) {
  const { row } = props;
  const [open, setOpen] = React.useState(false);
  //   console.log(row, "row");

  return (
    <React.Fragment>
      <TableRow>
        <TableCell>
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={() => setOpen(!open)}
          >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell>{row.source}</TableCell>
        <TableCell align="center">{row.name}</TableCell>
        <TableCell align="center">{row.severity}</TableCell>
        <TableCell align="center">{row.http_url}</TableCell>
        <TableCell align="center">
          {row.open_status == true ? "Open" : "Unknown"}
        </TableCell>
        {/* </TableRow> */}
        {/* <TableRow> */}
        {/* <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}> */}
        <Collapse in={open} timeout="auto" unmountOnExit>
          <Box sx={{ margin: 1, width: "400px" }}>
            {/* <Typography variant="h6" gutterBottom component="div">
                {`${row.severity} | ${row.name}`}
              </Typography> */}
            {/* <Table size="small" aria-label="purchases"> */}
            {/* <TableHead>
                  <TableRow> */}
            {/* <TableCell>ID</TableCell> */}
            {/* <TableCell>Discovered On</TableCell>
                    <TableCell align="right">URL</TableCell>
                    <TableCell align="right">Severity</TableCell>
                    <TableCell align="right">Type</TableCell>
                    <TableCell align="right">Source</TableCell>
                  </TableRow>
                </TableHead> */}
            {/* <TableBody> */}
            {/* {row.map((singleRow) => ( */}
            <>
              {/* <TableRow> */}
              {/* <TableCell component="th" scope="row">
                        {row.id}
                      </TableCell> */}
              {/* <TableCell>{row.discovered_date}</TableCell>
                      <TableCell>{row.source}</TableCell>
                      <TableCell>{row.severity}</TableCell>
                      <TableCell>{row.type}</TableCell>
                      <TableCell>{row.http_url}</TableCell> */}
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>Info</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{`Discovered On:${row.discovered_date}`}</Typography>
                  <Typography>{`URL:${row.source}`}</Typography>
                  <Typography>{`Severity:${row.severity}`}</Typography>
                  <Typography>{`Type:${row.type}`}</Typography>
                  <Typography>{`Source:${row.http_url}`}</Typography>
                </AccordionDetails>
              </Accordion>
              {/* </TableRow>
                    <TableRow> */}
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>Nuclei Template Details</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{`Template:${row.template}`}</Typography>
                  <Typography>{`Template URL:${row.template_url}`}</Typography>
                  <Typography>{`Template ID:${row.template_id}`}</Typography>
                  <Typography>{`Matcher Name:${row.matcher_name}`}</Typography>
                  <Typography>{`CVSS Metrics:${row.cvss_metrics}`}</Typography>
                </AccordionDetails>
              </Accordion>
              {/* </TableRow>
                    <TableRow> */}
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>CURL Command</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{`Template:${row.curl_command}`}</Typography>
                </AccordionDetails>
              </Accordion>
              {/* </TableRow>
                    <TableRow> */}
              {/* <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>HTTP Request</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{`Template:${row.request}`}</Typography>
                </AccordionDetails>
              </Accordion> */}
              {/* </TableRow>
                    <TableRow> */}
              {/* <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel2a-content"
                  id="panel2a-header"
                >
                  <Typography>HTTP Response</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{`Template:${row.response}`}</Typography>
                </AccordionDetails>
              </Accordion> */}
              {/* </TableRow> */}
            </>
            {/*   ))} */}
            {/* </TableBody>
              </Table> */}
          </Box>
        </Collapse>
        {/* </TableCell> */}
        {/* </TableRow> */}
      </TableRow>
    </React.Fragment>
  );
}

export default function CollapsibleTable(props) {
  const { rows } = props;
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [message, setMessage] = React.useState(false);

  useEffect(() => {
    console.log(rows, "ss");
    if (rows.length == 0) {
      setMessage(true);
    }
  }, []);

  function PageBar() {
    return (
      <Paper elevation={8}>
        <Box sx={{ display: "flex", width: "100%", margin: "5px" }}>
          <Pagination
            onChange={(event, value) => {
              setPage(value - 1);
              console.log(event.target.value, value);
            }}
            page={page + 1}
            count={Math.round(rows.length / 5)}
            shape="rounded"
          />
        </Box>
      </Paper>
    );
  }

  const visibleRows = React.useMemo(
    () => rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage),
    [page, rowsPerPage]
  );

  return (
    <>
      {" "}
      <TableContainer sx={{ width: "100%" }}>
        <Table aria-label="collapsible table">
          <TableHead>
            <TableRow>
              <TableCell />
              <TableCell>Source</TableCell>
              <TableCell align="center">Title</TableCell>
              <TableCell align="center">Severity</TableCell>
              <TableCell align="center">Vulnerable URL</TableCell>
              <TableCell align="center">Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {visibleRows.map((row, index) => (
              <Row key={index} row={row} />
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      {message && (
        <Paper
          sx={{
            backgroundColor: "black",
            color: "white",
            p: 1,
            textAlign: "center",
          }}
        >
          No data
        </Paper>
      )}
      {!message && <TablePagination component={PageBar} />}
    </>
  );
}
