// "use client";
import Sidebar from "./sidebar";
import Topbar from "./topbar";
import Box from "@mui/material/Box";
import {
  handleSignOut,
  getUserSession,
  CookieContext,
  supabase,
} from "../services/index";
import { useEffect, useState } from "react";
import React from "react";
import { useRouter } from "next/navigation";
import { useContext } from "react";
import PropTypes from "prop-types";
import { ASMTContext } from "../contexts/ASMTContext";
import Dashboard from "./dashboard";
import Summary from "./summary";
import Details from "./details";
import Deltas from "./deltas";
import KPI from "./kpi";
import Integrations from "./integrations";
import Domains from "./domains";
import Settings from "./settings";
import Notifications from "./notifications";
import Billings from "../src/app/register/components/billings";

export function Item(props) {
  const { sx, ...other } = props;
  return (
    <Box
      sx={{
        display: "inline-flex",
        bgcolor: (theme) =>
          theme.palette.mode === "dark" ? "#101010" : "#fff",
        color: (theme) =>
          theme.palette.mode === "dark" ? "grey.300" : "grey.800",
        fontSize: "0.875rem",
        fontWeight: "700",
        ...sx,
      }}
      {...other}
    />
  );
}

Item.propTypes = {
  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: PropTypes.oneOfType([
    PropTypes.arrayOf(
      PropTypes.oneOfType([PropTypes.func, PropTypes.object, PropTypes.bool])
    ),
    PropTypes.func,
    PropTypes.object,
  ]),
};

const ASMTComponent = (props) => {
  const { loader } = props;
  const { push } = useRouter();

  const [currentComponent, setCurrentComponent] = useState("DashBoard");
  const [orgId, setOrgId] = useState();
  // const [load, setLoad] = useState(true);
  const [token, setToken] = useState();
  const [target, setTarget] = useState();
  const [site, setSite] = useState("http://localhost:3001/v1");
  const [siteV2, setSiteV2] = useState("http://localhost:3001/v2");
  // const [machineFetch, setMachineFetch] = useState();
  // let machineFetch;
  //   const [load, setLoad] = useState(false);
  //   const [orgIdRengine, setOrgIdRengine] = useState();
  const connectClient = async (site) => {
    let url = `${site}/api/loginAt/`;
    try {
      let response = await fetch(url, {
        method: "post",
        headers: {
          "Content-Type": "application/json",
          mode: "cors",
          // "Access-Control-Expose-Headers": "*",
          // "Access-Control-Allow-Origin": "*",
          // "Access-Control-Allow-Credentials": "true",
          // "Access-Control-Allow-Methods": "GET,HEAD,OPTIONS,POST,PUT",
          // "Access-Control-Allow-Headers":
          //   "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers",
        },
        body: JSON.stringify({ username: "admin", password: "1234" }),
      });
      let csrf = await response.json();
      //   .getSetCookie()[1]
      //   .split(";")[0]
      //   .split("=")[1];
      // console.log(getCookie(), "hds");
      // response.headers.forEach(console.log);
      // setToken(csrf);
      // console.log(csrf, "csrf");
    } catch (error) {
      throw error;
      // token = null;
      console.log(error, "ert");
    }
  };

  useEffect(() => {
    const getProfile = async () => {
      return await supabase.from("Profile").select();
    };

    const getOrg = async (id) => {
      return await supabase.from("Organization").select().eq("id", id);
    };

    const machineFetchInit = async () => {
      try {
        let csrf = localStorage.getItem("X-CSRFToken");
        if (csrf == null) {
          console.log("sas");
          let response = await fetch("http://localhost:3001/token");
          response = await response.json();
          localStorage.setItem("X-CSRFToken", response.auth);
          setToken(response.auth);
        } else {
          setToken(csrf);
        }
        // let response = await fetch("http://localhost:3001/site");
        // console.log(response, response, "sie");
        // let site = response?.site;
      } catch (error) {
        console.log(error, "ini");

        // setLoad(false);
      }
      // setMachineFetch({ token, site });
    };

    machineFetchInit();

    const activeAccount = async (customer) => {
      try {
        // const customer = data[0].customer_id;
        let response = await fetch(`${site}/billing/?customer=${customer}`);
        const { subscriptions, customerDetails, paymentMethods } =
          await response.json();
        let account = "inactive";
        for (var i in subscriptions.data) {
          if (subscriptions.data[i].status == "active") account = "active";
        }
        if (account == "inactive") {
          //Inavctive account
          console.log("inact");
          push("/register/subscribe");
        }
      } catch (error) {
        console.log(error, "accPov");
      }
    };

    const subscriptionRequired = async () => {
      const { data, error } = await supabase.from("Profile").select();
      const id = data[0]?.org_id;
      if (!error && id != null) {
        const { data, error } = await supabase
          .from("Organization")
          .select("customer_id")
          .eq("id", id);
        if (!error) {
          let customer = data[0]?.customer_id;
          customer && activeAccount(customer);
        }
      }
    };

    subscriptionRequired();

    getProfile()
      .then(async ({ data, error }) => {
        if (error) {
          throw error;
        }
        console.log(data, "dmtt");
        const profileData = data[0];
        let orgData = {};
        if (profileData != null) {
          const id = profileData.org_id;
          if (!id) {
            console.log(`push("/register/subscribe")`);
            push("/register/subscribe");
            return;
          } else {
            loader(false);
          }
          orgData.org_id = id;
          console.log(orgData, "dddsmtadsdt");

          getOrg(id)
            .then(async ({ data, error }) => {
              console.log(data, error, "org");
              orgData.customer = data[0].customer_id;
              if (data[0].rengine_org_id)
                orgData.rengine_org_id = data[0].rengine_org_id;
              else {
                setCurrentComponent("Details");
                // throw error;
              }
              setOrgId(orgData);
              console.log(orgData, currentComponent, "dddsmtt");
            })
            .catch((error) => {
              console.log(error, "mtaser");

              throw error;
            });
        }
      })
      .catch((error) => {
        // setLoad(false);
        console.log(error, "mter");
      });
  }, []);

  return (
    <>
      <ASMTContext.Provider
        value={{
          currentComponent,
          setCurrentComponent,
          orgId,
          token,
          site,
          siteV2,
          setToken,
          target,
          setTarget,
        }}
      >
        <Topbar />

        <Box
          sx={{
            display: "flex",
            p: 1,
            borderRadius: 1,
            flexDirection: "row",
            mt: 6,
            minHeight: "100%",
          }}
        >
          <Item>
            <Sidebar />
          </Item>
          {currentComponent && orgId && (
            <Item sx={{ flexGrow: 1, m: 2 }}>
              {currentComponent === "DashBoard" ? <Dashboard /> : ""}
              {currentComponent === "Summary" ? <Summary /> : ""}
              {currentComponent === "Details" ? <Details /> : ""}
              {currentComponent === "Deltas" ? <Deltas /> : ""}
              {currentComponent === "KPI" ? <KPI /> : ""}
              {currentComponent === "Integrations" ? <Integrations /> : ""}
              {currentComponent === "Org Domains" ? <Domains /> : ""}
              {currentComponent === "Security Settings" ? (
                <Settings key={"Settings"} />
              ) : (
                ""
              )}
              {currentComponent === "Notifications" ? <Notifications /> : ""}
              {currentComponent === "Billings" ? <Billings /> : ""}
            </Item>
          )}
        </Box>
      </ASMTContext.Provider>
    </>
  );
};

export default ASMTComponent;
