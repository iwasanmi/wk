import React from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { useContext, useEffect } from "react";
import { ASMTContext } from "../contexts/ASMTContext";
import { supabase } from "../services";
import { useState } from "react";
import Stack from "@mui/system/Stack";
import TextField from "@mui/material/TextField";
import Input from "@mui/material/Input";
import { styled } from "@mui/system";
import { Box } from "@mui/material";
import CustomStyles from "./styles";

export const Item = styled("div")(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#262B32" : "#fff",
  // padding: theme.spacing(1),
}));

export const Rbox = styled(Box)(({ theme }) => ({
  [theme.breakpoints.down("md")]: {
    minWidth: "100%",
  },
}));

const Details = () => {
  const { orgId, site, token } = useContext(ASMTContext);
  const [detailNow, setDetailNow] = useState();
  const [detailPrev, setDetailPrev] = useState();
  const [changeForm, setChangeForm] = useState(false);
  const [target, setTarget] = useState();
  const [ip, setIp] = useState();
  const [image, setImage] = useState(false);

  const submitChange = async () => {
    console.log(detailNow, orgId, "sch");
    // if (detailNow.avatar) console.log(detailNow.avatar.name, "ins");
    // else console.log(data, "inorgerdta");
    // {
    //   const { data, error } = await supabase
    //     .from("Organization")
    //     .insert([{ customer_id: response.customerId }])
    //     .select();
    // }
    try {
      if (image) {
        const { data, error } = await supabase.storage
          .from("profile_logo")
          .upload(
            `avatars/${orgId.org_id}/${detailNow.avatar.name}`,
            detailNow.avatar,
            {
              cacheControl: "3600",
              upsert: false,
            }
          );
        if (error) {
          console.log(error, "inorger");
          throw error;
        } else {
          const { data, error } = await supabase
            .from("Organization")
            .update([{ avatar: detailNow.avatar.name }])
            .eq("id", parseInt(orgId.org_id))
            .select();
          console.log("dor", data, error);
          if (error) throw error;
        }
      } else {
        let details = detailNow;
        delete details.avatar;
        const { data, error } = await supabase
          .from("Organization")
          .update([detailNow])
          .eq("id", parseInt(orgId.org_id))
          .select();
        console.log(data, error, orgId, "uplerr");
        const orgData = data[0];
        const updateId = async () => {
          if (orgData.rengine_org_id == null && orgData.name !== "") {
            let obj = {};
            obj.token = token;
            obj.apiId = "addPro";
            let params = {
              name: orgData.name,
            };
            obj.params = params;
            let response = await fetch(site, {
              method: "post",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify(obj),
            });
            response = await response.json();
            const { data, error } = await supabase
              .from("Organization")
              .update([{ rengine_org_id: response.project_name }])
              .eq("id", parseInt(orgId.org_id));
            setDetailNow({
              ...detailNow,
              rengine_org_id: response.project_name,
            });
            location.reload();
            console.log(response, "reor");
            console.log(data, "reor");
            {
              // let obj = {};
              // obj.apiId = "addOrg";
              //   method: "post",
              //   headers: {
              //     Accept: "application/json",
              //     "Content-Type": "application/json",
              //   },
              //   body: JSON.stringify(obj),
              // });
              // let response = await fetch("http://localhost:3001/addOrg/", {
              //   method: "post",
              //   mode: "no-cors", //check
              //   headers: {
              //     "Content-Type": "application/json",
              //   },
              //   body: JSON.stringify(obj),
              // });
              // console.log("show");
            }
          }
        };
        await updateId();
      }
      const { data, error } = await supabase
        .from("Organization")
        .select("rengine_org_id")
        .eq("id", parseInt(orgId.org_id));
      let rengine_id_org = data[0].rengine_org_id;
      let PrevTarget = detailPrev.domains;
      let NowTarget = detailNow.domains;
      let PrevIp = detailPrev.ip_addresses;
      let NowIp = detailNow.ip_addresses;
      let diffTarget = PrevTarget != NowTarget;
      let diffIp = PrevIp != NowIp;
      console.log(diffTarget, diffIp, "ine");
      console.log(PrevTarget, NowTarget, PrevIp, NowIp, "idne");
      setDetailPrev({
        ip_addresses: detailNow.ip_addresses,
        domains: detailNow.domains,
      });
      if (diffTarget) {
        let obj = {};
        let params = {
          org_id: rengine_id_org,
          addTargets: detailNow.domains,
        };
        obj.token = token;
        obj.params = params;
        obj.apiId = "addTargets";
        //be_
        let response = await fetch(site, {
          method: "post",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(obj),
        });
        response = await response.json();
        console.log(response, "@tgt");
      }

      if (diffIp) {
        let obj = {};
        let params = {
          org_id: rengine_id_org,
          addTargets: detailNow.ip_addresses,
        };
        obj.token = token;
        obj.params = params;
        obj.apiId = "addTargets";
        //be_
        let response = await fetch(site, {
          method: "post",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(obj),
        });
        response = await response.json();
        console.log(response, "@ip");
      }
    } catch (error) {
      console.log(error, "deta");
    }
  };

  const handleChange = (event) => {
    let value = event.target.value;
    setDetailNow({
      ...detailNow,
      [event.target.id]:
        event.target.id === "avatar" ? event.target.files[0] : value,
    });
    if (event.target.id === "avatar") setImage(true);
    if (!changeForm) setChangeForm(true);
    try {
      console.log(event.target.id, "ifny");
    } catch (error) {
      console.log(error, "devn");
    }
  };

  const removeImage = async (event) => {
    setDetailNow({ ...detailNow, avatar: null });
    const { data, error } = await supabase
      .from("Organization")
      .update([{ avatar: "" }])
      .eq("id", parseInt(orgId.org_id));
  };

  useEffect(() => {
    console.log("sasa");
    console.log(orgId, "sch");

    const defaultForm = async () => {
      const { data, error } = await supabase
        .from("Organization")
        .select()
        .eq("id", parseInt(orgId.org_id));
      console.log(data, "ini");
      let effect = {};
      if (data[0]) {
        effect.name = data[0].name;
        effect.core_email = data[0].core_email;
        effect.domains = data[0].domains;
        effect.ip_addresses = data[0].ip_addresses;
        effect.tags = data[0].tags;
        effect.rengine_org_id = data[0].rengine_org_id;
        const avatar = data[0].avatar;
        setDetailPrev({
          name: data[0].name,
          domains: data[0].domains,
          ip_addresses: data[0].ip_addresses,
        });
        console.log(`avatars/${orgId.org_id}/${avatar}`);
        const response = await supabase.storage
          .from("profile_logo")
          .download(`avatars/${orgId.org_id}/${avatar}`);

        if (response.data) effect.avatar = response.data;
        setDetailNow(effect);
      } else throw Error("cannot load");
    };
    defaultForm();
    console.log("render");
  }, []);

  return (
    <>
      <Rbox sx={{ minWidth: "80%" }}>
        <Stack>
          <Item>
            <Card
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                textAlign: "center",
              }}
            >
              {detailNow?.avatar ? (
                <CardMedia
                  component="img"
                  alt="avatar"
                  sx={{ height: 140, objectFit: "contain" }}
                  image={URL.createObjectURL(detailNow.avatar)}
                />
              ) : (
                ""
              )}
              <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                  Upload Org Logo
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Your photo should be in PNG or JPG format
                </Typography>
              </CardContent>
              <CardActions>
                <Button size="small" component="label">
                  Choose Image
                  <input
                    id="avatar"
                    key="avatar"
                    hidden
                    type="file"
                    accept="image/png, image/jpeg"
                    onChange={(event) => {
                      handleChange(event);
                    }}
                  />
                </Button>
                <Button
                  size="small"
                  onClick={removeImage}
                  disabled={detailNow?.avatar == null}
                >
                  Remove
                </Button>
              </CardActions>
            </Card>
          </Item>
          {detailNow && (
            <>
              <Item sx={{ mt: 2 }}>
                <TextField
                  fullWidth
                  id="name"
                  key="name"
                  label="Org Name"
                  disabled={detailNow?.rengine_org_id != null}
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  defaultValue={detailNow?.name}
                  helperText="Your Full Name"
                  variant="standard"
                />
              </Item>
              <Item>
                <TextField
                  fullWidth
                  id="core_email"
                  key="core_email"
                  label="Core Contact Email"
                  defaultValue={detailNow?.core_email}
                  helperText="Your Email"
                  variant="standard"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                />
              </Item>
              <Item>
                <TextField
                  fullWidth
                  id="domains"
                  key="domains"
                  label="Domains for monitoring (Use comma ',' for separating domains)"
                  defaultValue={detailNow?.domains}
                  helperText="Your Domains"
                  variant="standard"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                />
              </Item>
              <Item>
                <TextField
                  fullWidth
                  id="ip_addresses"
                  key="ip_addresses"
                  label="IP Addresses for monitoring (Use comma ',' for separating IPs)"
                  defaultValue={detailNow?.ip_addresses}
                  helperText="Your IPs"
                  variant="standard"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                />
              </Item>
              <Item>
                <TextField
                  fullWidth
                  id="tags"
                  key="tags"
                  label="Tags (Use comma ',' for separating tags)"
                  defaultValue={detailNow?.tags}
                  helperText="List Tags"
                  multiline
                  variant="standard"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                />
              </Item>
              <Item
                sx={{
                  display: "flex",
                  bgcolor: "background.paper",
                  borderRadius: 1,
                  gap: 2,
                  flexDirection: "row",
                }}
              >
                <Button
                  size="small"
                  disabled={!changeForm}
                  onClick={() => {
                    location.reload();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  size="small"
                  disabled={!changeForm}
                  onClick={submitChange}
                >
                  Submit Profile
                </Button>
              </Item>
            </>
          )}
        </Stack>
      </Rbox>
    </>
  );
};

export default Details;
