import React from "react";
import { Rbox } from "./details";
import { Item } from "./details";
import { Stack } from "@mui/material";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { useContext, useEffect } from "react";
import Alert from "@mui/material/Alert";
import { ASMTContext } from "../contexts/ASMTContext";
import { Divider } from "@mui/material";
import { supabase } from "../services";
import { useState } from "react";
import TextField from "@mui/material/TextField";
import Input from "@mui/material/Input";
import { styled } from "@mui/system";
import { Box } from "@mui/material";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";

const Settings = () => {
  const { orgId, site, token } = useContext(ASMTContext);
  const [now, setNow] = useState();
  const [changeForm, setChangeForm] = useState(false);
  console.log("even");
  const handleChange = (event) => {
    setChangeForm(true);
    let value = event.target.value;
    if (value === "on" || value === "off") {
      value = event.target.checked;
    }
    setNow({
      ...now,
      [event.target.id]: value,
    });
  };

  const submitChange = async () => {
    let obj = {};
    obj.apiId = "Settings";
    obj.post = true;
    obj.token = token;
    obj.rengine_org_id = orgId.rengine_org_id;
    obj.params = now;
    try {
      let response = await fetch(site, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
      });
      response = await response.json();
      console.log(response, "okay");
    } catch (error) {
      console.log(error, "okayError");
    }
  };

  useEffect(() => {
    const apiLoad = async () => {
      let obj = {};
      obj.apiId = "Settings";
      obj.get = true;
      obj.token = token;
      obj.rengine_org_id = orgId.rengine_org_id;
      try {
        let response = await fetch(site, {
          method: "post",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(obj),
        });
        response = await response.json();
        console.log(response.status, response, "ds");
        if (response.status == undefined) {
          setNow({
            openaikey: response.OpenAiAPIKey.key,
            netlaskey: response.NetlasAPIKey.key,
            use_proxy: response.Proxy.use_proxy,
            proxies: response.Proxy.proxies,
          });
          console.log(response, "okay");
        }
      } catch (error) {
        console.log(error, "okayError");
      }
    };
    apiLoad();
  }, []);

  return (
    <Rbox sx={{ minWidth: "80%" }}>
      <Stack spacing={2}>
        {now && (
          <>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
              >
                Proxy Settings
              </Typography>
              <Divider />
            </Item>
            <Item
              sx={{
                border: 1,
                p: 1,
                borderColor: "grey.500",
                backgroundColor: "grey.500",
                opacity: 0.5,
              }}
            >
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                Every website has a limit to certain number of requests allowed
                for a certain period of time from an particular IP Address,
                exceeding the limit will block any incoming requests from that
                particular IP Address for a specific period of time. This
                results in unreliable recon results. Suppose if you were to run
                Nuclei on a particular target with all the templates, your IP is
                likely to get banned because of the number of requests made by
                Nuclei. And this is especially true for dorking and other OSINT
                reNgine does. After certain dorking attempts Google is likely to
                ban your IP for certain period of time.
              </Typography>
              <Alert severity="info">Using proxies is recommended.</Alert>
            </Item>
            <Item></Item>
            <Item>
              <FormControlLabel
                control={
                  <Checkbox
                    disabled
                    id="use_proxy"
                    checked={now.use_proxy}
                    onChange={(event) => {
                      handleChange(event);
                    }}
                    size="small"
                  />
                }
                label="Use Proxy"
              />
            </Item>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                Proxy List
              </Typography>

              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                You can enter as many proxies as you want, reNgine will randomly
                pick one among them during the scan.
              </Typography>
            </Item>
            <Item>
              <TextField
                id="proxies"
                label="Separate the proxies by newline."
                fullWidth
                multiline
                rows={3}
                defaultValue={now.proxies}
                disabled={now.use_proxy != true}
                onChange={(event) => {
                  handleChange(event);
                }}
                variant="standard"
              />
            </Item>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                OpenAI
              </Typography>

              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                OpenAI keys will be used to generate vulnerability description,
                remediation, impact and vulnerability report writing using
                ChatGPT.
              </Typography>
            </Item>
            <Item>
              <TextField
                fullWidth
                id="openaikey"
                key="OpenAiAPIKey"
                label="Enter OpenAI Key"
                defaultValue={now.openaikey}
                helperText="OpenAI keys will be used to generate vulnerability description, remediation, impact and vulnerability report writing using ChatGPT."
                variant="standard"
                onChange={(event) => {
                  handleChange(event);
                }}
              />
            </Item>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                Netlas
              </Typography>

              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                Netlas keys will be used to get whois information and other
                OSINT data.
              </Typography>
            </Item>
            <Item>
              <TextField
                fullWidth
                id="netlaskey"
                key="NetlasAPIKey"
                label="Enter Netlas Key"
                defaultValue={now.netlaskey}
                helperText="Netlas keys will be used to get whois information and other OSINT data."
                variant="standard"
                onChange={(event) => {
                  handleChange(event);
                }}
              />
            </Item>
            <Button size="small" disabled={!changeForm} onClick={submitChange}>
              Save Settings
            </Button>
          </>
        )}
      </Stack>
    </Rbox>
  );
};

export default Settings;
