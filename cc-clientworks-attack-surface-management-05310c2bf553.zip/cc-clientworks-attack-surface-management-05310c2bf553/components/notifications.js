import { Box } from "@mui/material";
import React from "react";
import Stack from "@mui/system/Stack";
// import DeleteIcon from "@mui/icons-material/Delete";
import Typography from "@mui/material/Typography";
import Switch from "@mui/material/Switch";
import TextField from "@mui/material/TextField";
import { Divider } from "@mui/material";
import { styled } from "@mui/system";
import Button from "@mui/material/Button";
import { useContext, useEffect } from "react";
import { useState } from "react";
import { ASMTContext } from "../contexts/ASMTContext";

const Item = styled("div")(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#262B32" : "#fff",
  // padding: theme.spacing(1),
}));

const Rbox = styled(Box)(({ theme }) => ({
  [theme.breakpoints.down("md")]: {
    minWidth: "100%",
  },
}));

const Notifications = () => {
  const { orgId, site, token } = useContext(ASMTContext);
  // let url = `http://localhost:8000/api/notification/?org_id=${orgId?.rengine_org_id}`;
  const [now, setNow] = useState();
  const handleChange = (event) => {
    let value = event.target.value;
    if (value === "on" || value === "off") {
      value = event.target.checked;
    }
    setNow({
      ...now,
      [event.target.id]: value,
    });
  };

  const handleSave = async () => {
    console.log(now, "now");
    let obj = {};
    obj.apiId = "Notification";
    obj.post = true;
    obj.token = token;
    obj.rengine_org_id = orgId.rengine_org_id;
    obj.params = now;
    try {
      let response = await fetch(
        site,
        // `http://127.0.0.1:8000/api/listTargets/?orgId=${orgIdRengine}`,
        {
          method: "post",
          // mode: "cors",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(obj),
        }
      );
      response = await response.json();
      console.log(response, "okay");
    } catch (error) {
      console.log(error, "okayError");
    }
  };

  useEffect(() => {
    const callNotificationApi = async () => {
      let obj = {};
      obj.apiId = "Notification";
      obj.get = true;
      obj.token = token;
      obj.rengine_org_id = orgId.rengine_org_id;
      try {
        let response = await fetch(
          site,
          // `http://127.0.0.1:8000/api/listTargets/?orgId=${orgIdRengine}`,
          {
            method: "post",
            // mode: "cors",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify(obj),
          }
        );
        response = await response.json();
        setNow(response.obj);
        console.log(response, "okay");
      } catch (error) {
        console.log(error, "okayError");
      }
    };

    callNotificationApi();
  }, []);

  return (
    <Rbox>
      <Stack spacing={2}>
        {now && (
          <>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
              >
                Send Notifications to:
              </Typography>
              <Divider />
              <Divider />
            </Item>
            <Typography variant="caption" display="block" gutterBottom>
              Slack
            </Typography>
            <Item sx={{ display: "flex", flexDirection: "row" }}>
              <Box>
                <Switch
                  defaultChecked={now?.send_to_slack}
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  id="send_to_slack"
                />
              </Box>
              <Box sx={{ flexGrow: 1 }}>
                <TextField
                  fullWidth
                  id="slack_hook_url"
                  key="slack_hook_url"
                  label="Slack URL"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  value={now?.slack_hook_url}
                  disabled={!now?.send_to_slack}
                  variant="standard"
                />
              </Box>
              <Box>{/* <DeleteIcon /> */}</Box>
            </Item>
            <Typography variant="caption" display="block" gutterBottom>
              Discord (Recommended)
            </Typography>
            <Item sx={{ display: "flex", flexDirection: "row" }}>
              <Box>
                <Switch
                  defaultChecked={now?.send_to_discord}
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  id="send_to_discord"
                />
              </Box>
              <Box sx={{ flexGrow: 1 }}>
                <TextField
                  fullWidth
                  id="discord_hook_url"
                  key="discord_hook_url"
                  label="Discord URL"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  value={now?.discord_hook_url}
                  disabled={!now?.send_to_discord}
                  variant="standard"
                />
              </Box>
              <Box>{/* <DeleteIcon /> */}</Box>
            </Item>
            <Typography variant="caption" display="block" gutterBottom>
              Telegram
            </Typography>
            <Item sx={{ display: "flex", flexDirection: "row" }}>
              <Box>
                <Switch
                  defaultChecked={now?.send_to_telegram}
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  id="send_to_telegram"
                />
              </Box>
              <Box sx={{ flexGrow: 1 }}>
                <TextField
                  fullWidth
                  id="telegram_bot_token"
                  key="telegram_bot_token"
                  label="Bot Token"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  value={now?.telegram_bot_token}
                  disabled={!now?.send_to_telegram}
                  variant="standard"
                />
              </Box>
              <Box sx={{ flexGrow: 1 }}>
                <TextField
                  fullWidth
                  id="telegram_bot_chat_id"
                  key="telegram_bot_chat_id"
                  label="Bot Chat ID"
                  onChange={(event) => {
                    handleChange(event);
                  }}
                  value={now?.telegram_bot_chat_id}
                  disabled={!now?.send_to_telegram}
                  variant="standard"
                />
              </Box>
              <Box>{/* <DeleteIcon /> */}</Box>
            </Item>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
              >
                Send me notification for:
              </Typography>
              <Divider />
              <Divider />
            </Item>
            <Item>
              <Switch
                defaultChecked={now?.send_scan_status_notif}
                onChange={(event) => {
                  handleChange(event);
                }}
                id="send_scan_status_notif"
              />
              <Typography variant="caption" display="inline-block" gutterBottom>
                Scan related updates (e.g.Scan Initiated, Scan Completed)
              </Typography>
            </Item>
            <Item>
              <Switch
                defaultChecked={now?.send_interesting_notif}
                onChange={(event) => {
                  handleChange(event);
                }}
                id="send_interesting_notif"
              />
              <Typography variant="caption" display="inline-block" gutterBottom>
                Interesting Subdomains
              </Typography>
            </Item>
            <Item>
              <Switch
                defaultChecked={now?.send_vuln_notif}
                onChange={(event) => {
                  handleChange(event);
                }}
                id="send_vuln_notif"
              />
              <Typography variant="caption" display="inline-block" gutterBottom>
                Vulnerabilities Found
              </Typography>
            </Item>
            <Item>
              <Typography variant="caption" display="block" gutterBottom>
                *Informational Vulnerabilities will not be notified.
              </Typography>
              <Switch
                defaultChecked={now?.send_subdomain_changes_notif}
                onChange={(event) => {
                  handleChange(event);
                }}
                id="send_subdomain_changes_notif"
              />
              <Typography variant="caption" display="inline-block" gutterBottom>
                Subdomain Changes (e.g. when new Subdomains are discovered or
                subdomains are no longer available)
              </Typography>
            </Item>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
              >
                Upload Scan Results (Recommended):
              </Typography>
              <Divider />
              <Divider />
            </Item>
            <Item>
              <Switch
                defaultChecked={now?.send_scan_output_file}
                onChange={(event) => {
                  handleChange(event);
                }}
                id="send_scan_output_file"
              />
              <Typography variant="caption" display="inline-block" gutterBottom>
                Send Scan Output (e.g.Subdomain gathered file)
              </Typography>
              <Typography variant="caption" display="block" gutterBottom>
                Only discord is supported!
              </Typography>
              <Typography variant="caption" display="block" gutterBottom>
                (This lets you upload scan results like list of subdomains to
                your discord)
              </Typography>
            </Item>
            <Item>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
              >
                Upload Scan Results (Recommended):
              </Typography>
              <Divider />
              <Divider />
            </Item>
            <Item>
              <Switch
                defaultChecked={now?.send_scan_tracebacks}
                onChange={(event) => {
                  handleChange(event);
                }}
                id="send_scan_tracebacks"
              />
              <Typography variant="caption" display="inline-block" gutterBottom>
                Send tasks tracebacks
              </Typography>
              <Typography variant="caption" display="block" gutterBottom>
                Only discord is supported!
              </Typography>
              <Typography variant="caption" display="block" gutterBottom>
                (upload task failed tasks tracebacks to your Discord)
              </Typography>
            </Item>
            <Item>
              <Button size="small" onClick={handleSave}>
                Save and Test Notification
              </Button>
              <Typography variant="caption" display="block" gutterBottom>
                *Once saved, a test message will be sent to all the enabled
                services.
              </Typography>
            </Item>
          </>
        )}
      </Stack>
    </Rbox>
  );
};

export default Notifications;
