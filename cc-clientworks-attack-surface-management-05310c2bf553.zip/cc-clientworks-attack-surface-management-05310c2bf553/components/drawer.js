import React from "react";
import Box from "@mui/material/Box";
import SwipeableDrawer from "@mui/material/SwipeableDrawer";
import Stack from "@mui/material/Stack";
import { styled } from "@mui/material/styles";
import dayjs from "dayjs";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimeField } from "@mui/x-date-pickers/DateTimeField";
import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import { useContext, useEffect } from "react";
import { ASMTContext } from "../contexts/ASMTContext";

import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import { GifBoxOutlined } from "@mui/icons-material";

const Item = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  color: theme.palette.text.secondary,
}));

const Drawer = (props) => {
  const { orgId, site, token } = useContext(ASMTContext);
  const [scan, setScan] = React.useState();
  const [mode, setMode] = React.useState("periodic");
  const [type, setType] = React.useState("domain");
  const [text, setText] = React.useState({ periodText: "30,minutes" });
  const [value, setValue] = React.useState(dayjs("2022-04-17T15:30"));
  const [open, setOpen] = React.useState(props.open);
  const open_fn = props.close;

  const handleChange = (event) => {
    setScan(event.target.value);
  };
  const handleText = (event) => {
    setText({ ...text, [event.target.id]: event.target.value });
  };

  const handleSchedule = (event) => {
    if (event.target.checked) {
      setType(event.target.id);
      return;
    }
    setType();
    console.log(event.target.id, "sch");
  };

  const handleMode = (event) => {
    if (event.target.checked) {
      setMode(event.target.id);
      return;
    }
    setMode();
    console.log(event.target.id, "sch");
  };

  const handleDelete = async (event) => {
    try {
      let obj = {};
      obj.apiId = "deleteTargets";
      obj.token = token;
      let params = {};
      let targetSelect = props.targetSelect;
      params.targets = targetSelect;
      obj.params = params;
      console.log(obj, "wsssat");
      //be------
      let response = await fetch(site, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
      });
      response = await response.json();
      console.log(response, "wat");
    } catch (error) {
      console.log(error, "er");
    }
  };

  const submitScans = async (event) => {
    try {
      let targetSelect = props.targetSelect;
      console.log(event.target.value, targetSelect, "sub");
      let obj = {};
      obj.apiId = "scanApi";
      obj.token = token;
      let params = {};
      params.listOfDomainId = targetSelect;
      params.scanMode = scan;
      let org_id;
      {
        const { data, error } = await supabase.from("Profile").select("org_id");
        if (data.length) {
          org_id = parseInt(data[0].org_id);
        }
      }
      {
        // console.log(org_id, data, error, "orff");
        const { data, error } = await supabase
          .from("Organization")
          .select("first_limit")
          .eq("id", org_id);
        params.supabase_limit = data[0].first_limit;
      }
      params.org_id = orgId.rengine_org_id;
      obj.params = params;
      console.log(obj, orgId, "wsssat");
      // //be------
      let response = await fetch(site, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
      });
      response = await response.json();
      console.log(response, "wat");
    } catch (error) {
      console.log(error, "er");
    }
  };

  {
    // params.orgId = orgId.rengine_org_id;
    // if (type == "target") {
    //   params.domainId = targetSelect[0];
    // }
    // if (type == "domain") {
    // }
    // if (type == "org") params.orgId = orgId.rengine_org_id;
    // if (type == "org" || type == "target") {
    //   params.schedule = true;
    //   params.scheduledMode = mode;
    //   if (mode == "periodic") {
    //     console.log(text, "prii");
    //     let val = text.periodText.split(",");
    //     console.log(val, "caa");
    //     params.frequency = parseInt(val[0]);
    //     params.frequency_type = val[1];
    //   } else if (mode == "clocked") params.scheduled_time = value;
    //   else params.scheduled_time = null;
    // }
  }
  const list = (anchor) => (
    <Box>
      <Stack>
        <Box hidden>
          <Item>
            <FormControlLabel
              control={
                <Checkbox
                  id="org"
                  checked={type == "org"}
                  onChange={handleSchedule}
                  size="small"
                />
              }
              label="Schedule Organization Scan"
            />
          </Item>
          <Divider />{" "}
          <Item>
            <FormControlLabel
              control={
                <Checkbox
                  id="target"
                  checked={type == "target"}
                  onChange={handleSchedule}
                  size="small"
                />
              }
              label="Schedule Target Scan"
            />
          </Item>
          <Divider />{" "}
        </Box>
        <Item>
          <FormControlLabel
            control={
              <Checkbox
                id="domain"
                checked={type == "domain"}
                onChange={handleSchedule}
                size="small"
              />
            }
            label="Scan Selected Targets"
          />
        </Item>
        <Item>
          <FormControlLabel
            control={
              <Checkbox
                id="delete"
                checked={type == "delete"}
                onChange={handleSchedule}
                size="small"
              />
            }
            label="Delete Selected Targets"
          />
        </Item>
        <Divider />
        <Item hidden>
          <FormControlLabel
            control={
              <Checkbox
                id="periodic"
                checked={mode == "periodic"}
                onChange={handleMode}
                size="small"
              />
            }
            label="Periodic"
          />
          <TextField
            id="periodText"
            onChange={(event) => {
              handleText(event);
            }}
            label="Run scan every"
            defaultValue="30,minutes"
            helperText="number,(minutes,hours,days,weeks,months)"
            variant="standard"
          />
        </Item>
        <Item hidden>
          <FormControlLabel
            control={
              <Checkbox
                id="clocked"
                checked={mode == "clocked"}
                onChange={handleMode}
                size="small"
              />
            }
            label="Clocked"
          />
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DateTimeField
              label="Controlled field"
              value={value}
              onChange={(newValue) => setValue(newValue)}
            />
          </LocalizationProvider>
        </Item>
        <Divider />
        <Item>
          <FormControl fullWidth disabled={type == "delete"}>
            <InputLabel id="engine-select-label">Select Scan Engine</InputLabel>
            <Select
              labelId="engine-label"
              id="engine"
              value={scan}
              label="Select Scan Engine"
              onChange={handleChange}
            >
              <MenuItem value={1}>Full Scan</MenuItem>
              <MenuItem value={2}>Subdomain Scan</MenuItem>
              <MenuItem value={3}>OSINT</MenuItem>
              <MenuItem value={4}>Vulnerability Scan</MenuItem>
              <MenuItem value={5}>Port Scan</MenuItem>
              <MenuItem value={6}>reNgine Recommended</MenuItem>
            </Select>
          </FormControl>
        </Item>
        <Divider />
        <Item>
          <TextField
            disabled={type == "delete" || props.targetSelect.length > 1}
            id="importSubdomainTextArea"
            label="Import Subdomains(Optional)"
            defaultValue={""}
            helperText="Separate the subdomains using ','. If the subdomain does not belong to domain it will be skipped."
            variant="standard"
            onChange={(event) => {
              handleText(event);
            }}
          />
          <TextField
            disabled={type == "delete" || props.targetSelect.length > 1}
            id="outOfScopeSubdomainTextarea"
            label="Out of Scope Subdomains(Optional)"
            defaultValue={""}
            helperText="Separate the out of scope subdomains/keywords using ','.(No regex currently supported.)"
            variant="standard"
            onChange={(event) => {
              handleText(event);
            }}
          />
          <TextField
            disabled={type == "delete" || props.targetSelect.length > 1}
            id="filterPath"
            label="Filters (Optional)"
            defaultValue={""}
            fullWidth
            helperText={`You can filter on a specific path for the target.`}
            variant="standard"
            onChange={(event) => {
              handleText(event);
            }}
          />
        </Item>
        <Divider />
        <Item>
          <Button
            disabled={type == "domain"}
            size="small"
            onClick={handleDelete}
          >
            Delete
          </Button>
          <Button
            disabled={type == "delete"}
            size="small"
            onClick={submitScans}
          >
            Submit
          </Button>
        </Item>
      </Stack>
    </Box>
  );
  return <Box>{list(props.anchor)}</Box>;
};

export default Drawer;
