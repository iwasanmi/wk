import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import AdbIcon from "@mui/icons-material/Adb";
import { useRouter } from "next/navigation";
import { Image } from "@mui/icons-material";
import logo from "../public/logo.png";

import { Item } from "./ASMTComponent";
import {
  handleSignOut,
  getUserSession,
  CookieContext,
} from "../services/index";
import { useContext, useEffect } from "react";
import { useState } from "react";
import { ASMTContext } from "../contexts/ASMTContext";

const pages = ["Products", "Pricing", "Blog"];
const settings = ["Profile", "Account", "Dashboard", "Logout"];
console.log(logo, "dff");
const Topbar = () => {
  const { push } = useRouter();
  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const { orgId, site, token, setToken } = useContext(ASMTContext);
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  console.log(logo, orgId, "kll");

  return (
    <>
      <AppBar position="fixed" title={<img src={logo.src} />}>
        <Container maxWidth="xl">
          <Toolbar disableGutters>
            <Box
              sx={{
                height: 64,
                background: "transparent",
                flex: 1,
              }}
            >
              <Box
                component="img"
                sx={{
                  height: 64,
                }}
                alt="Your logo."
                src="white-logo.png"
              />
            </Box>
            <Box sx={{ float: "right" }}>
              <Button
                onClick={async () => {
                  let response = await fetch("http://localhost:3001/token");
                  response = await response.json();
                  localStorage.setItem("X-CSRFToken", response.auth);
                  setToken(response.auth);
                }}
                color="inherit"
              >
                Refresh
              </Button>
              <Button
                onClick={() => {
                  push("register/subscribe");
                }}
                color="inherit"
              >
                Billings
              </Button>
              <Button
                onClick={() => {
                  handleSignOut();
                  push("/login");
                }}
                color="inherit"
              >
                Logout
              </Button>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
    </>
  );
};

export default Topbar;
