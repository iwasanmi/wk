import { Box, Stack, Typography, Divider, Paper } from "@mui/material";
import React from "react";
import * as ReactDOM from "react-dom";
import { styled } from "@mui/material/styles";
import {
  ChartComponent,
  SeriesCollectionDirective,
  SeriesDirective,
  Inject,
  Legend,
  Category,
  Tooltip,
  DataLabel,
  ScatterSeries,
} from "@syncfusion/ej2-react-charts";
import { ASMTContext } from "../contexts/ASMTContext";
import { Accordion } from "@mui/material/Accordion";
import { AccordionSummary } from "@mui/material/AccordionSummary";
import { AccordionDetails } from "@mui/material/AccordionDetails";
import { ExpandMoreIcon } from "@mui/icons-material/ExpandMore";
import { useContext, useEffect } from "react";
import { EnhancedTable } from "./table";
import CollapsibleTable from "./collapsetable";
import { Button } from "@mui/material";
import { useState } from "react";

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  color: theme.palette.text.secondary,
}));
function ScatterPlot(props) {
  const { plot } = props;
  // const primaryxAxis = {
  //   title: "Height (cm)",
  //   minimum: 130,
  //   maximum: 400,
  //   edgeLabelPlacement: "Shift",
  //   labelFormat: "{value}cm",
  // };
  // const primaryyAxis = {
  //   title: "Weight (kg)",
  //   minimum: 30,
  //   maximum: 100,
  //   labelFormat: "{value}kg",
  //   rangePadding: "None",
  // };
  const marker = { width: 15, height: 15 };
  return (
    <ChartComponent
      id="charts"
      // primaryXAxis={primaryxAxis}
      // primaryYAxis={primaryyAxis}
      title="Vulnerabilities"
    >
      <Inject
        services={[ScatterSeries, Legend, Tooltip, DataLabel, Category]}
      />
      <SeriesCollectionDirective>
        <SeriesDirective
          dataSource={plot}
          xName="total"
          yName="severity"
          name="Vulnerabilities"
          type="Scatter"
          marker={marker}
        ></SeriesDirective>
      </SeriesCollectionDirective>
    </ChartComponent>
  );
}

export const AccordionRow = (props) => {
  const { text } = props;
  return (
    <Accordion>
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        aria-controls="panel2a-content"
        id="panel2a-header"
      >
        <Typography>{"Tags"}</Typography>
      </AccordionSummary>
      <AccordionDetails>
        <Typography>{text}</Typography>
      </AccordionDetails>
    </Accordion>
  );
};

const KPI = () => {
  const { orgId, site, siteV2, token, target, setTarget } =
    useContext(ASMTContext);
  // const target = { id: 1 };
  let obj = {};
  obj.token = token;
  obj.rengine_org_id = orgId.rengine_org_id;
  // obj.rengine_org_id = "default";
  let pager = {};

  const [page, setPage] = useState();
  const [selectedScans, setSelectedScans] = useState([]);

  const vulnerableheadCells = [
    {
      id: "name",
      numeric: false,
      disablePadding: true,
      label: "Target",
    },
    {
      id: "vuln_count",
      numeric: true,
      disablePadding: false,
      label: "Vulnerabilities Count",
    },
  ];

  const commonheadCells = [
    {
      id: "name",
      numeric: false,
      disablePadding: true,
      label: "Vulnerability",
    },
    {
      id: "count",
      numeric: true,
      disablePadding: false,
      label: "Count",
    },
    {
      id: "severity",
      numeric: false,
      disablePadding: false,
      label: "Severity",
    },
  ];

  const highlightheadCells = [
    {
      id: "type",
      numeric: false,
      disablePadding: true,
      label: "Type",
    },
    {
      id: "name",
      numeric: false,
      disablePadding: false,
      label: "Vulnerability",
    },
    {
      id: "severity",
      numeric: false,
      disablePadding: false,
      label: "Severity",
    },
    {
      id: "http_url",
      numeric: false,
      disablePadding: false,
      label: "Vulnerable URL",
    },
  ];

  const urlheadCells = [
    {
      id: "http_url",
      numeric: false,
      disablePadding: true,
      label: "HTTP URL",
    },
    {
      id: "page_title",
      numeric: false,
      disablePadding: false,
      label: "Page Title",
    },
    {
      id: "http_status",
      numeric: false,
      disablePadding: false,
      label: "Status",
    },
    {
      id: "content_type",
      numeric: false,
      disablePadding: false,
      label: "Content Type",
    },
    {
      id: "content_length",
      numeric: false,
      disablePadding: false,
      label: "Content Length",
    },
    {
      id: "response_time",
      numeric: false,
      disablePadding: false,
      label: "Response Time",
    },
  ];

  const callApiV2 = async () => {
    console.log(obj, "obj");
    let response = await fetch(siteV2, {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(obj),
    });
    response = await response.json();
    console.log(response, "v2a");
    return response;
  };

  useEffect(() => {
    const loadPage = async () => {
      obj.apiId = `/api/fetch/most_vulnerable/?format=json`;
      obj.method = "post";
      obj.params = { target_id: target.id };
      let response = await callApiV2();
      pager = { vulnerable: response.result };
      console.log(pager, "re");
      ///////////////////////////////////////////////////////////
      obj.apiId = `/api/fetch/most_common_vulnerability/?format=json`;
      obj.method = "post";
      obj.params = { target_id: target.id };
      response = await callApiV2();
      pager = { ...pager, common: response.result };
      // setPage(pager);
      ///////////////////////////////////////////////////////////
      obj.apiId = `/api/get/kpi?id=${target.id}`;
      obj.method = "get";
      obj.params = null;
      response = await callApiV2();
      console.log(response, "kpi");
      pager = {
        ...pager,
        ...response,
      };
      ///////////////////////////////////////////////////////////
      console.log(pager, "lpg");
      setPage({ ...pager, ...response });
    };
    loadPage();
  }, []);

  return (
    <>
      {page && (
        <Box sx={{ width: "100%" }}>
          <Stack spacing={2}>
            <Item>
              <Box
                sx={{
                  display: "flex",
                  gap: 2,
                  justifyContent: "space-between",
                }}
              >
                <Box>
                  <Typography
                    sx={{ textTransform: "none" }}
                    variant="button"
                    display="block"
                    gutterBottom
                  >
                    Vulnerable Subdomains
                  </Typography>
                  <Divider />
                  <EnhancedTable
                    checkbox={false}
                    rows={page.vulnerable ? page.vulnerable : []}
                    headCells={vulnerableheadCells}
                    cols={1}
                  />
                </Box>
                <Box>
                  <Typography
                    sx={{ textTransform: "none" }}
                    variant="button"
                    display="block"
                    gutterBottom
                  >
                    Common Vulnerabilities
                  </Typography>
                  <Divider />
                  <EnhancedTable
                    checkbox={false}
                    rows={page.common ? page.common : []}
                    headCells={commonheadCells}
                    cols={2}
                  />
                </Box>
              </Box>
            </Item>
            <Item>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  Vulnerability Highlights
                </Typography>
                <Divider />
                <EnhancedTable
                  checkbox={false}
                  rows={page.vulnerability_highlight}
                  headCells={highlightheadCells}
                  cols={3}
                />
              </Box>
            </Item>
            <Item>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  Vulnerabilities
                </Typography>
                <Divider />
                <CollapsibleTable rows={page.vulnerabilities} />
              </Box>
            </Item>
            <Box
              sx={{
                display: "flex",
                gap: 2,
                justifyContent: "center",
              }}
            >
              <ScatterPlot plot={page.heatmap} />
            </Box>
            <Item>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  URLs
                </Typography>
                <Divider />
                <EnhancedTable
                  checkbox={false}
                  add={true}
                  point={"techs"}
                  rows={page.endpoints}
                  headCells={urlheadCells}
                  cols={5}
                  setSelectedRows={setSelectedScans}
                />
              </Box>
            </Item>
          </Stack>
        </Box>
      )}
    </>
  );
};

export default KPI;
