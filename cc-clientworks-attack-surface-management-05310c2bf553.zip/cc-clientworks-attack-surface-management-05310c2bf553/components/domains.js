"use client";
import * as React from "react";
import { useContext, useEffect } from "react";
import { useState } from "react";
import { ASMTContext } from "../contexts/ASMTContext";
import { Divider } from "@mui/material";
import PropTypes from "prop-types";
import { alpha } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import { EnhancedTable } from "./table";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import Container from "@mui/material/Container";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import FilterListIcon from "@mui/icons-material/FilterList";
import { visuallyHidden } from "@mui/utils";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import SendIcon from "@mui/icons-material/Send";
import Stack from "@mui/material/Stack";
import Drawer from "./drawer";
import { Details, Item } from "./details";

function EnhancedTableHead(props) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
  } = props;

  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        <TableCell
          sx={{ backgroundColor: "black", color: "white", fontSize: 14 }}
          padding="checkbox"
        >
          <Checkbox
            color="primary"
            indeterminate={numSelected > 0 && numSelected < rowCount}
            checked={true}
            onClick={onSelectAllClick}
            inputProps={{
              "aria-label": "select all desserts",
            }}
          />
        </TableCell>
        {headCells.map((headCell) => (
          <TableCell
            sx={{ backgroundColor: "black", color: "white", fontSize: 14 }}
            key={headCell.id}
            align={"left"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(["asc", "desc"]).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

const TableMade = (props) => {
  const [open, setOpen] = React.useState(false);
  const [count, setCount] = React.useState(0);
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);

  const { rows, domainHeadCells, setSelectedRows, returning, checkbox, cols } =
    props;

  console.log(
    rows,
    domainHeadCells,
    setSelectedRows,
    returning,
    checkbox,
    cols,
    "seva"
  );

  function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  }

  function getComparator(order, orderBy) {
    return order === "desc"
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  }

  function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) {
        return order;
      }
      return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
  }

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (selected.length > 0) {
      setSelected([]);
      return;
    }
    const newSelected = rows.map((n) => n.id);
    setSelected(newSelected);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    setSelected(newSelected);
  };

  const isSelected = (name) => selected.indexOf(name) !== -1;

  const visibleRows = React.useMemo(
    () => stableSort(rows, getComparator(order, orderBy)),
    [order, orderBy]
  );

  return (
    <>
      <Box sx={{ display: "flex", gap: 2 }}>
        <Box sx={{ width: "50%" }}>
          <Typography
            sx={{ textTransform: "none" }}
            variant="button"
            display="block"
            gutterBottom
          >
            All Targets
          </Typography>
          <Divider />
          <Paper sx={{ mb: 2 }}>
            <EnhancedTable
              checkbox={checkbox}
              rows={rows}
              headCells={domainHeadCells}
              cols={cols}
              setSelectedRows={setSelected}
              returning={returning}
            />
          </Paper>
        </Box>
        <Box sx={{ width: "50%" }}>
          <Drawer
            targetSelect={selected}
            anchor="right"
            open={open}
            close={setOpen}
          />
        </Box>
      </Box>
    </>
  );
};

const Domains = () => {
  const [rows, setRows] = React.useState();
  const [selectedDomains, setSelectedDomains] = useState([]);
  const { orgId, site, token } = useContext(ASMTContext);
  const domainHeadCells = [
    {
      id: "target",
      numeric: false,
      disablePadding: true,
      label: "Target",
    },
    {
      id: "description",
      numeric: false,
      disablePadding: false,
      label: "Description",
    },
    {
      id: "addedOn",
      numeric: false,
      disablePadding: false,
      label: "Added On",
    },
    {
      id: "lastScanned",
      numeric: false,
      disablePadding: false,
      label: "Last Scanned",
    },
  ];

  useEffect(() => {
    async function getData() {
      let obj = {};
      obj.apiId = "listTargets";
      obj.token = token;
      obj.rengine_org_id = orgId.rengine_org_id;
      console.log(obj, "obj");
      let response = await fetch(site, {
        method: "post",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
      });

      response = await response.json();
      console.log(response, "rsp");
      const results = response.results;
      var rowData = [];
      for (var i in results) {
        rowData.push({
          id: results[i].id,
          target: results[i].name,
          description: results[i]?.description,
          addedOn: results[i].insert_date_humanized,
          lastScanned: results[i]?.start_scan_date_humanized,
        });
      }
      setRows(rowData);
      console.log(rowData, "@tgt");
    }
    getData();
  }, []);

  return (
    <>
      {rows && (
        <Box sx={{ width: "100%" }}>
          <Stack spacing={2}>
            <Item>
              <TableMade
                rows={rows}
                domainHeadCells={domainHeadCells}
                returning={"id"}
                setSelectedRows={setSelectedDomains}
                checkbox={true}
                cols={3}
              ></TableMade>
            </Item>
          </Stack>
        </Box>
      )}
    </>
  );
};

export default Domains;
