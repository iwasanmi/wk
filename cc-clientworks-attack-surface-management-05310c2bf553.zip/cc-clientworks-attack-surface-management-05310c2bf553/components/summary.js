import React, { useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Divider } from "@mui/material";
import Stack from "@mui/material/Stack";
import { ASMTContext } from "../contexts/ASMTContext";
import Chip from "@mui/material/Chip";
import { useContext, useEffect } from "react";
import { styled } from "@mui/material/styles";
import { Button } from "@mui/material";
import { TextField } from "@mui/material";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import { Paper } from "@mui/material";

import {
  ChartComponent,
  SeriesCollectionDirective,
  SeriesDirective,
  Inject,
  Legend,
  Category,
  Tooltip,
  DataLabel,
  ColumnSeries,
} from "@syncfusion/ej2-react-charts";
import { EnhancedTable } from "./table";

import MuiAlert from "@mui/material/Alert";

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

// in miliseconds
var units = {
  year: 24 * 60 * 60 * 1000 * 365,
  month: (24 * 60 * 60 * 1000 * 365) / 12,
  day: 24 * 60 * 60 * 1000,
  hour: 60 * 60 * 1000,
  minute: 60 * 1000,
  second: 1000,
};

const columnData = [
  { country: "US", gold: 32 },
  { country: "GOA", gold: 44 },
  { country: "RSA", gold: 88 },
  { country: "MUM", gold: 68 },
  { country: "PN", gold: 60 },
  { country: "SI", gold: 75 },
];
function ColumnChart(props) {
  const { columnData } = props;
  const primaryxAxis = { valueType: "Category" };
  const primaryyAxis = {
    minimum: 0,
    maximum: 30,
    interval: 5,
  };
  console.log("asiu");
  return (
    <Box sx={{ height: "300px" }}>
      <ChartComponent
        id="charts"
        primaryXAxis={primaryxAxis}
        primaryYAxis={primaryyAxis}
        title="HTTP Status Breakdown"
      >
        <Inject
          services={[ColumnSeries, Legend, Tooltip, DataLabel, Category]}
        />
        <SeriesCollectionDirective>
          <SeriesDirective
            dataSource={columnData}
            xName="http_status"
            yName="http_status__count"
            name="Status Code"
            type="Column"
          ></SeriesDirective>
        </SeriesCollectionDirective>
      </ChartComponent>
    </Box>
  );
}
// //////////////////////////////////

export const Item = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  color: theme.palette.text.secondary,
}));
import { BubbleMaps } from "./dashboard";

const Summary = () => {
  const { orgId, site, siteV2, token, target, setTarget } =
    useContext(ASMTContext);

  const [selectedScans, setSelectedScans] = useState([]);
  const [empty, setEmpty] = useState(false);
  const [selectedHistoricIP, setSelectedHistoricIP] = useState([]);
  const [info, setInfo] = useState("domain");

  let obj = {};
  obj.token = token;
  // obj.rengine_org_id = "default";
  obj.rengine_org_id = orgId.rengine_org_id;
  let domain;
  let pager = {};

  const [page, setPage] = useState();
  const [geo, setGeo] = useState();
  const [column, setColumn] = useState();
  const getApi = async () => {
    console.log(obj, "obj");
    let response = await fetch(site, {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(obj),
    });
    response = await response.json();
    return response;
  };

  const callApiV2 = async () => {
    console.log(obj, "obj");
    let response = await fetch(siteV2, {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(obj),
    });
    response = await response.json();
    console.log(response, "v2a");
    return response;
  };
  const viewSummary = async () => {
    obj.apiId = `/api/get/summary?id=${domain}`;
    obj.method = "get";
    let response = await callApiV2();
    if (response.historical_ips && response.historical_ips.length > 0) {
      let ipId = response.historical_ips[0].id;
      setSelectedHistoricIP([ipId]);
    }
    pager = { ...response, ...pager };
    ////////////////////////////////
    let geo_ip = response.asset_countries.map((element) => {
      return {
        color: `blue`,
        name: `${element.name}`,
        count: `${element.count}`,
      };
    });
    setGeo(geo_ip);
    ///////////////////////////////////
    setColumn(response.http_status_breakdown);
    ///////////////////////////////////
    obj.apiId = `/api/queryIps/?target_id=${domain}`;
    obj.method = "get";
    response = await callApiV2();
    pager = { ...response, ...pager };
    ///////////////////////////////////
    obj.apiId = `/api/queryPorts/?target_id=${domain}`;
    obj.method = "get";
    response = await callApiV2();
    pager = { ...response, ...pager };
    ///////////////////////////////////
    obj.apiId = `/api/queryTechnologies/?target_id=${domain}`;
    obj.method = "get";
    response = await callApiV2();
    pager = { ...response, ...pager };
    // console.log(pager, "res");
    ///////////////////////////////////
  };
  const updateTarget = async (event) => {
    console.log(page, "ss");
    obj.apiId = `/api/update/target`;
    obj.method = "post";
    obj.params = target;
    let response = await callApiV2();
    console.log(response, target, "joo");
  };

  const updateSummary = async () => {
    domain = selectedScans[selectedScans.length - 1];
    console.log(domain, selectedScans, "upd");
    if (domain) {
      setTarget({ ...target, id: domain });
      await viewSummary();
      pager = { ...pager, host: page.host };
      console.log(pager, domain, { ...target, id: domain }, "do");
      setPage(pager);
    }
  };

  const handleText = async (event) => {
    setTarget({
      [event.target.id]: event.target.value,
    });
  };
  const stopScan = async () => {
    obj.apiId = `/api/action/stop/scan/`;
    obj.method = "post";
    selectedScans.forEach(async (id) => {
      obj.params = { scan_id: id };
      let response = await callApiV2();
      console.log(response, "v2c");
    });
  };
  useEffect(() => {
    const loadPage = async () => {
      obj.apiId = "getScans";
      let response = await getApi();
      console.log(response, "dyy");
      pager = { ...response };
      ///////////////////////////////
      let host = response.host;
      if (host.length > 0) {
        if (target?.id) domain = target.id;
        else domain = response.host[0].domain;
        // setSelectedScans([domain]);
        setTarget({ id: domain });
        await viewSummary();
        console.log(pager, "re");

        if (pager.domain_info == undefined) {
          pager.historical_ips = [];
          pager.nameservers = [];
          pager.dns_records = [];
        }
        setPage(pager);
      } else {
        setEmpty(true);
      }
    };
    loadPage();
  }, []);
  // ////////////////////////
  {
    function createData(obj) {
      return obj;
      //   return {
      // id,
      // name,
      // calories,
      // fat,
      // carbs,
      // protein,
      //   };
    }
  }
  const rows = [
    {
      id: 1,
      name: "Cupcake",
      engine: 305,
      status: 3.7,
      carbs: 67,
      protein: 4.3,
    },
    {
      id: 2,
      name: "Donut",
      engine: 452,
      status: 25.0,
      carbs: 51,
      protein: 4.9,
    },
    {
      id: 3,
      name: "Eclair",
      engine: 262,
      status: 16.0,
      carbs: 24,
      protein: 6.0,
    },
    {
      id: 4,
      name: "Frozen yoghurt",
      engine: 159,
      status: 6.0,
      carbs: 24,
      protein: 4.0,
    },
    {
      id: 5,
      name: "Gingerbread",
      engine: 356,
      status: 16.0,
      carbs: 49,
      protein: 3.9,
    },
    {
      id: 6,
      name: "Honeycomb",
      engine: 408,
      status: 3.2,
      carbs: 87,
      protein: 6.5,
    },
    {
      id: 7,
      name: "Ice cream sandwich",
      engine: 237,
      status: 9.0,
      carbs: 37,
      protein: 4.3,
    },
    {
      id: 8,
      name: "Jelly Bean",
      engine: 375,
      status: 0.0,
      carbs: 94,
      protein: 0.0,
    },
    {
      id: 9,
      name: "KitKat",
      engine: 518,
      status: 26.0,
      carbs: 65,
      protein: 7.0,
    },
    {
      id: 10,
      name: "Lollipop",
      engine: 392,
      status: 0.2,
      carbs: 98,
      protein: 0.0,
    },
    {
      id: 11,
      name: "Marshmallow",
      engine: 318,
      status: 2.0,
      carbs: 81,
      protein: 2.0,
    },
    {
      id: 12,
      name: "Nougat",
      engine: 360,
      status: 19.0,
      carbs: 9,
      protein: 37.0,
    },
    {
      id: 13,
      name: "Oreo",
      engine: 437,
      status: 18.0,
      carbs: 63,
      protein: 4.0,
    },
  ];
  const scanheadCells = [
    {
      id: "name",
      numeric: false,
      disablePadding: true,
      label: "Name",
    },
    {
      id: "engine",
      numeric: false,
      disablePadding: false,
      label: "Engine",
    },
    {
      id: "scan_status",
      numeric: false,
      disablePadding: false,
      label: "Status",
    },
  ];
  const historicalheadCells = [
    {
      id: "ip",
      numeric: false,
      disablePadding: true,
      label: "Ip",
    },
    {
      id: "location",
      numeric: false,
      disablePadding: false,
      label: "Location",
    },
    {
      id: "owner",
      numeric: false,
      disablePadding: false,
      label: "Owner",
    },
    {
      id: "last_seen",
      numeric: false,
      disablePadding: false,
      label: "Last Seen",
    },
  ];
  // ////////////////////////
  return (
    <>
      {page && (
        <Stack spacing={2}>
          <Item>
            <Box sx={{ display: "flex", gap: 2 }}>
              <Box sx={{ width: "50%" }}>
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  All Scans
                </Typography>
                <Divider />
                <Box sx={{ width: "100%" }}>
                  <EnhancedTable
                    checkbox={true}
                    rows={page.host}
                    headCells={scanheadCells}
                    cols={2}
                    setSelectedRows={setSelectedScans}
                    returning={"domain"}
                  />
                  <Button disabled size="small" onClick={stopScan}>
                    Stop
                  </Button>
                </Box>
              </Box>
              <Box sx={{ flexGrow: 1 }}>
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  Update Target
                </Typography>
                <Divider />
                <TextField
                  id="name"
                  label="Domain name"
                  disabled={true}
                  fullWidth
                  value={page.target.name}
                  variant="standard"
                />
                <TextField
                  id="h1_team_handle"
                  label="Description (Optional)"
                  fullWidth
                  onChange={(event) => {
                    handleText(event);
                  }}
                  value={page.target.h1_team_handle}
                  variant="standard"
                />
                <TextField
                  id="description"
                  label="HackerOne Target Team Handle"
                  fullWidth
                  helperText="This is used to send vulnerability reports to the HackerOne Program automatically. Team handle can be found from the program URL, hackerone.com/team_handle."
                  variant="standard"
                  onChange={(event) => {
                    handleText(event);
                  }}
                  value={page.target.description}
                />
                <TextField
                  id="ip_address_cidr"
                  label="IP Address or CIDR"
                  fullWidth
                  helperText="Example: 192.168.1.1 or 192.168.1.1/24, both are supported"
                  variant="standard"
                  onChange={(event) => {
                    handleText(event);
                  }}
                  value={
                    page.target.ip_address_cidr == null
                      ? ""
                      : page.target.ip_address_cidr
                  }
                />
                <Box sx={{ display: "flex", gap: 1 }}>
                  <Button size="small" onClick={updateTarget}>
                    Save
                  </Button>
                  <Button size="small" onClick={updateSummary}>
                    View Summary
                  </Button>
                </Box>
              </Box>
            </Box>
          </Item>
          <Item>
            <Box sx={{ textAlign: "center" }}>
              <Typography
                sx={{ textTransform: "none" }}
                variant="button"
                display="block"
                gutterBottom
              >
                Summary
              </Typography>
              <Divider />
            </Box>
            <Box sx={{ display: "flex", gap: 2, alignItems: "baseline", m: 1 }}>
              <Paper
                sx={{
                  width: "15rem",
                  padding: 1,
                }}
              >
                <Box
                  sx={{
                    color: "white",
                    backgroundColor: "black",
                    padding: 1,
                    borderRadius: 1,
                    mb: 1,
                  }}
                >
                  <Typography
                    sx={{ textTransform: "none", fontWeight: "bold" }}
                    variant="button"
                    display="block"
                    // variant="h6"
                    component="h6"
                  >
                    Last Scan{" "}
                  </Typography>
                  <Typography
                    variant="button"
                    display="block"
                    sx={{ textTransform: "none" }}
                  >
                    {page.target.last_scan}
                  </Typography>
                  <Divider />
                </Box>
                <Box sx={{ flexGrow: 1 }}>
                  <Typography
                    sx={{ textTransform: "none", fontWeight: "bold" }}
                    variant="button"
                    display="block"
                  >
                    Times target is scanned
                  </Typography>
                  <Typography
                    variant="button"
                    display="block"
                    sx={{ textTransform: "none", textAlign: "center" }}
                  >
                    {page.scan_count}
                  </Typography>
                  <Typography
                    sx={{ textTransform: "none", fontSize: "10px" }}
                    variant="button"
                    display="block"
                  >
                    {page.this_week_scan_count} Scans this week
                  </Typography>
                  <Divider />
                  <Typography
                    sx={{ textTransform: "none", fontWeight: "bold" }}
                    variant="button"
                    display="block"
                  >
                    Subdomains Discovered
                  </Typography>
                  <Typography
                    variant="button"
                    display="block"
                    sx={{ textTransform: "none", textAlign: "center" }}
                  >
                    {page.subdomain_count}
                  </Typography>
                  <Typography
                    sx={{ textTransform: "none", fontSize: "10px" }}
                    variant="button"
                    display="block"
                  >
                    Alive Subdomains: {page.alive_count}
                  </Typography>
                  <Divider />
                  <Typography
                    sx={{ textTransform: "none", fontWeight: "bold" }}
                    variant="button"
                    display="block"
                  >
                    Endpoints Discovered
                  </Typography>
                  <Typography
                    variant="button"
                    display="block"
                    sx={{ textTransform: "none", textAlign: "center" }}
                  >
                    {page.endpoint_count}
                  </Typography>
                  <Typography
                    sx={{ textTransform: "none", fontSize: "10px" }}
                    variant="button"
                    display="block"
                  >
                    Alive Endpoints: {page.endpoint_alive_count}
                  </Typography>
                  <Divider />
                  <Typography
                    sx={{ textTransform: "none", fontWeight: "bold" }}
                    variant="button"
                    display="block"
                  >
                    Vulnerabilities Discovered
                  </Typography>
                  <Typography
                    variant="button"
                    display="block"
                    sx={{ textTransform: "none", textAlign: "center" }}
                  >
                    {page.vulnerability_count}
                  </Typography>
                  <Typography
                    sx={{
                      textTransform: "none",
                      lineHeight: 1.2,
                      fontSize: "10px",
                    }}
                    variant="button"
                    display="block"
                  >
                    {page.critical_count} Critical, {page.high_count} High,{" "}
                    {page.medium_count} Medium
                  </Typography>
                  <Typography
                    sx={{
                      textTransform: "none",
                      lineHeight: 1.2,
                      fontSize: "10px",
                    }}
                    variant="button"
                    display="block"
                  >
                    {page.low_count} Low, {page.info_count} Info Vulnerabilities
                  </Typography>
                </Box>
              </Paper>
              <Box sx={{ width: "100%" }}>
                <Tabs
                  value={info}
                  onChange={(event, value) => {
                    if (value == 1) setInfo("historical_ips");
                    else if (value == 2) setInfo("extra");
                    else setInfo("domain");
                  }}
                  centered
                >
                  <Tab
                    sx={{ borderBottom: info == "domain" ? 2 : 0 }}
                    label="Domain Info"
                  />
                  <Tab
                    sx={{ borderBottom: info == "historical_ips" ? 2 : 0 }}
                    label="Historical IPs"
                  />
                  <Tab
                    sx={{ borderBottom: info == "extra" ? 2 : 0 }}
                    label="Extra"
                  />
                </Tabs>
                {info == "domain" && (
                  <>
                    {" "}
                    <Box
                      sx={{
                        display: "flex",
                        gap: 5,
                        p: 3,
                        justifyContent: "space-between",
                      }}
                      role="tabpanel"
                    >
                      <Box sx={{ flexGrow: 1 }}>
                        <Stack>
                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            {" "}
                            <Box>Domain : </Box>
                            <Box sx={{ fontWeight: "bold" }}>
                              {page.target?.name}
                            </Box>
                          </Item>
                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            {" "}
                            <Box>Dnssec : </Box>
                            {page.domain_info && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.domain_info[0].dnssec}
                              </Box>
                            )}
                          </Item>
                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            {" "}
                            <Box>Geolocation : </Box>
                            {page.domain_info && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.domain_info[0]?.geolocation_iso}
                              </Box>
                            )}
                          </Item>
                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            {" "}
                            <Box>Created : </Box>
                            {page.domain_info && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.domain_info[0]?.created}
                              </Box>
                            )}
                          </Item>
                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            {" "}
                            <Box>Updated : </Box>
                            {page.domain_info && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.domain_info[0]?.updated}
                              </Box>
                            )}
                          </Item>
                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            {" "}
                            <Box>Expires : </Box>
                            {page.domain_info && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.domain_info[0]?.expires}
                              </Box>
                            )}
                          </Item>
                        </Stack>
                      </Box>
                      <Box sx={{ border: 1 }}></Box>
                      <Box sx={{ flexGrow: 1 }}>
                        <Stack>
                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            <Box>Whois Server : </Box>
                            {page.domain_info && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.domain_info[0]?.whois_server}
                              </Box>
                            )}
                          </Item>

                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            <Box>Registrar Name : </Box>
                            {page.registrar && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.registrar[0]?.name}
                              </Box>
                            )}
                          </Item>

                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            <Box>Registrar Phone : </Box>
                            {page.registrar && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.registrar[0]?.phone}
                              </Box>
                            )}
                          </Item>

                          <Item
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                            }}
                          >
                            <Box>Registrar Email : </Box>
                            {page.registrar && (
                              <Box sx={{ fontWeight: "bold" }}>
                                {page.registrar[0]?.email}
                              </Box>
                            )}
                          </Item>
                        </Stack>
                      </Box>
                    </Box>
                    <Box>
                      <Typography
                        sx={{ textTransform: "none" }}
                        variant="button"
                        display="block"
                        gutterBottom
                      >
                        Whois
                      </Typography>
                      <Divider />
                      <Stack>
                        <Box>
                          Name :
                          {page.registrant && (
                            <span style={{ fontWeight: "bold" }}>
                              {" "}
                              {page.registrant[0]?.name}
                            </span>
                          )}
                        </Box>
                        <Box>
                          Organization :
                          {page.registrant && (
                            <span style={{ fontWeight: "bold" }}>
                              {" "}
                              {page.registrant[0]?.organization}
                            </span>
                          )}
                        </Box>
                        <Box>
                          Email :
                          {page.registrant && (
                            <span style={{ fontWeight: "bold" }}>
                              {page.registrant[0]?.email}
                            </span>
                          )}
                        </Box>
                        <Box>
                          Phone/Fax :
                          {page.registrant && (
                            <span style={{ fontWeight: "bold" }}>
                              {" "}
                              {page.registrant[0]?.phone}
                            </span>
                          )}
                        </Box>
                        <Box>
                          Address :
                          {page.registrant && (
                            <span style={{ fontWeight: "bold" }}>
                              {" "}
                              {page.registrant[0]?.address}
                            </span>
                          )}
                        </Box>
                        <Box>
                          Address :
                          {page.registrant && (
                            <span style={{ fontWeight: "bold" }}>
                              City : {page.registrant[0]?.city} State :{" "}
                              {page.registrant[0]?.state} Zip Code :{" "}
                              {page.registrant[0]?.zip_code} Country :{" "}
                              {page.registrant[0]?.country}
                            </span>
                          )}
                        </Box>
                      </Stack>
                    </Box>
                  </>
                )}
                {info == "historical_ips" && (
                  <Box role="tabpanel">
                    <EnhancedTable
                      checkbox={false}
                      rows={page.historical_ips}
                      headCells={historicalheadCells}
                      cols={3}
                      setSelectedRows={setSelectedHistoricIP}
                    />
                  </Box>
                )}
                {info == "extra" && (
                  <Box role="tabpanel">
                    <Typography
                      sx={{ textTransform: "none" }}
                      variant="button"
                      display="block"
                      gutterBottom
                    >
                      Nameservers
                    </Typography>
                    {page.nameservers.map((ns) => {
                      return (
                        <Chip
                          sx={{ m: 1 }}
                          label={ns.name}
                          variant="outlined"
                        />
                      );
                    })}
                    <Divider />
                    <Typography
                      sx={{ textTransform: "none" }}
                      variant="button"
                      display="block"
                      gutterBottom
                    >
                      DNS Records
                    </Typography>
                    {page.dns_records.map((rs) => {
                      return (
                        <Chip
                          sx={{ m: 1 }}
                          label={`${rs.name} | ${rs.type}`}
                          onClick={() => {}}
                        />
                      );
                    })}
                  </Box>
                )}
              </Box>
            </Box>
          </Item>
          <Item>
            <Paper
              sx={{
                display: "flex",
                gap: 2,
                height: "300px",
                p: 1,
                justifyContent: "center",
              }}
            >
              <Box sx={{ width: "60%" }}>
                <BubbleMaps id={"target-geoip"} data={geo} />
              </Box>
              <Box sx={{ width: "35%" }}>
                <ColumnChart columnData={column} />
              </Box>
            </Paper>
          </Item>
          <Item>
            <Box
              sx={{
                display: "flex",
                flexWrap: "wrap",
                justifyContent: "space-around",
              }}
            >
              <Box sx={{ width: "300px" }}>
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  {`${page.ips.length} | IP Addresses`}
                </Typography>
                {"  "}*IP Addresses highlighted with yellow are CDN IP
                <Divider />
                {page.ips.map((element) => {
                  return (
                    <Chip
                      sx={{
                        backgroundColor: "black",
                        color: element.is_cdn ? "yellow" : "white",
                        m: 0.5,
                      }}
                      label={element.address}
                      onClick={() => {}}
                    />
                  );
                })}
              </Box>
              <Box sx={{ width: "300px" }}>
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  {`${page.ports.length} | Discovered Ports`}
                </Typography>
                {"  "}*Ports highlighted with red are uncommon Ports
                <Divider />
                {page.ports.map((element) => {
                  return (
                    <Chip
                      sx={{
                        backgroundColor: "black",
                        color: element.is_uncommon ? "red" : "white",
                        m: 0.5,
                      }}
                      label={element.number}
                      onClick={() => {}}
                    />
                  );
                })}
              </Box>
              <Box sx={{ width: "300px" }}>
                <Typography
                  sx={{ textTransform: "none" }}
                  variant="button"
                  display="block"
                  gutterBottom
                >
                  {`${page.technologies.length} | Discovered Technologies`}
                </Typography>
                <Divider />
                {page.technologies.map((element) => {
                  return (
                    <Chip
                      sx={{
                        backgroundColor: "black",
                        color: "white",
                        m: 0.5,
                      }}
                      label={element.name}
                      onClick={() => {}}
                    />
                  );
                })}
              </Box>
            </Box>
          </Item>
        </Stack>
      )}
      {empty && (
        <>
          <Stack spacing={2} sx={{ width: "100%" }}>
            <Alert fullWidth severity="info">
              No data to show!
            </Alert>
          </Stack>
        </>
      )}
    </>
  );
};

export default Summary;
