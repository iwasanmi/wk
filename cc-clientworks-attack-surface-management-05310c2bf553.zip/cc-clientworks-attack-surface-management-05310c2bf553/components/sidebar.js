import React from "react";

import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import List from "@mui/material/List";
import Divider from "@mui/material/Divider";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListSubheader from "@mui/material/ListSubheader";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import { Paper } from "@mui/material";
import { useState } from "react";
import { ASMTContext } from "../contexts/ASMTContext";
import { useContext } from "react";

const Sidebar = () => {
  let { currentComponent, setCurrentComponent, target, setTarget } =
    useContext(ASMTContext);
  const handleChange = (event, text) => {
    console.log(event, text, "evt");
    setCurrentComponent(text);
  };

  return (
    <>
      <div>
        <Box
          sx={{ width: 250 }}
          role="presentation"
          // onClick={toggleDrawer(anchor, false)}
          // onKeyDown={toggleDrawer(anchor, false)}
        >
          <List>
            {["DashBoard"].map((text, index) => (
              <ListItem key={text} disablePadding>
                <ListItemButton
                  onClick={(event) => handleChange(event, text)}
                  selected={currentComponent === text}
                >
                  <ListItemIcon>
                    {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                  </ListItemIcon>
                  <ListItemText primary={text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
          <Divider />
          <List subheader={<ListSubheader>Report</ListSubheader>}>
            <List>
              {
                <Box sx={{ backgroundColor: "black", color: "white" }}>
                  <ListItem key={"text"}>
                    <ListItemText primary={`Active Scans :   #`} />
                    <ListItemText primary={`Viewing :   ${target?.id}`} />
                  </ListItem>
                </Box>
              }
            </List>
            {[
              "Summary",
              "Deltas",
              "KPI",
              // ,"Integrations"
            ].map((text, index) => (
              <ListItem key={text} disablePadding>
                <ListItemButton
                  onClick={(event) => handleChange(event, text)}
                  disabled={target == null && text != "Summary"}
                  selected={currentComponent === text}
                >
                  <ListItemIcon>
                    {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                  </ListItemIcon>
                  <ListItemText primary={text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
          <Divider />
          <List subheader={<ListSubheader>Settings</ListSubheader>}>
            {[
              "Org Domains",
              "Security Settings",
              "Notifications",
              "Details",
            ].map((text, index) => (
              <ListItem key={text} disablePadding>
                <ListItemButton
                  onClick={(event) => handleChange(event, text)}
                  selected={currentComponent === text}
                >
                  <ListItemIcon>
                    {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                  </ListItemIcon>
                  <ListItemText primary={text} />
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </div>
    </>
  );
};

export default Sidebar;
