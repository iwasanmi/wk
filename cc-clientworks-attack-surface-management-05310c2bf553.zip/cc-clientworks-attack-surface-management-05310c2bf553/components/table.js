import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { alpha } from "@mui/material/styles";
import { Box } from "@mui/material";
import { Stack, Typography, Divider } from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Chip from "@mui/material/Chip";
import Toolbar from "@mui/material/Toolbar";
import Paper from "@mui/material/Paper";
import AccordionRow from "./kpi";
import Checkbox from "@mui/material/Checkbox";
import Tooltip from "@mui/material/Tooltip";
import IconButton from "@mui/material/IconButton";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import DeleteIcon from "@mui/icons-material/Delete";
import FilterListIcon from "@mui/icons-material/FilterList";
import Pagination from "@mui/material/Pagination";
import { visuallyHidden } from "@mui/utils";

// function createData(id, name, calories, fat, carbs, protein) {

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

// Since 2020 all major browsers ensure sort stability with Array.prototype.sort().
// stableSort() brings sort stability to non-modern browsers (notably IE11). If you
// only support modern browsers you can replace stableSort(exampleArray, exampleComparator)
// with exampleArray.slice().sort(exampleComparator)
function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}

const theme = createTheme({
  components: {
    MuiTableCell: {
      styleOverrides: {
        root: {
          color: "blue",
        },
      },
    },
  },
});

function EnhancedTableHead(props) {
  const {
    onSelectAllClick,
    order,
    orderBy,
    numSelected,
    rowCount,
    onRequestSort,
    headCells,
    checkbox,
  } = props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  const [hover, setHover] = useState();

  return (
    <TableHead>
      <TableRow>
        {checkbox && (
          <TableCell
            sx={{
              backgroundColor: "white",
              color: "white",
              fontSize: 14,
            }}
            onMouseEnter={() => {
              setHover(true);
            }}
            padding="checkbox"
          >
            <Checkbox
              color="primary"
              indeterminate={numSelected > 0 && numSelected < rowCount}
              checked={true}
              onChange={onSelectAllClick}
              inputProps={{
                "aria-label": "select all scans",
              }}
            />
          </TableCell>
        )}
        {headCells.map((headCell) => (
          <TableCell
            sx={{
              color: "secondary",
              backgroundColor: "white",
              "& .Mui-active": { color: "primary" },
              fontSize: 14,
            }}
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(["asc", "desc"]).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

export function EnhancedTable(props) {
  const {
    checkbox,
    rows,
    headCells,
    cols,
    setSelectedRows,
    returning,
    add,
    point,
  } = props;
  const Component = add;
  console.log(
    checkbox,
    rows,
    headCells,
    cols,
    setSelectedRows,
    returning,
    "ddd"
  );
  const cells = [];
  for (let i = 0; i < cols; i++) {
    cells.push(i + 1);
  }

  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState(returning);
  const [selected, setSelected] = React.useState([]);
  const [selectedReturn, setSelectedReturn] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [dense, setDense] = React.useState(false);
  const [message, setMessage] = React.useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  useEffect(() => {
    console.log(rows, "ss");
    if (rows.length == 0) {
      setMessage(true);
    }
  }, []);
  // let selectedReturn = [rows[0][returning]];
  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (selected.length > 0) {
      setSelected([]);
      setSelectedRows([]);
      return;
    }
    const newSelected = rows.map((n) => n.id);
    const returnSelected = rows.map((n) => n[returning]);
    setSelected(newSelected);
    setSelectedRows(returnSelected);
  };

  const handleClick = (event, id, property) => {
    const selectedIndex = selected.indexOf(id);
    const selectedReturnIndex = selectedReturn.indexOf(property);
    let newSelected = [];
    let returnSelected = [];

    if (selectedIndex === -1) {
      returnSelected = returnSelected.concat(selectedReturn, property);
      newSelected = newSelected.concat(selected, id);
    } else if (selectedIndex === 0) {
      returnSelected = returnSelected.concat(selectedReturn.slice(1));
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      returnSelected = returnSelected.concat(selectedReturn.slice(0, -1));
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      returnSelected = returnSelected.concat(
        selectedReturn.slice(0, selectedReturnIndex),
        selectedReturn.slice(selectedReturnIndex + 1)
      );
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    // if (selectedReturnIndex === -1) {
    //   // newSelected = newSelected.concat(selected, id);
    //   returnSelected = returnSelected.concat(selectedReturn, property);
    // } else if (selectedReturnIndex === 0) {
    //   returnSelected = returnSelected.concat(selectedReturn.slice(1));
    // } else if (selectedReturnIndex === selectedReturn.length - 1) {
    //   returnSelected = returnSelected.concat(selectedReturn.slice(0, -1));
    // } else if (selectedReturnIndex > 0) {
    //   returnSelected = returnSelected.concat(
    //     selectedReturn.slice(0, selectedReturnIndex),
    //     selectedReturn.slice(selectedReturnIndex + 1)
    //   );
    // }
    console.log(returnSelected, selectedReturnIndex, property, "dsdds");
    console.log(newSelected, selectedIndex, id, "dss");
    setSelected(newSelected);
    setSelectedReturn(returnSelected);
    setSelectedRows(returnSelected);
  };

  const handleChangePage = (event, newPage) => {
    console.log(newPage, "dd");
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleChangeDense = (event) => {
    setDense(event.target.checked);
  };

  const isSelected = (id) => selected.indexOf(id) !== -1;

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const visibleRows = React.useMemo(
    () =>
      stableSort(rows, getComparator(order, orderBy)).slice(
        page * rowsPerPage,
        page * rowsPerPage + rowsPerPage
      ),
    [order, orderBy, page, rowsPerPage]
  );

  function PageBar() {
    let count = Math.floor(rows.length / 5);
    if (rows.length % 5) {
      count = count + 1;
    }
    return (
      <Paper elevation={8}>
        <Box sx={{ display: "flex", width: "100%", margin: "5px" }}>
          <Pagination
            onChange={(event, value) => {
              setPage(value - 1);
              console.log(event.target.value, value);
            }}
            page={page + 1}
            count={count}
            shape="rounded"
          />
        </Box>
      </Paper>
    );
  }

  return (
    <>
      <TableContainer sx={{ width: "100%" }}>
        <Table aria-labelledby="tableTitle">
          <EnhancedTableHead
            numSelected={selected.length}
            order={order}
            orderBy={orderBy}
            onSelectAllClick={handleSelectAllClick}
            onRequestSort={handleRequestSort}
            rowCount={rows.length}
            headCells={headCells}
            checkbox={checkbox}
          />
          <TableBody>
            {visibleRows.map((row, index) => {
              const isItemSelected = isSelected(row.id);
              const labelId = `enhanced-table-checkbox-${index}`;
              console.log(row[point], "jrr");
              return (
                <>
                  {" "}
                  <TableRow
                    hover
                    onClick={(event) =>
                      handleClick(event, row.id, row[returning])
                    }
                    role="checkbox"
                    aria-checked={isItemSelected}
                    tabIndex={-1}
                    key={row.id}
                    selected={isItemSelected}
                    sx={{ cursor: "pointer" }}
                  >
                    {checkbox && (
                      <TableCell padding="checkbox">
                        <Checkbox
                          color="primary"
                          checked={isItemSelected}
                          inputProps={{
                            "aria-labelledby": labelId,
                          }}
                        />
                      </TableCell>
                    )}
                    <TableCell
                      component="th"
                      id={labelId}
                      scope="row"
                      padding="none"
                    >
                      {row[headCells[0].id]}
                    </TableCell>
                    {cells.map((cell) => {
                      return (
                        <TableCell color="green" align="right">
                          {row[headCells[cell].id]}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                  {add && (
                    <Accordion fullWidth>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2a-content"
                        id="panel2a-header"
                      >
                        <Typography>{"Tags"}</Typography>
                      </AccordionSummary>
                      <AccordionDetails>
                        {row[point].map((element) => {
                          return (
                            <Chip
                              sx={{
                                backgroundColor: "black",
                                color: "white",
                                m: 0.5,
                              }}
                              label={element.name}
                              onClick={() => {}}
                            />
                          );
                        })}
                      </AccordionDetails>
                    </Accordion>
                  )}
                </>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      {message && (
        <Box
          sx={{
            p: 1,
            textAlign: "center",
          }}
        >
          No data
        </Box>
      )}
      {!message && <TablePagination component={PageBar} />}
    </>
  );
}
