import React from "react";
import { useContext, useEffect, useState } from "react";
import { Box, Stack } from "@mui/material";
import { createTheme, ThemeProvider, styled } from "@mui/material/styles";
import { EnhancedTable } from "./table";
import { Button, Paper } from "@mui/material";
import Typography from "@mui/material/Typography";
import { Divider } from "@mui/material";
import { Item } from "./summary";
import { ASMTContext } from "../contexts/ASMTContext";
import { PieChart } from "./dashboard";

import {
  AccumulationChartComponent,
  AccumulationSeriesCollectionDirective,
  AccumulationSeriesDirective,
  AccumulationLegend,
  PieSeries,
  AccumulationDataLabel,
  AccumulationTooltip,
} from "@syncfusion/ej2-react-charts";

// function Piechart(props) {
//   const { variouspiedata } = props;
//   console.log(variouspiedata, "ddsad");
//   // let variouspiedata = props.variouspiedata;
//   // console.log(variouspiedata, "sasa");
//   return (
//     <AccumulationChartComponent
//       id={props.id}
//       title={props.title}
//       titleStyle={props.titleSettings}
//       ref={(pie) => (pie = pie)}
//       legendSettings={{
//         visible: true,
//       }}
//     >
//       <Inject
//         services={[
//           AccumulationLegend,
//           PieSeries,
//           AccumulationDataLabel,
//           AccumulationTooltip,
//         ]}
//       />
//       <AccumulationSeriesCollectionDirective>
//         <AccumulationSeriesDirective
//           dataSource={variouspiedata}
//           xName="x"
//           yName="y"
//           innerRadius="60%"
//         ></AccumulationSeriesDirective>
//       </AccumulationSeriesCollectionDirective>
//     </AccumulationChartComponent>
//   );
// }
import {
  ChartComponent,
  SeriesCollectionDirective,
  SeriesDirective,
  Inject,
  Legend,
  Category,
  DateTime,
  Tooltip,
  DataLabel,
  LineSeries,
} from "@syncfusion/ej2-react-charts";

function Linechart(props) {
  const data = [
    { scan_history__start_scan_date: 2000, total: 22, scan_history: "sd" },
    { scan_history__start_scan_date: 2001, total: 31, scan_history: "sd" },
    { scan_history__start_scan_date: 2002, total: 41, scan_history: "sd" },
    { scan_history__start_scan_date: 2003, total: 61, scan_history: "sd" },
    { scan_history__start_scan_date: 2004, total: 21, scan_history: "sd" },
  ];
  const { x, y, name, point } = props;
  console.log(x, y, name, point, "xlr");
  const primaryxAxis = { valueType: "DateTime", labelFormat: "ddMMM" };
  const primaryyAxis = { title: name };
  return (
    <ChartComponent
      id={name}
      primaryXAxis={primaryxAxis}
      primaryYAxis={primaryyAxis}
    >
      <Inject services={[LineSeries, Legend, Tooltip, DataLabel, DateTime]} />
      <SeriesCollectionDirective>
        <SeriesDirective
          dataSource={point}
          xName={x}
          yName={y}
          width={2}
          name={name}
          type="Line"
        ></SeriesDirective>
      </SeriesCollectionDirective>
    </ChartComponent>
  );
}

const CustomBox = styled(Box)(({ theme }) => ({
  "@global": {
    "*::-webkit-scrollbar": {
      width: "0.4em",
    },
    "*::-webkit-scrollbar-track": {
      "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
    },
    "*::-webkit-scrollbar-thumb": {
      backgroundColor: "rgba(0,0,0,.1)",
      outline: "1px solid slategrey",
    },
  },
}));

const Deltas = () => {
  const { orgId, site, siteV2, token, target, setTarget } =
    useContext(ASMTContext);

  let obj = {};
  obj.token = token;
  obj.rengine_org_id = orgId.rengine_org_id;
  // obj.rengine_org_id = "default";
  let pager = {};

  const [page, setPage] = useState();

  const urlheadCells = [
    {
      id: "name",
      numeric: false,
      disablePadding: true,
      label: "Subdomain",
    },
    {
      id: "ip_addresses__address",
      numeric: false,
      disablePadding: false,
      label: "IP",
    },
    {
      id: "ip_addresses__ports__number",
      numeric: false,
      disablePadding: false,
      label: "Port",
    },
    {
      id: "technologies__name",
      numeric: false,
      disablePadding: false,
      label: "Technology Discovered",
    },
  ];

  const callApiV2 = async () => {
    console.log(obj, "obj");
    let response = await fetch(siteV2, {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(obj),
    });
    response = await response.json();
    console.log(response, "v2a");
    return response;
  };

  useEffect(() => {
    const loadPage = async () => {
      console.log(target.id, "ee");
      obj.apiId = `/api/get/delta?id=${target.id}`;
      obj.method = "get";
      let response = await callApiV2();
      pager = { ...response };
      console.log(pager, "re");
      ///////////////////////////////////////////////////////////
      setPage(pager);
    };
    loadPage();
  }, []);

  return (
    <>
      {page && (
        <Box sx={{ width: "100%" }}>
          <Box>
            <Stack spacing={2}>
              <Item>
                <Box sx={{ display: "flex", gap: 2 }}>
                  <Box
                    sx={{
                      flexGrow: 1,
                      backgroundColor: "black",
                      color: "white",
                      borderRadius: 1,
                      p: 1,
                    }}
                  >
                    Change in Subdomain: <span>{page.change_in_subdomain}</span>
                  </Box>
                  <Box
                    sx={{
                      flexGrow: 1,
                      backgroundColor: "black",
                      color: "white",
                      borderRadius: 1,
                      p: 1,
                    }}
                  >
                    Change in Endpoint: <span>{page.change_in_endpoint}</span>
                  </Box>
                </Box>
              </Item>
              <Item>
                <CustomBox
                  sx={{
                    height: "400px",
                    display: "flex",
                    gap: 2,
                    mb: 2,
                    overflowY: "scroll",
                  }}
                >
                  <Box sx={{ flexGrow: 1, p: 1 }}>
                    <Linechart
                      x="scan_history__start_scan_date"
                      y="total"
                      name="Subdomain ^"
                      point={page.subdomain_delta}
                    />
                  </Box>
                  <Box sx={{ flexGrow: 1, p: 1 }}>
                    <Linechart
                      x="scan_history__start_scan_date"
                      y="total"
                      name="Endpoint ^"
                      point={page.endpoint_delta}
                    />
                  </Box>
                </CustomBox>
              </Item>
              <Item>
                <Paper sx={{ display: "flex", gap: 2 }}>
                  <PieChart
                    id="vulnerability_pbreakdown"
                    title="Vulnerabilities"
                    titleSettings={{
                      textStyle: { size: "14px", fontWeight: "700" },
                      textAlignment: "Near",
                    }}
                    variouspiedata={page.vulnerability_breakdown}
                  />
                </Paper>
              </Item>
              <Item>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <Typography
                    sx={{ textTransform: "none" }}
                    variant="button"
                    display="block"
                    gutterBottom
                  >
                    Open Connections
                  </Typography>
                  <Divider />
                  <EnhancedTable
                    checkbox={false}
                    rows={page.technology_stack}
                    headCells={urlheadCells}
                    cols={3}
                  />
                </Box>
              </Item>
            </Stack>
          </Box>
        </Box>
      )}
    </>
  );
};

export default Deltas;
