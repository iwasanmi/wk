import React from "react";
import { useEffect, useContext, useState } from "react";
import { ASMTContext } from "../contexts/ASMTContext";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import { MapAjax } from "@syncfusion/ej2-maps";
import PropTypes from "prop-types";
import Container from "@mui/material/Container";
import Tooltip from "@mui/material/Tooltip";
import InfoIcon from "@mui/icons-material/Info";
import {
  HeatMapComponent,
  Inject as heatMapInject,
  Legend as heatMapLegend,
  Tooltip as heatMapTooltip,
  Adaptor,
} from "@syncfusion/ej2-react-heatmap";
import { purple } from "@mui/material/colors";

import * as ReactDOM from "react-dom";
import {
  ChartComponent,
  SeriesCollectionDirective,
  SeriesDirective,
  Tooltip as chartsTooltip,
  Legend,
  Category,
  DataLabel,
  StackingColumnSeries,
  ColumnSeries,
} from "@syncfusion/ej2-react-charts";

import {
  MapsComponent,
  Inject,
  LayersDirective,
  Legend as MLegend,
  LayerDirective,
  Bubble,
  BubblesDirective,
  BubbleDirective,
  MapsTooltip,
} from "@syncfusion/ej2-react-maps";

import {
  AccumulationChartComponent,
  AccumulationSeriesCollectionDirective,
  AccumulationSeriesDirective,
  AccumulationLegend,
  PieSeries,
  AccumulationDataLabel,
  AccumulationTooltip,
} from "@syncfusion/ej2-react-charts";

import { DateTime, StackingAreaSeries } from "@syncfusion/ej2-react-charts";
const Item = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: 1,
  textAlign: "center",
  color: theme.palette.text.secondary,
  background: "transparent",
}));

const Div = styled(Paper)(({ theme }) => ({
  [theme.breakpoints.down("md")]: {
    minWidth: "100%",
  },
}));

export const BubbleMaps = (props) => {
  let template =
    '<div id="bubbletooltiptemplate" style="width: 165px;background: rgba(53, 63, 76, 0.90); opacity: 90%;background: rgba(53, 63, 76, 0.90);box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.40);padding: 10px;border: 1px #abb9c6;border-radius: 4px;">' +
    '<div style="font-size:13px;color:#ffffff;font-weight: 500;"><center>${name}</center></div>' +
    '<hr style="margin-top: 2px;margin-bottom:5px;border:0.5px solid #DDDDDD">' +
    '<div><span style="font-size:13px;color:#cccccc">Count : </span><span style="font-size:13px;color:#ffffff;font-weight: 500;">${count}</span></div></div>';
  const bubbleRendering = (args) => {
    args.radius = args.data.count;
  };
  let datasource = props.data;
  // useEffect(() => {
  //   try {
  //     console.log("error");
  //   } catch (error) {
  //     console.log(error);
  //   }
  // });
  console.log(datasource, "datasource");
  return (
    <MapsComponent
      height="210px"
      id={props.id}
      mapsArea={{
        background: "#FAF9F6",
        display: "block",
      }}
      // onMouseMove={() => {
      //   try {
      //     console.log("move");
      //   } catch (error) {
      //     console.log(error);
      //   }
      // }}
      bubbleRendering={bubbleRendering}
      // titleSettings={{
      //   text: 'Maps Component',
      //   color: 'red',
      //   fontStyle: 'italic',
      //   fontWeight: 'regular',
      //   fontFamily: 'arial',
      //   size: '14px'
      // }}
      titleSettings={{
        text: "Geo-IP Assets",
        textStyle: {
          size: "14px",
          fontWeight: "700",
          // padding: "5px",
        },
        alignment: "Left",
        // textAlignment: "Near",
      }}
    >
      <Inject services={[Bubble, MapsTooltip]} />
      <LayersDirective>
        <LayerDirective
          shapeData={new MapAjax("./map-data/world-map.json")}
          shapeDataPath="name"
          shapePropertyPath="name"
          dataSource={datasource}
          shapeSettings={{ fill: "#E5E5E5" }}
        >
          <BubblesDirective>
            <BubbleDirective
              dataSource={datasource}
              visible={true}
              valuePath="count"
              colorValuePath="color"
              minRadius={3}
              maxRadius={70}
              opacity={0.8}
              tooltipSettings={{
                visible: true,
                valuePath: "count",
                template: template,
              }}
            />
          </BubblesDirective>
        </LayerDirective>
      </LayersDirective>
    </MapsComponent>
  );
};

function StackChart(props) {
  let stackColumndata = props.data;
  const primaryxAxis = { interval: 1, valueType: "Category" };
  const primaryyAxis = {
    labelFormat: "{value}",
  };
  return (
    <ChartComponent
      id="charts"
      primaryXAxis={primaryxAxis}
      primaryYAxis={primaryyAxis}
      title="Scan Trend Analysis"
      // titleSettings={{
      //   text: "Scan Trend Analysis",
      //   textStyle: { size: "14px", fontWeight: "700" },
      //   alignment: "left",
      // }}
      titleStyle={{
        // text: "Port Exposure Trend",
        size: "14px",
        fontWeight: "700",
        textAlignment: "Near",
      }}
    >
      <Inject services={[StackingColumnSeries, Legend, DataLabel, Category]} />
      <SeriesCollectionDirective>
        <SeriesDirective
          dataSource={stackColumndata}
          xName="month"
          yName="ip_domains"
          name="ip_domains"
          type="StackingColumn"
        ></SeriesDirective>
        <SeriesDirective
          dataSource={stackColumndata}
          xName="month"
          yName="vuls"
          name="vuls"
          type="StackingColumn"
        ></SeriesDirective>
      </SeriesCollectionDirective>
    </ChartComponent>
  );
}

function Card(props) {
  const { sx, ...other } = props;

  return (
    <Box
      sx={{
        p: 1,
        m: 1,
        width: 210,
        bgcolor: (theme) =>
          theme.palette.mode === "dark" ? "grey.300" : "#101010",
        opacity: 0.8,
        color: (theme) =>
          theme.palette.mode === "dark" ? "grey.300" : "white",
        border: "1px solid",
        borderColor: (theme) =>
          theme.palette.mode === "dark" ? "grey.800" : "grey.300",
        borderRadius: 2,
        fontSize: "0.875rem",
        fontWeight: "700",
        ...sx,
      }}
      {...other}
    ></Box>
  );
}

function HeatMap(props) {
  var heatmapData = props.data;
  var value = heatmapData.value;
  var xAxis = heatmapData.xAxis;
  var yAxis = heatmapData.yAxis;
  console.log(value, xAxis, yAxis, "pr");
  return (
    <>
      <HeatMapComponent
        titleSettings={{
          text: "Port versus Vulnerabilities",
          textStyle: {
            size: "15px",
            fontWeight: "500",
            fontStyle: "Normal",
            fontFamily: "Segoe UI",
            textAlignment: "Near",
          },
          // height: "250px",

          // alignment: "left",
        }} //https://ej2.syncfusion.com/react/documentation/heatmap-chart/appearance
        height={"250px"}
        xAxis={{
          //Data label
          labels: xAxis,
        }}
        yAxis={{
          labels: yAxis,
        }}
        cellSettings={{
          showLabel: false,
        }}
        dataSource={value}
      >
        <Inject services={[heatMapTooltip]} />
      </HeatMapComponent>
    </>
  );
}

const ColorButton = styled(Button)(({ theme }) => ({
  color: "white",
  backgroundColor: "white",
  "&:hover": {
    backgroundColor: purple[700],
  },
}));

Card.propTypes = {
  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: PropTypes.oneOfType([
    PropTypes.arrayOf(
      PropTypes.oneOfType([PropTypes.func, PropTypes.object, PropTypes.bool])
    ),
    PropTypes.func,
    PropTypes.object,
  ]),
};
{
  /* <Box
        sx={{ width: 150, height: 250, display: "flex", flexDirection: "row" }}
      >
        <div style={card}>
          <div>
            <InfoIcon style={{ color: "blue" }} />
          </div>
          <h4 style={h4}>Times Scanned</h4>
        </div>
        <div style={{ color: "blue", ...card }}>
          <div>
            <InfoIcon />
          </div>
          <h4 style={h4}>Vulnerabilities Discovered</h4>
          <div></div>
        </div>
        <div style={card}>
          <div>
            <InfoIcon style={{ color: "blue" }} />
          </div>
          <h4 style={h4}>Endpoints Discovered</h4>
          <div></div>
        </div>
        <div style={card}>
          <div>
            <InfoIcon style={{ color: "blue" }} />
          </div>
          <h4 style={h4}>Subdomains Discovered</h4>
          <div></div>
        </div>
      </Box> */
}

const Carousel = (props) => {
  const card = {
    width: "250px",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    borderRadius: 1,
    // flex: "1 0 21%" /* explanation below */,
    margin: "5px",
    padding: 1,
    backgroundColor: "black",
    opacity: 0.8,
    alignItems: "center",
  };
  const h4 = {
    fontWeight: 700,
    color: "white",
    marginBottom: 1,
  };
  const h3 = {
    fontWeight: 700,
    color: "purple",
  };
  return (
    <>
      <Box
        sx={{
          display: "flex",
          height: "100%",
          p: 1,
          mb: 10,
          bgcolor: "background.paper",
          borderRadius: 1,
          justifyContent: "center",
        }}
      >
        <Card>
          <Stack>
            <Item sx={{ color: "white" }}>
              <Box sx={{ float: "right" }}>
                <Tooltip title="Total Number of Targets/Domains">
                  <InfoIcon sx={{ color: "white", fontSize: 12 }} />
                </Tooltip>
              </Box>
            </Item>
            <Item sx={{ color: "white" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#bf8bff",
                  textTransform: "none",
                }}
              >
                {props.times_scanned}
              </Typography>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 10,
                  textTransform: "none",
                }}
                gutterBottom
              >
                Times Scanned
              </Typography>
            </Item>
            <Item>
              <Box
                backgroundColor="white"
                onClick={() => {
                  props.setCurrentComponent("Org Domains");
                }}
              >
                <Typography
                  variant="overline"
                  display="block"
                  sx={{
                    fontWeight: "bold",
                    fontSize: 8,
                    textTransform: "none",
                    cursor: "pointer",
                  }}
                  gutterBottom
                >
                  Scan
                </Typography>
              </Box>
            </Item>
          </Stack>
        </Card>
        <Card>
          <Stack>
            <Item sx={{ color: "white" }}>
              <Box sx={{ float: "right" }}>
                <Tooltip title="Total Number of Subdomains discovered by reNgine across all targets.">
                  <InfoIcon sx={{ color: "white", fontSize: 12 }} />
                </Tooltip>
              </Box>
            </Item>
            <Item sx={{ color: "white" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 10,
                  textTransform: "none",
                }}
                gutterBottom
              >
                Vulnerabilities Discovered
              </Typography>
            </Item>
            <Item sx={{ color: "white" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#2baccd",
                  textTransform: "none",
                }}
                gutterBottom
              >
                {props.vulnerability_count}
              </Typography>
            </Item>
            <Item sx={{ color: "white", textAlign: "left" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 8,
                  color: "#2baccd",
                  textTransform: "none",
                  pl: 2,
                  lineHeight: 1.6,
                }}
                gutterBottom
              >
                {props.level2}
              </Typography>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 8,
                  color: "#bf8bff",
                  textTransform: "none",
                  pl: 2,
                  lineHeight: 1.6,
                }}
                gutterBottom
              >
                {props.level1}
              </Typography>
            </Item>
          </Stack>
        </Card>
        <Card>
          <Stack>
            <Item sx={{ color: "white", float: "right" }}>
              <Box sx={{ float: "right" }}>
                <Tooltip title="Total Endpoints/URLs discovered by reNgine across all targets & subdomains.">
                  <InfoIcon sx={{ color: "white", fontSize: 12 }} />
                </Tooltip>
              </Box>
            </Item>
            <Item sx={{ color: "white" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 10,
                  textTransform: "none",
                }}
                gutterBottom
              >
                Endpoints Discovered
              </Typography>
            </Item>
            <Item sx={{ color: "white" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#bf8bff",
                  textTransform: "none",
                }}
                gutterBottom
              >
                {props.endpoint_count}
              </Typography>
            </Item>
            <Item sx={{ color: "white" }}>
              <Box sx={{ backgroundColor: "#404c51" }}>
                <Typography
                  variant="overline"
                  display="block"
                  sx={{
                    fontWeight: "bold",
                    fontSize: 8,
                    textTransform: "none",
                    opacity: 1,
                  }}
                  gutterBottom
                >
                  Alive Endpoints:{props.alive_endpoints}
                </Typography>
              </Box>
            </Item>
          </Stack>
        </Card>
        <Card>
          <Stack>
            <Item sx={{ color: "white", float: "right" }}>
              <Box sx={{ float: "right" }}>
                <Tooltip title="More Info">
                  <InfoIcon sx={{ color: "white", fontSize: 12 }} />
                </Tooltip>
              </Box>
            </Item>
            <Item sx={{ color: "white" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 10,
                  textTransform: "none",
                }}
                gutterBottom
              >
                Subdomains Discovered
              </Typography>
            </Item>
            <Item sx={{ color: "white" }}>
              <Typography
                variant="overline"
                display="block"
                sx={{
                  fontWeight: "bold",
                  fontSize: 16,
                  color: "#bf8bff",
                  textTransform: "none",
                }}
                gutterBottom
              >
                {props.subdomain_count}
              </Typography>
            </Item>
            <Item sx={{ color: "white" }}>
              <Box sx={{ backgroundColor: "#404c51" }}>
                <Typography
                  variant="overline"
                  display="block"
                  sx={{
                    fontWeight: "bold",
                    fontSize: 8,
                    textTransform: "none",
                    opacity: 1,
                  }}
                  gutterBottom
                >
                  Alive Subdomains:{props.alive_subdomain}
                </Typography>
              </Box>
            </Item>
          </Stack>
        </Card>
      </Box>
    </>
  );
};

function StackArea(props) {
  var data = props.data;
  var stackedData = data.stackedData;
  var port = data.port;
  console.log(stackedData, "col");
  // const primaryxAxis = { valueType: "Category" };
  // const primaryyAxis = {
  //   minimum: 0,
  //   maximum: 1000,
  //   interval: 100,
  //   labelFormat: "{value}",
  // };
  // const primaryxAxis = {
  //   title: "Years",
  //   valueType: "Category",
  //   intervalType: "month",
  //   majorTickLines: { width: 0 },
  //   labelFormat: "y",
  //   edgeLabelPlacement: "Shift",
  // };
  const primaryyAxis = {
    labelFormat: "{value}",
  };
  // const primaryxAxis = {
  //   valueType: "DateTime",
  //   intervalType: "Months",
  //   interval: 1,
  //   majorTickLines: { width: 0 },
  //   labelFormat: "m",
  //   edgeLabelPlacement: "Shift",
  // };
  // const primaryyAxis = {
  //   minimum: 0,
  //   maximum: 7,
  //   interval: 1,
  //   majorTickLines: { width: 0 },
  //   labelFormat: "{value}",
  // };
  const primaryxAxis = { valueType: "Category" };
  return (
    <ChartComponent
      id="charts7"
      primaryXAxis={primaryxAxis}
      primaryYAxis={primaryyAxis}
      // xAxis={{
      //   //Data label
      //   labels: data.month,
      // }}
      // yAxis={{
      //   labels: data.port,
      // }}
      title="Port Exposure Trend"
      titleStyle={{
        // text: "Port Exposure Trend",
        size: "14px",
        fontWeight: "700",
        textAlignment: "Near",
      }}
    >
      <Inject
        services={[
          StackingAreaSeries,
          Legend,
          heatMapTooltip,
          DataLabel,
          Category,
        ]}
      />
      <SeriesCollectionDirective>
        <SeriesDirective
          dataSource={stackedData}
          xName="month"
          yName={`${port[0]}`}
          name={`${port[0]}`}
          type="StackingArea"
        ></SeriesDirective>
        <SeriesDirective
          dataSource={stackedData}
          xName="month"
          yName={`${port[1]}`}
          name={`${port[1]}`}
          type="StackingArea"
        ></SeriesDirective>
        <SeriesDirective
          dataSource={stackedData}
          xName="month"
          yName={`${port[2]}`}
          name={`${port[2]}`}
          type="StackingArea"
        ></SeriesDirective>
        <SeriesDirective
          dataSource={stackedData}
          xName="month"
          yName={`${port[3]}`}
          name={`${port[3]}`}
          type="StackingArea"
        ></SeriesDirective>
        <SeriesDirective
          dataSource={stackedData}
          xName="month"
          yName={`${port[4]}`}
          name={`${port[4]}`}
          type="StackingArea"
        ></SeriesDirective>
      </SeriesCollectionDirective>
    </ChartComponent>
  );
}

export function PieChart(props) {
  let pie;
  let variouspiedata = props.variouspiedata;
  console.log(variouspiedata, "sasa");
  return (
    <AccumulationChartComponent
      id={props.id}
      title={props.title}
      titleStyle={props.titleSettings}
      ref={(pie) => (pie = pie)}
      legendSettings={{
        visible: true,
      }}
    >
      <Inject
        services={[
          AccumulationLegend,
          PieSeries,
          AccumulationDataLabel,
          AccumulationTooltip,
        ]}
      />
      <AccumulationSeriesCollectionDirective>
        <AccumulationSeriesDirective
          dataSource={variouspiedata}
          xName="x"
          yName="y"
          innerRadius="60%"
        ></AccumulationSeriesDirective>
      </AccumulationSeriesCollectionDirective>
    </AccumulationChartComponent>
  );
}
const Dashboard = () => {
  const { orgId, setCurrentComponent, site, token } = useContext(ASMTContext);

  const [data, setData] = useState();
  const [load, setLoad] = useState(false);
  const [geo, setGeo] = useState();
  const [sta_, setSta_] = useState();
  const [carousal, setCarousal] = useState();
  const [heatmap, setHeatmap] = useState();
  const [stackarea, setStackarea] = useState();
  const [asset_pie, setAsset_pie] = useState();
  const [lts_vulnerability_pie, setLts_vulnerability_pie] = useState();

  useEffect(() => {
    const loadDashboard = async () => {
      let obj = {};
      obj.apiId = "Dashboard";
      obj.token = token;
      obj.rengine_org_id = orgId.rengine_org_id;
      let params = {};
      params.org_id = orgId.rengine_org_id;
      // params.org_id = "default";
      obj.params = params;
      let response = await fetch(site, {
        method: "post",
        // mode: "cors",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
      });
      response = await response.json();
      console.log(response, "dbs");
      if (response.status == true) {
        // setData(response);
        //----------------------------------------------
        let asset_countries = response.asset_countries;
        let geo_ip = asset_countries.map((element) => {
          return {
            color: `blue`,
            // name: `${element.geo_iso__name}`,
            name: `${element.geo_iso__name}`,
            count: `${element.count}`,
          };
        });
        setGeo(geo_ip);
        //----------------------------------------------

        let ip_analysis = response.ip_analysis;
        let vul_analysis = response.vul_analysis;
        let sd_analysis = response.sd_analysis;
        let year = "2023";
        const monthGet = (date) => {
          const month = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
          ];
          console.log(date, "as");
          let value = parseInt(date.split("-")[1]);
          return month[value];
        };
        var sum_ip_domain = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        var sum_vul = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        for (var i in ip_analysis) {
          let value = parseInt(ip_analysis[i].month?.split("-")[1]);
          if (value) {
            let sum = sum_ip_domain[value];
            sum_ip_domain[value] = sum + ip_analysis[i].total;
          }
        }
        for (var i in sd_analysis) {
          let value = parseInt(sd_analysis[i].month?.split("-")[1]);
          if (value) {
            let sum = sum_ip_domain[value];
            console.log(sum, sd_analysis[i].count, "ghgc");
            sum_ip_domain[value] = sum + sd_analysis[i].count;
          }
        }
        for (var i in vul_analysis) {
          let value = parseInt(vul_analysis[i].month?.split("-")[1]);
          if (value) {
            let sum = sum_vul[value];
            sum_vul[value] = sum + vul_analysis[i].total;
          }
        }
        let sta = [
          { month: "Jan", ip_domains: sum_ip_domain[0], vuls: sum_vul[0] },
          { month: "Feb", ip_domains: sum_ip_domain[1], vuls: sum_vul[1] },
          { month: "Mar", ip_domains: sum_ip_domain[2], vuls: sum_vul[2] },
          { month: "Apr", ip_domains: sum_ip_domain[3], vuls: sum_vul[3] },
          { month: "May", ip_domains: sum_ip_domain[4], vuls: sum_vul[4] },
          { month: "Jun", ip_domains: sum_ip_domain[5], vuls: sum_vul[5] },
          { month: "Jul", ip_domains: sum_ip_domain[6], vuls: sum_vul[6] },
          { month: "Aug", ip_domains: sum_ip_domain[7], vuls: sum_vul[7] },
          { month: "Sep", ip_domains: sum_ip_domain[8], vuls: sum_vul[8] },
          { month: "Oct", ip_domains: sum_ip_domain[9], vuls: sum_vul[9] },
          { month: "Nov", ip_domains: sum_ip_domain[10], vuls: sum_vul[10] },
          { month: "Dec", ip_domains: sum_ip_domain[11], vuls: sum_vul[11] },
        ];
        console.log(sta, "sta");
        setSta_(sta);

        //----------------------------------------------
        {
          //     endpoint_count
          // scan_count
          // subdomain_count
          // subdomain_with_ip_count
          // alive_count
          // endpoint_alive_count
          // info_count
          // low_count
          // medium_count
          // high_count
          // critical_count
          // unknown_count
          // total_vul_count
        }
        let carousal_ = {};
        let level2 = `${response.critical_count} Critical, ${response.high_count} High, ${response.medium_count} Medium`;
        let level1 = `${response.info_count} Low, ${response.low_count} Info, ${response.unknown_count} Unknown`;
        carousal_.vulnerability_count = response.total_vul_count;
        carousal_.level2 = level2;
        carousal_.level1 = level1;
        carousal_.endpoint_count = response.endpoint_count;
        carousal_.alive_endpoints = response.subdomain_count;
        carousal_.subdomain_count = response.alive_count;
        carousal_.alive_subdomain = response.endpoint_alive_count;
        carousal_.times_scanned = response.times_scanned;
        carousal_.setCurrentComponent = setCurrentComponent;
        console.log(carousal_, "carousal_");
        setCarousal(carousal_);

        //----------------------------------------------
        let heatmap_ = {};
        let portsVsvulnerabilities = response.portsVsvulnerabilities;
        let vul_ports = response.vul_ports; //x-axis
        let value = Array.from(Array(vul_ports.length), (_) =>
          Array(6).fill(0)
        );
        console.log(value, "hmt");
        let column = [0, 0, 0, 0, 0, 0];
        for (var i in portsVsvulnerabilities) {
          let index = vul_ports.indexOf(
            portsVsvulnerabilities[i].subdomain__ip_addresses__ports__number
          );
          let sev = portsVsvulnerabilities[i].severity;
          let count = portsVsvulnerabilities[i].count;
          value[index][sev + 1] = count;
        }

        let value_ = value.map((e) => {
          return e.slice(1, 5).reverse();
        });

        console.log(value_, vul_ports, "hmt_");
        heatmap_.value = value_;
        // heatmap_.value = [32,43,124,34,23];
        heatmap_.xAxis = vul_ports;
        // heatmap_.xAxis = [56,68,32,65,2];
        heatmap_.yAxis = ["Critical", "High", "Medium", "Low"];
        if (value_.length || vul_ports.length) setHeatmap(heatmap_);

        //----------------------------------------
        let areamap = {};
        var most_used_port = response.most_used_port.map((e) => {
          return e.subdomain__ip_addresses__ports__number;
        });

        console.log(most_used_port, "most_used_port");
        var port_analysis = response.port_analysis;
        let xmonth = [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ];
        let stackarea_ = Array.from(Array(most_used_port.length), (_) =>
          Array(12).fill(0)
        );
        let some = {};
        for (var j in xmonth) {
          let month_key = xmonth[j];
          let row = {};
          row.month = month_key;
          for (var i in most_used_port) {
            let port_key = most_used_port[i];
            row[`${port_key}`] = 0;
          }
          some[`${month_key}`] = row;
          // some.push(row);
        }
        for (var i in port_analysis) {
          let point = port_analysis[i];
          let number = point.subdomain__ip_addresses__ports__number;
          let number_exists = most_used_port.includes(number);
          let index = parseInt(point.month?.split("-")[1]) - 1;
          if (index && number_exists) some[xmonth[index]][number] = point.total;
        }
        let areamap_ = [];
        for (var i in some) {
          if (some.hasOwnProperty(i)) areamap_.push(some[i]);
        }
        {
          let pa = [
            { month: "Jan", port: [], count: [] },
            { month: "Feb", port: [], count: [] },
            { month: "Mar", port: [], count: [] },
            { month: "Apr", port: [], count: [] },
            { month: "May", port: [], count: [] },
            { month: "Jun", port: [], count: [] },
            { month: "Jul", port: [], count: [] },
            { month: "Aug", port: [], count: [] },
            { month: "Sep", port: [], count: [] },
            { month: "Oct", port: [], count: [] },
            { month: "Nov", port: [], count: [] },
            { month: "Dec", port: [], count: [] },
          ];
        }
        areamap.month = xmonth;
        areamap.port = most_used_port;
        areamap.stackedData = areamap_;
        // for (var i in stackarea_) {
        //   let key_ = `${most_used_port[i]}`;
        //   areamap[`${key_}`] = stackarea_[i];
        // }
        console.log(areamap, "papa");
        setStackarea(areamap);

        //----------------------------------------

        let none_pie = [{ x: "None", y: 1 }];

        //----------------------------------------

        let most_used_tech = response.most_used_tech;
        let asset_pie_ = [];
        // let total_assets = 0;
        for (var i in most_used_tech) {
          let row = {};
          let point = most_used_tech[i];
          row.x = point.name;
          row.y = point.count;
          asset_pie_.push(row);
        }
        if (asset_pie_.length) setAsset_pie(asset_pie_);
        else setAsset_pie(none_pie);

        //----------------------------------------

        let latest_vulnerabilities = response.latest_vulnerabilities;
        console.log(latest_vulnerabilities, "sug");
        let lts_vulnerability_pie_ = [];
        for (var i in latest_vulnerabilities) {
          let row = {};
          let point = latest_vulnerabilities[i];
          row.x = point.severity;
          row.y = point.count;
          lts_vulnerability_pie_.push(row);
        }
        if (lts_vulnerability_pie_.length)
          setLts_vulnerability_pie(lts_vulnerability_pie_);
        else setLts_vulnerability_pie(none_pie);

        setLoad(true);
      }
      // return;
      else return;
    };
    // console.log(load, "true");
    try {
      // window.addEventListener(
      //   "mousemove",
      //   function (event) {
      //     event.stopImmediatePropagation();
      //   },
      //   true
      // );
      loadDashboard();
      // setTimeout(() => {
      // window.addEventListener(
      //   "mousemove",
      //   function (event) {
      //     window.dispatchEvent(event);
      //   },
      //   true
      // );
      // }, 5000);
    } catch (error) {
      console.log(error, "any");
    }
  }, []);

  return (
    <>
      {load && (
        <>
          <Box sx={{ width: "100%", padding: 1 }}>
            <Box>
              <Stack spacing={2}>
                <Item>
                  <Box
                    sx={{
                      display: "flex",
                      flexWrap: "wrap",
                      flexDirection: "row",
                      gap: 2,
                      justifyContent: "space-between",
                    }}
                  >
                    <Div sx={{ minWidth: "45%", height: 220, p: 1 }}>
                      <StackChart data={sta_} />
                    </Div>
                    <Div sx={{ minWidth: "45%", height: 220, p: 1 }}>
                      <div style={{ width: "100%", height: "100%" }}>
                        {geo && <BubbleMaps data={geo} id={"maps1"} />}
                      </div>
                    </Div>
                  </Box>
                </Item>
                <Carousel {...carousal} />
                <Item sx={{ display: "flex", height: "500px", gap: 2 }}>
                  <Box
                    sx={{
                      flexGrow: 1,
                      display: "flex",
                      gap: 5,
                      flexDirection: "column",
                    }}
                  >
                    <Box sx={{ height: "45%" }}>
                      {heatmap && <HeatMap data={heatmap} />}
                    </Box>
                    <Box
                      sx={{
                        flexGrow: 1,
                        display: "flex",
                        gap: 2,
                        padding: 1,
                        margin: 1,
                      }}
                    >
                      <Box sx={{ width: "60%", height: "100%" }}>
                        <StackArea data={stackarea} />
                      </Box>
                      <Paper
                        sx={{
                          flexGrow: 1,
                          backgroundImage:
                            "linear-gradient(rgb(254, 102, 125), rgb(255, 163, 117))",
                        }}
                      >
                        <PieChart
                          id="asset_pie"
                          title="Assets Discovered"
                          titleSettings={{
                            // text: "Assets Discovered",
                            textStyle: { size: "14px", fontWeight: "700" },
                            textAlignment: "Near",
                          }}
                          variouspiedata={asset_pie}
                        />
                      </Paper>
                    </Box>
                  </Box>
                  <Box
                    sx={{
                      width: "30%",
                      display: "flex",
                      gap: 2,
                      flexDirection: "column",
                    }}
                  >
                    <Paper sx={{ height: "55%", padding: 1 }}>
                      {geo && <BubbleMaps data={geo} id={"maps2"} />}
                    </Paper>
                    <Paper sx={{ flexGrow: 1, padding: 1, mb: 1 }}>
                      <PieChart
                        id="vulnerability_pie"
                        title="Vulnerabilities"
                        titleSettings={{
                          textStyle: { size: "14px", fontWeight: "700" },
                          textAlignment: "Near",
                        }}
                        // title="Vulnerabilities"
                        variouspiedata={lts_vulnerability_pie}
                      />
                    </Paper>
                  </Box>
                </Item>
                {/* <Item>
                  <Box
                    sx={{
                      display: "flex",
                      flexWrap: "wrap",
                      flexDirection: "row",
                      gap: 2,
                      justifyContent: "space-around",
                    }}
                  >
                    <Div sx={{ minWidth: "55%", height: 260, p: 1 }}>
                    </Div>
                    <Div sx={{ minWidth: "30%", height: 260, p: 1 }}>
                    </Div>
                  </Box>
                </Item> */}
                {/* <Item>
                  <Box
                    sx={{
                      display: "flex",
                      flexWrap: "wrap",
                      flexDirection: "row",
                      gap: 2,
                      justifyContent: "space-around",
                    }}
                  >
                    <Div sx={{ minWidth: "40%", height: 260, p: 1 }}>
                      <StackArea data={stackarea} />
                    </Div>
                    <Div sx={{ minWidth: "25%", height: 260, p: 1 }}>
                      <PieChart
                        id="asset_pie"
                        title="Assets Discovered"
                        titleSettings={{
                          // text: "Assets Discovered",
                          textStyle: { size: "14px", fontWeight: "700" },
                          textAlignment: "Near",
                        }}
                        variouspiedata={asset_pie}
                      />
                    </Div>
                    <Div sx={{ minWidth: "25%", height: 260, p: 1 }}>
                      <PieChart
                        id="vulnerability_pie"
                        title="Vulnerabilities"
                        titleSettings={{
                          textStyle: { size: "14px", fontWeight: "700" },
                          textAlignment: "Near",
                        }}
                        // title="Vulnerabilities"
                        variouspiedata={lts_vulnerability_pie}
                      />
                    </Div>
                  </Box>
                </Item> */}
              </Stack>
            </Box>
          </Box>
        </>
      )}
    </>
  );
};

export default Dashboard;
