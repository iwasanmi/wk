"use client";
import React, { useState, useEffect, useContext } from "react";
import Head from "next/head";
import {
  signInWithEmail,
  handleSignOut,
  getUserSession,
  enrollMFA,
  listFactors,
  supabase,
  magicSignUp,
  getUser,
  verifyMFA,
  CookieContext,
  Cookie,
} from "../../../services";
import { useFormik } from "formik";
import Image from "next/image";
import { useRouter } from "next/navigation";
import Cookies from "js-cookie";
import Router from "next/router";
import Link from "next/link";
import "../globals.css";
import IconButton from "@mui/material/IconButton";
import GoogleIcon from "@mui/icons-material/Google";
import FacebookIcon from "@mui/icons-material/Facebook";
import AppleIcon from "@mui/icons-material/Apple";
import Input from "@mui/material/Input";
import FilledInput from "@mui/material/FilledInput";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
// import { redirect } from "next/dist/server/api-utils";
import { redirect } from "next/navigation";
import SimpleBackdrop from "../../../components/loader";
const Message = (props) => {
  return <p className="color-red">{props.message}</p>;
};

export default function Home() {
  const { push } = useRouter();
  const [open, setOpen] = React.useState(false);
  const [showPassword, setShowPassword] = React.useState(false);
  const [message, setMessage] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [loginform, setLoginForm] = React.useState(true);
  const [password, setPassword] = React.useState("");
  const [error, setError] = React.useState(false);
  const [factorId, setFactorId] = useState("");
  const [qr, setQR] = useState(""); // holds the QR code image SVG

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const updatePassword = async (e) => {
    e.preventDefault();
    const { data, error } = await supabase.auth.updateUser({
      password: password,
    });
    console.log(data, error, "upp");
    if (error) {
      setError(true);
      setMessage("Password update failed. Try again.");
    }
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    onSubmit: async (values) => {
      // const status = await signInWithEmail(values);
      const { data, error } = await supabase.auth.signInWithPassword(values);
      console.log(data, error, "si");
      if (error) {
        setError(true);
        setMessage("Unable to sign in. Try Later.");
      } else {
        const session = data.session;
        const maxAge = 100 * 365 * 24 * 60 * 60; // 100 years, never expires
        console.log("b");
        document.cookie = `my-access-token=${session.access_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
        document.cookie = `my-refresh-token=${session.refresh_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
        push("/login");
      }
    },
  });
  // supabase.auth.onAuthStateChange(async (event, session) => {
  //   console.log(event, "eveilogindp");
  //   if (event === "SIGNED_IN") {
  //     //   console.log("autch");
  //     setOpen(true);
  //     console.log("asmtredirect");
  //     // push("/login");
  //   }
  // });
  // setTimeout(() => {
  //   push("/asmt");
  // }, 3000);

  //   const { data, error } = await enrollMFA();

  //   if (error) {
  //     console.log(error, "mfe");
  //     throw error;
  //   }
  //   setFactorId(data.id);

  //   // Supabase Auth returns an SVG QR code which you can convert into a data
  //   // URL that you can place in an <img> tag.
  //   setQR(data.totp.qr_code);
  // }

  // const { data, error } = await supabase.auth.getSession();
  // console.log(data, error, "lolo");

  useEffect(() => {
    async function userRedirect() {
      supabase.auth.onAuthStateChange(async (event, session) => {
        console.log(event, "eveidp");
        if (event === "PASSWORD_RECOVERY") {
          setLoginForm(false);
          console.log("PASSWORD_RECOVERY recovery", session);
          const {
            data: { user },
          } = await supabase.auth.getUser();
          console.log(user, "xyz");
        }
        // if (loginform != true) {
        // }
      });
      // const { data, error } = await supabase.auth.getUser(obj?.value);
    }
    userRedirect();
  });
  // else if (event === "SIGNED_IN") {
  //   console.log("autch");
  //   setOpen(true);
  //   console.log("asmtredirect");
  //   const maxAge = 100 * 365 * 24 * 60 * 60; // 100 years, never expires
  //   console.log("b");
  //   document.cookie = `my-access-token=${session.access_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
  //   document.cookie = `my-refresh-token=${session.refresh_token}; path=/; max-age=${maxAge}; SameSite=Lax; secure`;
  //   push("/login");
  // }
  // const { user, session, error } = await getUser();
  // console.log(
  //   user,
  //   session,
  //   (user != null) & (session != null),
  //   error,
  //   "ur"
  // );

  return (
    <>
      <section className="width-100 px-6">
        <div className="padding-n navbar">
          <div>
            <a>
              <span>
                <img
                  style={{
                    height: "94px",
                  }}
                  src="/logo.png"
                />
              </span>
            </a>
          </div>
          <div>
            <p className="text-sm font-light  padding-t-0">
              Don’t have an account yet?{" "}
              <Link
                href="/register"
                className="font-medium color-aqua underline dark:text-primary-500"
              >
                Sign up
              </Link>
            </p>
          </div>
        </div>
      </section>
      <section className="width-100 height-100">
        <div className="flex-h-w justify-between px-6 py-4">
          <div>
            <div className="">
              <Image
                src="/tea-cup-svgrepo-com.svg"
                alt="Vercel Logo"
                className="dark:invert"
                width={100}
                height={24}
                priority
              />
            </div>
            <div className="">
              <Image
                src="/horizontal-rule-svgrepo-com.svg"
                alt="Vercel Logo"
                className="dark:invert"
                width={100}
                height={24}
                priority
              />
            </div>
          </div>
          <div className="max-width-30">
            <div className="padding-tb-0 opacity-80">
              <h1 className="font-size-60 line-height-0">
                Great to have you back!
              </h1>
            </div>
            <div className="opacity-80 padding-b-0">
              <p>
                Attack Surface Detection - Keep your network secure. Detect and
                protect yourself from potential security vulnerabilities.
              </p>
            </div>
            <div>
              <div className="padding-t-0 padding-b-0">
                <Image
                  src="/sun-svgrepo-com.svg"
                  alt="Vercel Logo"
                  className="dark:invert"
                  width={100}
                  height={24}
                  priority
                />
              </div>
            </div>
          </div>
          <div className="w-full rounded-md shadow-blue-1 dark:border md:mt-0 sm:max-w-md xl:p-0 dark: dark:">
            {loginform ? (
              <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
                <h1 className="text-xl font-bold leading-tight tracking-tight md:text-2xl dark:text-white">
                  Sign in to your account
                </h1>
                <form
                  onSubmit={formik.handleSubmit}
                  className="space-y-4 md:space-y-6"
                  action="#"
                >
                  <div className="text-left">
                    <TextField
                      id="email"
                      label="Email"
                      type="email"
                      variant="standard"
                      onKeyUp={(e) => {
                        console.log(e.target.value);
                        setEmail(e.target.value);
                      }}
                      onChange={formik.handleChange}
                      value={formik.values.email}
                      fullWidth
                    />
                  </div>
                  <div className="text-left">
                    <FormControl fullWidth variant="standard">
                      <InputLabel htmlFor="password">Password</InputLabel>
                      <Input
                        id="password"
                        onChange={formik.handleChange}
                        value={formik.values.password}
                        type={showPassword ? "text" : "password"}
                        endAdornment={
                          <InputAdornment position="end">
                            <IconButton
                              aria-label="toggle password visibility"
                              onClick={handleClickShowPassword}
                              onMouseDown={handleMouseDownPassword}
                            >
                              {showPassword ? (
                                <VisibilityOff />
                              ) : (
                                <Visibility />
                              )}
                            </IconButton>
                          </InputAdornment>
                        }
                      />
                    </FormControl>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="remember"
                          aria-describedby="remember"
                          type="checkbox"
                          className="w-4 h-4 border rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="remember" className="">
                          Remember me
                        </label>
                      </div>
                    </div>
                    <button
                      id="forget-password"
                      type="button"
                      onClick={async () => {
                        console.log(email, "fg");
                        if (email !== "") {
                          const { data, error } =
                            await supabase.auth.resetPasswordForEmail(email, {
                              redirectTo: "http://localhost:3000/login",
                            });
                          console.log(data, "ereset");
                          if (!error) {
                            setMessage("Password reset link sent to email");
                            setTimeout(() => {
                              window.close();
                              // location.reload();
                            }, 3000);
                          }
                        }
                      }}
                      className="font-medium color-aqua underline dark:text-primary-500"
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <button
                    id="button"
                    type="submit"
                    className="w-full  bg-aqua focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center text-white dark:bg-indigo-600 dark:hover:bg-indigo-700 dark:focus:ring-indigo-800"
                  >
                    Sign In
                  </button>
                  {error ? <Message message={message} /> : ""}
                  {message !== "" ? <Message message={message} /> : ""}
                  {open ? <SimpleBackdrop /> : ""}
                </form>
                <div className="margin-t-0 text-center">
                  <p>Or sign in with</p>
                  <div className="flex-h justify-center margin-a padding-t-0">
                    <div className="rounded-lg padding-lr-0 margin-r-0 shadow bg-red-20">
                      <a onClick={magicSignUp}>
                        <GoogleIcon />
                      </a>
                    </div>
                    {/* <div className="rounded-lg padding-lr-0 margin-r-0 shadow bg-aqua-20">
                      <a
                        onClick={async () => {
                          const { data, error } = await supabase
                            .from("Profile")
                            .select()
                            .eq(
                              "user_id",
                              "b684a597-78d3-4442-988b-4f9fd74c5e2c"
                            );
                          console.log(data, "uppr");
                        }}
                      >
                        <FacebookIcon />
                      </a>
                    </div>
                    <div className="rounded-lg padding-lr-0 shadow bg-grey-20">
                      <a onClick={magicSignUp}>
                        <AppleIcon />
                      </a>
                    </div> */}
                  </div>
                </div>
              </div>
            ) : (
              ""
            )}
            {!loginform ? (
              <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
                <h1 className="text-xl font-bold leading-tight tracking-tight md:text-2xl dark:text-white">
                  Update Password
                </h1>
                <form
                  onSubmit={updatePassword}
                  className="space-y-4 md:space-y-6"
                  action="#"
                >
                  <div className="text-left">
                    <FormControl fullWidth variant="standard">
                      <InputLabel htmlFor="password">Password</InputLabel>
                      <Input
                        id="password"
                        onChange={(e) => {
                          setPassword(e.target.value);
                        }}
                        value={password}
                        type={showPassword ? "text" : "password"}
                        endAdornment={
                          <InputAdornment position="end">
                            <IconButton
                              aria-label="toggle password visibility"
                              onClick={handleClickShowPassword}
                              onMouseDown={handleMouseDownPassword}
                            >
                              {showPassword ? (
                                <VisibilityOff />
                              ) : (
                                <Visibility />
                              )}
                            </IconButton>
                          </InputAdornment>
                        }
                      />
                    </FormControl>
                  </div>
                  <button
                    id="button"
                    type="submit"
                    className="w-full  bg-aqua focus:ring-4 focus:outline-none focus:ring-indigo-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center text-white dark:bg-indigo-600 dark:hover:bg-indigo-700 dark:focus:ring-indigo-800"
                  >
                    Okay!
                  </button>
                  {error ? <Message message={message} /> : ""}
                </form>
              </div>
            ) : (
              ""
            )}
          </div>
          <div>
            <div className="padding-t-1">
              <Image
                src="/bulb-svgrepo-com.svg"
                alt="Vercel Logo"
                className="dark:invert"
                width={100}
                height={24}
                priority
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
