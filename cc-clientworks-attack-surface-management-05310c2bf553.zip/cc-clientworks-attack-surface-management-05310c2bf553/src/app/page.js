import Image from "next/image";
import "./globals.css";

export default function Home() {
  return (
    <>
      <section
        style={{
          backgroundColor: "#f97316",
        }}
        className="section-1"
      >
        <div className="general padding-rbl-0">
          <header className="navbar">
            <a href="#" className="font-size-24 font-semi-bold">
              Attack Surface Detection Webpage
            </a>
            <nav>
              <ul className="inline-list">
                <li>
                  <a href="#" className="font-size-16 font-medium">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#" className="font-size-16 font-medium">
                    FAQ
                  </a>
                </li>
              </ul>
            </nav>
          </header>

          <div className="padding-tb-3">
            <div>
              <h1 className="font-size-72 font-bold line-height-0 max-width-80">
                Attack Surface Detection - Keep your network secure
              </h1>
            </div>
            <div className="flex-v padding-t-1">
              <div className="max-width-55">
                <p className="font-size-24 font-medium">
                  Detect and protect yourself from potential security
                  vulnerabilities with our Attack Surface Detection Webpage.
                </p>
              </div>
              <div className="margin-t-1">
                <section>
                  <h2 className="font-size-24 font-bold">
                    Want to find out more?
                  </h2>
                  <div>
                    <form className="flex-v width-var">
                      <input
                        className="font-size-20 margin-t-0 padding-tb-0 padding-lr-1 rounded-xl shadow"
                        type="email"
                        id="home-email"
                        name="email"
                        placeholder="Enter your email."
                      />
                      <div
                        id="button"
                        className="font-size-20 font-bold color-white bg-brown margin-t-0 center-text padding-tb-0 rounded-xl padding-lr-1"
                      >
                        <input type="submit" value="Tell me more?" />
                      </div>
                    </form>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
        <div className="svgframe">
          <svg
            class=""
            viewBox="0 0 200 200"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g clip-path="url(#clip0_1124_1297)">
              <mask
                id="mask0_1124_1297"
                maskUnits="userSpaceOnUse"
                x="0"
                y="0"
                width="200"
                height="200"
              >
                <path d="M200 0H0V200H200V0Z" fill="white"></path>
              </mask>
              <g mask="url(#mask0_1124_1297)">
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M0 100L4.37114e-06 0L100 4.37114e-06C100 55.2285 55.2285 100 0 100ZM200 100C200 44.7716 155.228 1.88558e-05 100 4.37114e-06V100H0C-4.82822e-06 155.228 44.7715 200 100 200H200V100ZM199.961 100H100V200C100 144.785 144.75 100.021 199.961 100Z"
                  fill="url(#paint0_linear_1124_1297)"
                ></path>
              </g>
            </g>
            <defs>
              <linearGradient
                id="paint0_linear_1124_1297"
                x1="157.5"
                y1="32"
                x2="44"
                y2="147.5"
                gradientUnits="userSpaceOnUse"
              >
                <stop
                  offset="0.0509862"
                  stop-color="rgba(249, 22, 41, 0.2)"
                ></stop>
                <stop offset="1" stop-color="rgba(204, 249, 22, 0.2)"></stop>
              </linearGradient>
              <clipPath id="clip0_1124_1297">
                <rect width="200" height="200" fill="white"></rect>
              </clipPath>
            </defs>
          </svg>
        </div>
      </section>
      <main>
        <section className="padding-rbl-0">
          <div className="padding-tb-3">
            <div className="flex-h-c">
              <h2 className="font-size-60 font-bold line-height-0 center-text max-w-2xl">
                Our Attack Surface Detection Webpage offers several key
                features, including:
              </h2>
            </div>
            <div className="flex-v padding-t-1">
              <div className="padding-1 width-50 margin-l-a bg-yellow rounded-xl">
                <h3 className="font-size-30 font-semi-bold">
                  Comprehensive network scan
                </h3>
                <p className="font-size-20">
                  Our customizable network scanner will detect all possible
                  entry points into your network.
                </p>
              </div>
              <div className="padding-1 width-50 margin-r-a bg-yellow rounded-xl">
                <h3 className="font-size-30 font-semi-bold">
                  Detailed reporting
                </h3>
                <p className="font-size-20">
                  Receive a full report of vulnerabilities detected.
                </p>
              </div>
              <div className="padding-1 width-50 margin-l-a bg-yellow rounded-xl">
                <h3 className="font-size-30 font-semi-bold">
                  Continuous monitoring
                </h3>
                <p className="font-size-20">
                  Get alerts when new vulnerabilities are detected in your
                  network.
                </p>
              </div>
              <div className="padding-1 width-50 margin-r-a bg-yellow rounded-xl">
                <h3 className="font-size-30 font-semi-bold">
                  Easy to use interface
                </h3>
                <p className="font-size-20">
                  Our intuitive interface makes it simple to run scans and
                  manage your security.
                </p>
              </div>
              <div className="padding-1 width-50 margin-l-a bg-yellow rounded-xl">
                <h3 className="font-size-30 font-semi-bold">
                  Customizable scans
                </h3>
                <p className="font-size-20">
                  Tailor scans to fit your unique network and security
                  requirements.
                </p>
              </div>
              <div className="padding-1 width-50 margin-r-a bg-yellow rounded-xl">
                <h3 className="font-size-30 font-semi-bold">
                  Integration capabilities
                </h3>
                <p className="font-size-20">
                  Easily integrate with other security tools you use.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="padding-rbl-0">
          <div className="padding-tb-3 flex-h-w">
            <div className="max-width-30 margin-b-0">
              <h2 className="font-size-48 font-bold line-height-0 width-80 margin-r-a">
                Frequently Asked Questions
              </h2>
            </div>
            <div className="flex-v max-width-60">
              <div>
                <h3 className="font-size-30 font-semi-bold">
                  What is Attack Surface Detection?
                </h3>
                <p className="font-size-20">
                  Attack Surface Detection is a web-based security tool that
                  scans your network for vulnerabilities and provides you a
                  report of potential attack vectors.
                </p>
              </div>
              <div className="margin-t-0">
                <h3 className="font-size-30 font-semi-bold">
                  What does the reports contain?
                </h3>
                <p className="font-size-20">
                  The reports typically contain a list of all detected
                  vulnerabilities, along with remediation steps and suggestions
                  for additional security measures.
                </p>
              </div>
              <div className="margin-t-0">
                <h3 className="font-size-30 font-semi-bold">
                  What happens after the initial scan is complete?
                </h3>
                <p className="font-size-20">
                  Our service continuously monitors your network, providing
                  alerts for newly detected vulnerabilities and the capability
                  to run additional scans at any time.
                </p>
              </div>
              <div className="margin-t-0">
                <h3 className="font-size-30 font-semi-bold">
                  How customizable are the scans?
                </h3>
                <p className="font-size-20">
                  Very customizable, you can tailor each scan to fit your unique
                  network and security requirements.
                </p>
              </div>
              <div className="margin-t-0">
                <h3 className="font-size-30 font-semi-bold">
                  Is Attack Surface Detection easy to use?
                </h3>
                <p className="font-size-20">
                  Yes,our intuitive interface makes it simple to run scans and
                  manage your security.
                </p>
              </div>
              <div className="margin-t-0">
                <h3 className="font-size-30 font-semi-bold">
                  Does it integrate with other tools?
                </h3>
                <p className="font-size-20">
                  Yes, easily integrate with other security tools you use.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <section className="padding-rbl-0 bg-yellow">
        <div className="padding-tb-3">
          <h2 className="font-size-48 font-bold line-height-0 min-width-80 margin-a center-text">
            Attack Surface Detection - Keep your network secure
          </h2>
          <div className="margin-t-1">
            <section>
              <h2 className="font-size-24 font-bold text-center">
                Want to find out more?
              </h2>
              <div>
                <form className="flex-v width-var margin-a">
                  <input
                    className="font-size-20 margin-t-0 padding-tb-0 padding-lr-1 rounded-xl shadow"
                    type="email"
                    id="email-letter"
                    name="email-letter"
                    placeholder="Enter your email."
                  />
                  <div
                    id="button"
                    className="font-size-20 font-bold color-white bg-brown margin-t-0 center-text padding-tb-0 rounded-xl padding-lr-1"
                  >
                    <input type="submit" value="Tell me more?" />
                  </div>
                </form>
              </div>
            </section>
          </div>
        </div>
        <footer>
          <div class="text-sm">
            <div class="flex justify-center gap-4 py-2.5"></div>
            <div class="flex flex-col md:flex-row gap-4 justify-center">
              <span class="opacity-40">
                Attack Surface Detection - Keep your network secure. All rights
                reserved.
              </span>
            </div>
          </div>
        </footer>
      </section>
    </>
  );
}
