import React from "react";
import { useState, useEffect, useContext } from "react";
import { ASMTContext } from "../../../../contexts/ASMTContext";
import { Item } from "../../../../components/details";
import { Typography } from "@mui/material";
import Divider from "@mui/material/Divider";
import { styled } from "@mui/system";
import { Box } from "@mui/material";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import SendIcon from "@mui/icons-material/Send";
import CardContent from "@mui/material/CardContent";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import LinearProgress from "@mui/material/LinearProgress";
import {
  faStarOfLife,
  faWindowMinimize,
  faCcMastercard,
  faCcVisa,
} from "@fortawesome/free-solid-svg-icons";
import { TextField } from "@mui/material";
import { Stack } from "@mui/material";
import { useRouter } from "next/navigation";
import { pk_stripe, options } from "../subscribe/index";
import { Button } from "@mui/material";
import { experimentalStyled as exStyled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";
import { supabase } from "../../../../services";
import Grid from "@mui/material/Grid";
import { BoardContext } from "../subscribe/layout";
import {
  useStripe,
  useElements,
  Elements,
  AddressElement,
} from "@stripe/react-stripe-js";

const Rep = exStyled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(2),
  textAlign: "center",
  color: theme.palette.text.secondary,
}));

const Rbox = styled(Box)(({ theme }) => ({
  [theme.breakpoints.down("md")]: {
    minWidth: "100%",
  },
}));

export const Billings = (props) => {
  const { subscriptions, customerDetails, paymentMethods } = props;
  const { push } = useRouter();
  const [customer, setCustomer] = useState();
  const [complete, setComplete] = useState(true);
  const [subscription, setSubscription] = useState();
  const [addSubscription, setAddSubscription] = useState();
  const [payment, setPayment] = useState();
  const [paymentSelect, setPaymentSelect] = useState();
  const [org_id, setorg_id] = useState();
  const [token, settoken] = useState();
  const [rengine_org_id, setrengine_org_id] = useState();
  let {
    initaddress,
    initpackage,
    initpay,
    initresult,
    initStripe,
    setInitstripe,
    setIaddress,
    stripeSecret,
    setStripeSecret,
    setIpackage,
    setIpay,
    setIresult,
    stripeInLay,
    setInitaddress,
    setInitpackage,
    setInitpay,
    setInitresult,
    iresult,
    ipay,
    ipackage,
    iaddress,
  } = useContext(BoardContext);

  useEffect(() => {
    // const { subscriptions, customerDetails, paymentMethods } = {
    //   subscriptions: {
    //     object: "list",
    //     data: [
    //       {
    //         id: "sub_1O6TdNSE6gO0eGi5ZAHUmTd3",
    //         object: "subscription",
    //         application: null,
    //         application_fee_percent: null,
    //         automatic_tax: {
    //           enabled: false,
    //         },
    //         billing_cycle_anchor: 1698565329,
    //         billing_thresholds: null,
    //         cancel_at: null,
    //         cancel_at_period_end: false,
    //         canceled_at: null,
    //         cancellation_details: {
    //           comment: null,
    //           feedback: null,
    //           reason: null,
    //         },
    //         collection_method: "charge_automatically",
    //         created: 1698565329,
    //         currency: "inr",
    //         current_period_end: 1701243729,
    //         current_period_start: 1698565329,
    //         customer: "cus_OuIDv7m0tx6bcC",
    //         days_until_due: null,
    //         default_payment_method: "pm_1O6TeUSE6gO0eGi5tFBxGSYq",
    //         default_source: null,
    //         default_tax_rates: [],
    //         description: null,
    //         discount: null,
    //         ended_at: null,
    //         items: {
    //           object: "list",
    //           data: [
    //             {
    //               id: "si_OuIDbCrQt5bQdt",
    //               object: "subscription_item",
    //               billing_thresholds: null,
    //               created: 1698565330,
    //               metadata: {},
    //               plan: {
    //                 id: "price_1NuXz7SE6gO0eGi5UJK97WOF",
    //                 object: "plan",
    //                 active: true,
    //                 aggregate_usage: null,
    //                 amount: 400000,
    //                 amount_decimal: "400000",
    //                 billing_scheme: "per_unit",
    //                 created: 1695722117,
    //                 currency: "inr",
    //                 interval: "month",
    //                 interval_count: 1,
    //                 livemode: false,
    //                 metadata: {},
    //                 nickname: null,
    //                 product: "prod_OhxuNX6thz3X8Q",
    //                 tiers_mode: null,
    //                 transform_usage: null,
    //                 trial_period_days: null,
    //                 usage_type: "licensed",
    //               },
    //               price: {
    //                 id: "price_1NuXz7SE6gO0eGi5UJK97WOF",
    //                 object: "price",
    //                 active: true,
    //                 billing_scheme: "per_unit",
    //                 created: 1695722117,
    //                 currency: "inr",
    //                 custom_unit_amount: null,
    //                 livemode: false,
    //                 lookup_key: null,
    //                 metadata: {},
    //                 nickname: null,
    //                 product: "prod_OhxuNX6thz3X8Q",
    //                 recurring: {
    //                   aggregate_usage: null,
    //                   interval: "month",
    //                   interval_count: 1,
    //                   trial_period_days: null,
    //                   usage_type: "licensed",
    //                 },
    //                 tax_behavior: "unspecified",
    //                 tiers_mode: null,
    //                 transform_quantity: null,
    //                 type: "recurring",
    //                 unit_amount: 400000,
    //                 unit_amount_decimal: "400000",
    //               },
    //               quantity: 1,
    //               subscription: "sub_1O6TdNSE6gO0eGi5ZAHUmTd3",
    //               tax_rates: [],
    //             },
    //           ],
    //           has_more: false,
    //           total_count: 1,
    //           url: "/v1/subscription_items?subscription=sub_1O6TdNSE6gO0eGi5ZAHUmTd3",
    //         },
    //         latest_invoice: "in_1O6TdNSE6gO0eGi5uMAu9wBO",
    //         livemode: false,
    //         metadata: {},
    //         next_pending_invoice_item_invoice: null,
    //         on_behalf_of: null,
    //         pause_collection: null,
    //         payment_settings: {
    //           payment_method_options: {
    //             acss_debit: null,
    //             bancontact: null,
    //             card: {
    //               mandate_options: {
    //                 amount: 400000,
    //                 amount_type: "maximum",
    //                 description: "starter-global",
    //               },
    //               network: null,
    //               request_three_d_secure: "automatic",
    //             },
    //             customer_balance: null,
    //             konbini: null,
    //             us_bank_account: null,
    //           },
    //           payment_method_types: null,
    //           save_default_payment_method: "on_subscription",
    //         },
    //         pending_invoice_item_interval: null,
    //         pending_setup_intent: null,
    //         pending_update: null,
    //         plan: {
    //           id: "price_1NuXz7SE6gO0eGi5UJK97WOF",
    //           object: "plan",
    //           active: true,
    //           aggregate_usage: null,
    //           amount: 400000,
    //           amount_decimal: "400000",
    //           billing_scheme: "per_unit",
    //           created: 1695722117,
    //           currency: "inr",
    //           interval: "month",
    //           interval_count: 1,
    //           livemode: false,
    //           metadata: {},
    //           nickname: null,
    //           product: "prod_OhxuNX6thz3X8Q",
    //           tiers_mode: null,
    //           transform_usage: null,
    //           trial_period_days: null,
    //           usage_type: "licensed",
    //         },
    //         quantity: 1,
    //         schedule: null,
    //         start_date: 1698565329,
    //         status: "active",
    //         test_clock: null,
    //         transfer_data: null,
    //         trial_end: null,
    //         trial_settings: {
    //           end_behavior: {
    //             missing_payment_method: "create_invoice",
    //           },
    //         },
    //         trial_start: null,
    //       },
    //     ],
    //     has_more: false,
    //     url: "/v1/subscriptions",
    //   },
    //   customerDetails: {
    //     id: "cus_OuIDv7m0tx6bcC",
    //     object: "customer",
    //     address: {
    //       city: "Virar",
    //       country: "GH",
    //       line1: "N/102,the hill park CHS LTD.,jivdani road,Virar(east).",
    //       line2: "",
    //       postal_code: "",
    //       state: "",
    //     },
    //     balance: 0,
    //     created: 1698565328,
    //     currency: "inr",
    //     default_source: null,
    //     delinquent: false,
    //     description: null,
    //     discount: null,
    //     email: "rohitgurkhe@gmail.com",
    //     invoice_prefix: "3DE5C623",
    //     invoice_settings: {
    //       custom_fields: null,
    //       default_payment_method: null,
    //       footer: null,
    //       rendering_options: null,
    //     },
    //     livemode: false,
    //     metadata: {},
    //     name: "Gurkhe Rohit",
    //     next_invoice_sequence: 2,
    //     phone: null,
    //     preferred_locales: [],
    //     shipping: null,
    //     tax_exempt: "none",
    //     test_clock: null,
    //   },
    //   paymentMethods: {
    //     object: "list",
    //     data: [
    //       {
    //         id: "pm_1O6TeUSE6gO0eGi5tFBxGSYq",
    //         object: "payment_method",
    //         billing_details: {
    //           address: {
    //             city: null,
    //             country: "SV",
    //             line1: null,
    //             line2: null,
    //             postal_code: null,
    //             state: null,
    //           },
    //           email: null,
    //           name: null,
    //           phone: null,
    //         },
    //         card: {
    //           brand: "visa",
    //           checks: {
    //             address_line1_check: null,
    //             address_postal_code_check: null,
    //             cvc_check: "pass",
    //           },
    //           country: "US",
    //           exp_month: 4,
    //           exp_year: 2024,
    //           fingerprint: "mgJP3EMJLsfiKn3k",
    //           funding: "credit",
    //           generated_from: null,
    //           last4: "4242",
    //           networks: {
    //             available: ["visa"],
    //             preferred: null,
    //           },
    //           three_d_secure_usage: {
    //             supported: true,
    //           },
    //           wallet: null,
    //         },
    //         created: 1698565399,
    //         customer: "cus_OuIDv7m0tx6bcC",
    //         livemode: false,
    //         metadata: {},
    //         type: "card",
    //       },
    //     ],
    //     has_more: false,
    //     url: "/v1/customers/cus_OuIDv7m0tx6bcC/payment_methods",
    //   },
    // };
    async function loadPage() {
      // console.log(searchParams.get("extend"), "dsmvh"); // price_descending
      const { data, error } = await supabase.from("product").select();
      console.log(data, error, "sooner");
      let org_id;
      let rengine_org_id;
      let token;
      let product = {};
      for (var i = 0; i < data.length; i++) {
        product[data[i].product_id] = data[i].name;
      }
      settoken(localStorage.getItem("X-CSRFToken"));
      token = localStorage.getItem("X-CSRFToken");
      {
        const { data, error } = await supabase.from("Profile").select("org_id");
        if (data.length) {
          org_id = parseInt(data[0].org_id);
          setorg_id(parseInt(data[0].org_id));
        }
      }
      {
        const { data, error } = await supabase
          .from("Organization")
          .select("rengine_org_id")
          .eq("id", org_id);
        console.log(org_id, data, error, "orff");
        if (data && data.length) {
          setrengine_org_id(data[0].rengine_org_id);
          rengine_org_id = data[0].rengine_org_id;
        }
      }
      const searchParams = new URLSearchParams(window.location.search);
      if (searchParams.has("extend")) {
        let extend = parseInt(searchParams.get("extend"));
        let sub_id = null;
        let cus_id = null;
        cus_id = searchParams.get("cus_id");
        if (searchParams.has("sub_id")) {
          sub_id = searchParams.get("sub_id");
        }
        if (rengine_org_id == null) {
          let supabase_limit;
          {
            const { data, error } = await supabase
              .from("Organization")
              .select("first_limit")
              .eq("id", org_id);
            supabase_limit = data[0].first_limit + extend;
          }
          const { data, error } = await supabase
            .from("Organization")
            .update({ first_limit: supabase_limit })
            .eq("id", org_id);
        } else {
          let objt = {};
          objt.apiId = "/api/extend/limit";
          objt.params = {
            extend: extend,
            project: rengine_org_id,
          };
          if (sub_id != null) objt.params.sub_id = sub_id;
          objt.method = "post";
          objt.token = token;
          console.log(objt, "djg");
          let response = await fetch("http://localhost:3001/v2", {
            method: "post",
            // mode: "no-cors",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify(objt),
          });
          response = await response.json();
          console.log(response, "rdher");
        }
        push("/register/subscribe");
      }
      setCustomer({
        id: customerDetails.id,
        point: {
          name: customerDetails.name,
          email: customerDetails.email,
          address: customerDetails.address,
        },
        change: false,
        address: false,
      });
      let subscriptionList = [];
      for (var i = 0; i < subscriptions.data.length; i++) {
        let point = subscriptions.data[i];
        let obj = {};
        obj.status = point.status;
        let d = new Date(point.current_period_end * 1000);
        obj.current_period_end = d.getDate() + "/" + (d.getMonth() + 1);
        d = new Date(point.current_period_start * 1000);
        obj.current_period_start = d.getDate() + "/" + (d.getMonth() + 1);
        d = new Date(point.cancel_at * 1000);
        obj.cancel_at = d.getDate() + "/" + (d.getMonth() + 1);
        obj.cancel_at_period_end = point.cancel_at_period_end;
        obj.id = point.id;
        obj.object = point.object;
        obj.interval = point.plan.interval;
        obj.plan = point.plan.id;
        obj.product = point.plan.product;
        obj.name = product[point.plan.product];
        subscriptionList.push(obj);
      }
      setSubscription(subscriptionList);
      console.log(subscriptionList, "pr");
      if (paymentMethods.data.length) setPayment([paymentMethods.data[0]]);
      else setPayment([]);
      // paymentMethods.data.map((e) => {
      //   console.log(
      //     e.card.brand,
      //     e.card.last4,
      //     `Expiry: ${e.card.exp_month} ${e.card.exp_year}`,
      //     "tp"
      //   );
      // });

      console.log(subscriptions, customerDetails, paymentMethods, "ncsp");
    }

    loadPage();
  }, []);

  const payInvoice = async (event) => {
    try {
      const defaultPayment = payment.length;
      if (defaultPayment) {
        const invoice = await stripe.invoices.pay(event.target.value);
      } else {
      }
    } catch (error) {
      console.log(error, "error");
    }
  };

  const removeMethod = async (event) => {
    try {
      let response = await fetch("http://localhost:3001/v1/removeMethod/", {
        method: "post",
        // mode: "no-cors",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ method: event.target.value }),
      });
      // if(response.status==200)
      let paymentMethod = await response.json();
      console.log(paymentMethod);
    } catch (error) {
      console.log(error);
    }
  };

  const updateCustomer = async () => {
    console.log(customer, "sds");
    try {
      let response = await fetch("http://localhost:3001/v1/updateCustomer/", {
        method: "post",
        // mode: "no-cors",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(customer),
      });
      response = await response.json();
      console.log(response);
    } catch (error) {
      console.log(error);
    }
  };

  const continuePaying = async () => {
    try {
      const { data, error } = await supabase
        .from("product")
        .select("no_assets")
        .eq("price_id", addSubscription.price);
      console.log(data, error, "proo");
      let extend = data[0].no_assets;
      let obj = {};
      obj.customer = { id: customer.id };
      obj.addSubscription = { price: addSubscription.price };
      console.log(obj, "ssd");
      let response = await fetch("http://localhost:3001/v1/continuePaying/", {
        method: "post",
        // mode: "no-cors",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
      });
      let subscription = await response.json();
      console.log(
        subscription,
        {
          // passing the client secret obtained from the server
          clientSecret: subscription.metadata.clientSecret,
          appearance: { theme: "stripe" },
        },
        "dsd"
      );
      setIpay(true);
      setInitpay({
        // passing the client secret obtained from the server
        clientSecret: subscription.metadata.clientSecret,
        appearance: { theme: "stripe" },
        extend: extend,
        sub_id: subscription.id,
        id: customer.id,
      });
    } catch (error) {
      console.log(error, "abcd");
    }
  };

  const continueDefaultPaying = async (method) => {
    console.log(method, "wts");
    try {
      const defaultPayment = payment.length;
      const { data, error } = await supabase
        .from("product")
        .select("no_assets")
        .eq("price_id", addSubscription.price);
      console.log(data, error, "proo");
      let extend = data[0].no_assets;
      if (defaultPayment) {
        let obj = {};
        obj.customer = customer.id;
        obj.default_payment_method = method;
        obj.addSubscription = addSubscription.price;
        console.log(obj, "dfp");
        let response = await fetch(
          "http://localhost:3001/v1/continueDefaultPaying/",
          {
            method: "post",
            // mode: "no-cors",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(obj),
          }
        );
        response = await response.json();
        console.log(response, rengine_org_id, "hjfj");
        let { subscription, invoice } = response;
        let objt = {};
        objt.apiId = "/api/extend/limit";
        objt.params = { extend: extend, project: rengine_org_id };
        objt.method = "post";
        objt.token = token;
        console.log(objt, subscription, invoice, "grgf");
        if (invoice.status == "paid") {
          let response = await fetch("http://localhost:3001/v2", {
            method: "post",
            // mode: "no-cors",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
            body: JSON.stringify(objt),
          });
          response = await response.json();
          console.log(response, "rer");
        }
        // location.reload();
      } else throw Error("No Payment Method");
    } catch (error) {
      console.log(error, "abcd");
    }
  };

  const cancelSubscription = async (obj) => {
    try {
      console.log(obj, "cd");
      let response = await fetch(
        "http://localhost:3001/v1/cancelSubscription/",
        {
          method: "post",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(obj),
        }
      );
      response = await response.json();
      console.log(response);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    customer &&
    subscription &&
    payment && (
      <Rbox sx={{ minWidth: "80%", p: 1 }}>
        <Stack spacing={2}>
          <Item
            style={{
              display: "flex",
              padding: 5,
              justifyContent: "space-between",
              alignItems: "center",
              backgroundColor: "black",
              color: "white",
              height: "50px",
            }}
          >
            <Typography variant="h6" display="block">
              Billing Details
            </Typography>
            <Button variant="contained" href="/asmt" endIcon={<SendIcon />}>
              Continue to account
            </Button>
          </Item>
          <Divider />
          <Item
            sx={{
              display: "flex",
              gap: 2,
              flexDirection: "row",
              background: "transparent",
              justifyContent: "space-around",
            }}
          >
            <Box sx={{ width: "50%" }}>
              <Typography variant="caption" display="block" gutterBottom>
                Subscription
              </Typography>
              {/* <Divider /> */}
              <Item
                sx={{
                  display: "flex",
                  border: 1,
                  flexDirection: "column",
                }}
              >
                <Box sx={{ height: "600px", overflowY: "scroll" }}>
                  {subscription.map(
                    (e) =>
                      e.status == "active" && (
                        <Box
                          sx={{
                            display: "flex",
                            justifyContent: "space-between",
                            flexDirection: "row",
                            border: 1,
                            margin: 1,
                          }}
                        >
                          {" "}
                          <CardContent>
                            <Typography
                              sx={{ fontSize: 14 }}
                              color="text.secondary"
                              gutterBottom
                            >
                              {e.id}
                            </Typography>
                            <Typography variant="h5" component="div">
                              {e.name}
                            </Typography>
                            <Typography sx={{ mb: 1.5 }} color="text.secondary">
                              {`Paying per ${e.interval} | ${e.status}`}
                            </Typography>
                            <>
                              <Typography variant="body2">
                                {`Current Period: ${e.current_period_start} TO ${e.current_period_end}`}
                                <br />
                                {!e.cancel_at_period_end &&
                                  `Next Invoice:${e.current_period_end}`}
                              </Typography>
                            </>
                          </CardContent>
                          <CardActions>
                            <Button
                              value={{ id: e.id, status: e.status }}
                              onClick={(event) => {
                                let obj = { id: e.id, status: e.status };
                                console.log(e, "ysyua");
                                cancelSubscription(obj);
                                location.reload();
                              }}
                              variant="text"
                            >
                              Cancel
                            </Button>
                          </CardActions>
                        </Box>
                      )
                  )}
                  {subscription.length == 0 && (
                    <>
                      <Typography variant="body2">
                        {`No items to display.`}
                      </Typography>
                    </>
                  )}
                </Box>
              </Item>
            </Box>
            <Box sx={{ width: "50%" }}>
              <Typography variant="caption" display="block" gutterBottom>
                Customer
              </Typography>
              <TextField
                fullWidth
                id="email"
                key="customer_email"
                label="Email"
                size="small"
                defaultValue={customer.point.email}
                onChange={(event) => {
                  console.log(event.target.value, "email");
                  setCustomer({
                    ...customer,
                    point: {
                      ...customer.point,
                      email: event.target.value,
                    },
                    change: true,
                  });
                }}
                variant="standard"
              />
              <Typography variant="caption" display="block" gutterBottom>
                Address
              </Typography>
              <Elements stripe={pk_stripe} options={options}>
                <AddressElement
                  options={{
                    mode: "billing",
                    defaultValues: {
                      address: customer.point.address,
                      name: customer.point.name,
                    },
                  }}
                  onChange={(event) => {
                    console.log(event.value, "ad");
                    setCustomer({
                      ...customer,
                      point: {
                        ...customer.point,
                        address: event.value.address,
                        name: event.value.name,
                      },
                      change: true,
                    });
                  }}
                />
              </Elements>
              <Box
                sx={{
                  color: "white",
                  background: "black",
                  opacity: "1",
                  marginTop: 2,
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <Button
                  sx={{ color: "white" }}
                  fullWidth
                  onClick={updateCustomer}
                >
                  Save
                </Button>
              </Box>
            </Box>
          </Item>
          <Divider />
          <Item sx={{ background: "transparent" }}>
            {" "}
            <Typography variant="caption" display="block" gutterBottom>
              Available Packages
            </Typography>
            <Box
              sx={{
                flexGrow: 1,
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  gap: 5,
                }}
              >
                <Box
                  sx={{
                    border: 2,
                    borderRadius: 5,
                    borderColor: addSubscription?.id == 1 ? "black" : "yellow",
                    overflow: "hidden",
                  }}
                >
                  <Box
                    sx={{
                      border: 2,
                      borderRadius: 5,
                      overflow: "hidden",
                      margin: 0.5,
                    }}
                  >
                    <Card variant="outlined">
                      <CardContent>
                        <Typography
                          sx={{ fontSize: 14 }}
                          color="text.secondary"
                          gutterBottom
                        >
                          Monthly subscription cost £39.99
                        </Typography>
                        <Typography variant="h5" component="div">
                          Starter - Global
                        </Typography>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">
                          -upto 200 Assets
                        </Typography>
                      </CardContent>
                      <CardActions>
                        <Button
                          onClick={() => {
                            setAddSubscription({
                              id: 1,
                              price: "price_1OOjaoSE6gO0eGi5fZNTenK8",
                            });
                          }}
                          size="small"
                        >{`Buy`}</Button>
                      </CardActions>
                    </Card>
                  </Box>
                </Box>
                <Box
                  sx={{
                    border: 2,
                    borderRadius: 5,
                    borderColor: addSubscription?.id == 2 ? "black" : "yellow",
                    overflow: "hidden",
                  }}
                >
                  <Box
                    sx={{
                      border: 2,
                      borderRadius: 5,
                      overflow: "hidden",
                      margin: 0.5,
                    }}
                  >
                    <Card variant="outlined">
                      <CardContent>
                        <Typography
                          sx={{ fontSize: 14 }}
                          color="text.secondary"
                          gutterBottom
                        >
                          Monthly subscription cost £69.99
                        </Typography>
                        <Typography variant="h5" component="div">
                          Medium - Global
                        </Typography>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">
                          -upto 500 Assets
                        </Typography>
                      </CardContent>
                      <CardActions>
                        <Button
                          onClick={() => {
                            setAddSubscription({
                              id: 2,
                              price: "price_1OOjbJSE6gO0eGi5U8JKZzHj",
                            });
                          }}
                          size="small"
                        >{`Buy`}</Button>
                      </CardActions>
                    </Card>
                  </Box>
                </Box>
              </Box>
            </Box>
          </Item>
          <Divider />
          {addSubscription && (
            <>
              <Item sx={{ background: "transparent" }}>
                <Typography variant="caption" display="block" gutterBottom>
                  Continue Paying
                </Typography>
              </Item>
              <Item
                sx={{
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 2,
                  background: "transparent",
                }}
              >
                {rengine_org_id &&
                  payment.map((e, i) => {
                    return (
                      <Box
                        sx={{
                          display: "flex",
                          border: 1,
                          flexDirection: "column",
                          padding: 1,
                          backgroundColor: "white",
                        }}
                      >
                        <Item
                          sx={{
                            display: "flex",
                            justifyContent: "space-between",
                          }}
                        >
                          <Box>
                            <Typography
                              variant="caption"
                              display="inline-block"
                            >
                              {e.card.brand}
                            </Typography>{" "}
                            <Typography
                              variant="caption"
                              display="inline-block"
                            >
                              {e.card.last4}
                            </Typography>
                            <Typography
                              variant="caption"
                              display="block"
                              gutterBottom
                            >
                              {`Expiry: ${e.card.exp_month} / ${e.card.exp_year}`}
                            </Typography>
                          </Box>
                        </Item>
                        <Box
                          sx={{
                            display: "flex",
                            gap: 1,
                          }}
                        >
                          <Button
                            sx={{ color: "white" }}
                            onClick={() => {
                              console.log(e.id, "okkk");
                              setComplete(true);
                              continueDefaultPaying(e.id);
                            }}
                            variant="contained"
                          >
                            Pay Now
                          </Button>
                          <Button
                            value={e.id}
                            id={i}
                            onClick={removeMethod}
                            variant="text"
                          >
                            Remove
                          </Button>
                        </Box>
                      </Box>
                    );
                  })}
              </Item>

              <Item sx={{ background: "transparent" }}>
                <Box
                  sx={{
                    color: "white",
                    background: "black",
                    opacity: "1",
                    marginTop: 2,
                    display: "flex",
                    justifyContent: "center",
                    width: "50%",
                  }}
                >
                  <Button
                    fullWidth
                    value="add"
                    sx={{ color: "white" }}
                    onClick={continuePaying}
                    variant="text"
                  >
                    Add Payment Method
                  </Button>
                </Box>
              </Item>
            </>
          )}
        </Stack>
      </Rbox>
    )
  );
};
