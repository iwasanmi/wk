"use client";
import React from "react";
import {
  useStripe,
  useElements,
  Elements,
  AddressElement,
} from "@stripe/react-stripe-js";
import { Box } from "@mui/material";
import { PaymentElement } from "@stripe/react-stripe-js";
import { pk_stripe, options } from "../subscribe/index";
import { createContext, useContext, useState, useEffect } from "react";
import { getUser, supabase } from "../../../../services";

import { BoardContext } from "../subscribe/layout";
import { Button } from "@mui/base";

const CheckoutForm = (props) => {
  // const stripe = useStripe();
  const { error, message } = props;

  let {
    initaddress,
    initpackage,
    initpay,
    initresult,
    stripeSecret,
    setStripeSecret,
    setIaddress,
    setIpackage,
    setIpay,
    stripeInLay,
    setIresult,
    setInitaddress,
    setInitpackage,
    setInitpay,
  } = useContext(BoardContext);

  // const elements = useElements({ clientSecret: initpay });
  // const stripe = Stripe(
  //   "pk_test_51NrW2uSE6gO0eGi5GG5gMo0fuceLGMgSMZd0xAj1BTvLghlRr2yHywXzGkhzdJ2N6i1eYenhdEyoIEZ5TyRNHN1N00V6FeeHeI"
  // );
  const stripe = useStripe();
  const elements = useElements();
  // // const appearance = { /* appearance */ };
  const handleSubmit = async (event) => {
    event.preventDefault();
    // settodos(data);
    if (!stripe || !elements) {
      // Stripe.js hasn't yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    }

    const result = await stripe.confirmPayment({
      //`Elements` instance that was used to create the Payment Element
      elements,
      confirmParams: {
        return_url: `http://localhost:3000/register/subscribe/?extend=${initpay.extend}&sub_id=${initpay.sub_id}&cus_id=${initpay.id}`,
      },
    });

    if (result.error) {
      // Show error to your customer (for example, payment details incomplete)
      error(true);
      message(result.error.message);
      console.log(result.error.message);
    } else {
      // Your customer will be redirected to your `return_url`. For some payment
      // methods like iDEAL, your customer will be redirected to an intermediate
      // site first to authorize the payment, then redirected to the `return_url`.
    }
  };
  // // const options = { /* options */ };
  // const elements = stripe.elements({ clientSecret: initpay, theme: "stripe" });
  // const paymentElement = elements.create("payment", options);
  // paymentElement.mount("#payment-element");
  return (
    <form>
      <PaymentElement />

      <Box
        sx={{
          color: "white",
          background: "black",
          opacity: "1",
          margin: "auto",
          marginTop: 2,
          display: "flex",
          justifyContent: "center",
          width: "50%",
        }}
      >
        <Button variant="contained" onClick={handleSubmit}>
          Submit
        </Button>
      </Box>
    </form>
  );
};

export const Payment = (props) => {
  const [ocustomer, setOcustomer] = React.useState({});
  const { error, message } = props;
  let {
    initaddress,
    initpackage,
    initpay,
    initresult,
    stripeSecret,
    setStripeSecret,
    setIaddress,
    setIpackage,
    setIpay,
    stripeInLay,
    setIresult,
    setInitaddress,
    setInitpackage,
    setInitpay,
  } = useContext(BoardContext);

  // const elements = useElements({ clientSecret: initpay });
  useEffect(() => {
    const paySubscription = async () => {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();
        if (!user) throw Error("login required");
        const owner = {};
        owner.email = user.email;
        owner.name = initaddress.name;
        const obj = {
          owner: owner,
          initaddress: initaddress.address,
          initpackage: initpackage,
        };
        console.log(obj, "ds");
        let response = await fetch("http://localhost:3001/subscribe", {
          method: "post",
          // mode: "no-cors",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(obj),
        });
        response = await response.json();
        if (response.error == null) {
          let org_id;
          const { data, error } = await supabase
            .from("Organization")
            .insert([{ customer_id: response.customerId }])
            .select();
          console.log("org", data);
          org_id = data[0].id;
          if (!error) {
            const { data, error } = await supabase
              .from("Profile")
              .update({ fullname: owner.name, org_id: org_id })
              .eq("user_id", user.id)
              .select();
            console.log(data, org_id, "uppr");
            if (!error) {
              setInitpay({
                // passing the client secret obtained from the server
                clientSecret: response.clientSecret,
                appearance: { theme: "stripe" },
              });
            } else throw error;
          } else throw error;
        }
      } catch (error) {
        console.log(error, "abcd");
      }
    };

    // if (!initpay) paySubscription();
  }, []);

  // console.log(initpay, "sds");
  // const options = {
  //   // passing the client secret obtained from the server
  //   clientSecret: initpay,
  //   appearance: { theme: "stripe" },
  // };

  return (
    // <div>payment</div>
    initpay && (
      <>
        <Box>
          <Elements stripe={pk_stripe} options={initpay}>
            <CheckoutForm error={error} message={message} />
          </Elements>
        </Box>
      </>
    )
  );
};

export const Address = () => {
  let {
    initaddress,
    setIaddress,
    setIpackage,
    setIpay,
    setIresult,
    stripeSecret,
    setStripeSecret,
    setInitaddress,
    setInitpackage,
    setInitpay,
    setInitresult,
  } = useContext(BoardContext);
  return (
    <Elements stripe={pk_stripe} options={options}>
      <form>
        <h3>Billing</h3>
        <AddressElement
          options={{ mode: "billing" }}
          onChange={(event) => {
            console.log(event.value, event.complete, "target");
            setInitaddress(event.value);
            // if (event.complete)
          }}
        />
        <Box
          sx={{
            color: "white",
            background: "black",
            opacity: "1",
            marginTop: 2,
            display: "flex",
            justifyContent: "center",
            width: "50%",
          }}
        >
          <Button
            variant="contained"
            onClick={() => {
              if (initaddress) {
                setIaddress(false);
                setIpackage(true);
                setIpay(false);
                setIresult(false);
              }
            }}
          >
            SUbmit
          </Button>
        </Box>
      </form>
    </Elements>
  );
};

// export default Address;

export const Result = () => {
  let {
    setIaddress,
    setIpackage,
    setIpay,
    setIresult,
    setInitaddress,
    setInitpackage,
    setInitpay,
    setInitresult,
  } = useContext(BoardContext);
  return <div>Result</div>;
};
