"use client";
import * as React from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { createContext, useContext, useState, useEffect } from "react";
import { pk_stripe, options } from "../subscribe/index";
import { getUser, supabase } from "../../../../services";
import { BoardContext } from "../subscribe/layout";

const Subscription = () => {
  let {
    initaddress,
    initpackage,
    initpay,
    initresult,
    initStripe,
    setInitstripe,
    setIaddress,
    stripeSecret,
    setStripeSecret,
    setIpackage,
    setIpay,
    setIresult,
    stripeInLay,
    setInitaddress,
    setInitpackage,
    setInitpay,
    setInitresult,
    iresult,
    ipay,
    ipackage,
    iaddress,
  } = useContext(BoardContext);
  // useEffect(() => {

  async function handleSubscribe(e) {
    console.log(initaddress, e.target.value, "ap");
    setInitpackage(e.target.value);
    setIaddress(false);
    setIpackage(false);
    setIpay(true);
    setIresult(false);
  }
  // handleSubscribe();
  // }, []);
  return (
    <div className="container mx-auto">
      <Grid sx={{ flexGrow: 1 }} container spacing={2}>
        <Grid item xs={12}>
          <Grid container justifyContent="center" spacing={4}>
            <Grid item key="sme">
              <Box
                sx={{
                  width: 200,
                  height: 200,
                  backgroundColor: "primary.dark",
                  "&:hover": {
                    backgroundColor: "primary.main",
                    opacity: [0.9, 0.8, 0.7],
                  },
                }}
              >
                <button
                  value="price_1NuXz7SE6gO0eGi5UJK97WOF"
                  onClick={handleSubscribe}
                >
                  starter
                </button>
              </Box>
            </Grid>
            <Grid item key="med">
              <Box
                sx={{
                  width: 200,
                  height: 200,
                  backgroundColor: "primary.dark",
                  "&:hover": {
                    backgroundColor: "primary.main",
                    opacity: [0.9, 0.8, 0.7],
                  },
                }}
              >
                <button
                  value="price_1NupMiSE6gO0eGi59n9RYeLu"
                  onClick={handleSubscribe}
                >
                  medium
                </button>
              </Box>
            </Grid>
            <Grid item key="quote">
              <Box
                sx={{
                  width: 200,
                  height: 200,
                  backgroundColor: "primary.dark",
                  "&:hover": {
                    backgroundColor: "primary.main",
                    opacity: [0.9, 0.8, 0.7],
                  },
                }}
              >
                <button value="">Null</button>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};

export default Subscription;
