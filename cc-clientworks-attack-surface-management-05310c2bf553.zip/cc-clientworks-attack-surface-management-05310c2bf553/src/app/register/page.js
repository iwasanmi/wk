"use client";
import { supabase } from "../../../services";
import Link from "next/link";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import { useFormik } from "formik";
import "react-toastify/dist/ReactToastify.css";
import IconButton from "@mui/material/IconButton";
import Input from "@mui/material/Input";
import FilledInput from "@mui/material/FilledInput";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useRouter } from "next/navigation";

const Message = () => {
  return (
    <p className="color-red">Unable to sign up or form incomplete.Try later.</p>
  );
};
const Success = () => {
  return (
    <p className="text-emerald-500">
      Account created.Verify email to complete signup process.
    </p>
  );
};
import { createContext, useContext } from "react";

export const OwnerContext = createContext();

export default function Register() {
  const { push } = useRouter();
  const [showPassword, setShowPassword] = React.useState(false);
  const [owner, setOwner] = React.useState({});
  const [error, setError] = React.useState(false);
  const [success, setSuccess] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const formik = useFormik({
    initialValues: {
      fullName: "",
      email: "",
      password: "",
    },
    onSubmit: async (values) => {
      if (
        values.fullName === "" ||
        values.email === "" ||
        values.password === ""
      ) {
        setError(true);
      } else {
        setOwner(values);
        let response = await fetch("http://localhost:3001/customer/create", {
          method: "post",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            owner: {
              email: values.email,
              name: values.fullName,
              address: { country: "USA" },
            },
          }),
        });
        response = await response.json();
        console.log(response, "cst");
        const { data, error } = await supabase.auth.signUp({
          email: values.email,
          password: values.password,
          options: {
            emailRedirectTo: "http://localhost:3000/register/subscribe",
            data: {
              full_name: values.fullName,
              customer: response.customer.id,
              // age: 27,
            },
          },
        });
        if (error) {
          setError(true);
        } else {
          try {
            setSuccess(true);
            // localStorage.setItem("owner", JSON.stringify(values));
            // push("/register/subscribe");
          } catch (error) {
            console.log(error);
          }
        }
        console.log(data, error, "de");
      }
    },
  });

  return (
    <>
      <OwnerContext.Provider value={{ owner }}>
        <div className="width-100 height-100 abs z-index-b">
          <div
            id="big-image-circuit"
            className="width-50 height-100 abs right-0 circuit"
          ></div>
        </div>
        <section className="width-50 px-6">
          <div className="padding-n navbar">
            <div>
              <a>
                <span>
                  <img
                    style={{
                      height: "94px",
                    }}
                    src="/logo.png"
                  />
                </span>
              </a>
            </div>
            <div>
              <p className="text-sm font-light  padding-t-0">
                Already have an account?{" "}
                <Link
                  href="/login"
                  className="font-medium color-aqua underline dark:text-primary-500"
                >
                  Sign In
                </Link>
              </p>
            </div>
          </div>
        </section>
        <section className="width-50 px-6">
          <div className="flex justify-center">
            <div className="w-full md:mt-0 sm:max-w-md xl:p-0">
              <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
                <h1 className="font-size-36 center-text line-height-n font-bold leading-tight tracking-tight dark:text-white">
                  Create an Account
                </h1>
                <form
                  onSubmit={formik.handleSubmit}
                  className=" space-y-4 md:space-y-6"
                  action="#"
                >
                  <div className="text-left">
                    <TextField
                      id="fullName"
                      label="Full Name"
                      variant="standard"
                      onChange={formik.handleChange}
                      value={formik.values.fullName}
                      fullWidth
                    />
                  </div>
                  <div className="text-left">
                    <TextField
                      id="email"
                      label="Email"
                      type="email"
                      variant="standard"
                      onChange={formik.handleChange}
                      value={formik.values.email}
                      fullWidth
                    />
                  </div>
                  <div className="text-left">
                    <FormControl fullWidth variant="standard">
                      <InputLabel htmlFor="password">Password</InputLabel>
                      <Input
                        onChange={formik.handleChange}
                        id="password"
                        value={formik.values.password}
                        type={showPassword ? "text" : "password"}
                        endAdornment={
                          <InputAdornment position="end">
                            <IconButton
                              aria-label="toggle password visibility"
                              onClick={handleClickShowPassword}
                              onMouseDown={handleMouseDownPassword}
                              edge="end"
                            >
                              {showPassword ? (
                                <VisibilityOff />
                              ) : (
                                <Visibility />
                              )}
                            </IconButton>
                          </InputAdornment>
                        }
                      />
                    </FormControl>
                  </div>

                  <button
                    id="button"
                    type="submit"
                    className="w-full text-white bg-aqua hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                  >
                    Sign Up
                  </button>
                  {error ? <Message /> : ""}
                  {success ? <Success /> : ""}
                </form>
              </div>
            </div>
          </div>
          <div class="text-sm center-text">
            <div class="flex justify-center gap-4 py-2.5"></div>
            <div class="flex flex-col md:flex-row gap-4 justify-center">
              <span class="opacity-80">
                <p>
                  By signing up, you agree with the{" "}
                  <Link
                    href="#"
                    className="font-medium color-aqua underline dark:text-primary-500"
                  >
                    Terms of Use
                  </Link>{" "}
                  &{" "}
                  <Link
                    href="#"
                    className="font-medium color-aqua underline dark:text-primary-500"
                  >
                    Privacy Policy
                  </Link>
                  .
                </p>
              </span>
            </div>
          </div>
        </section>
        <section>
          <footer></footer>
        </section>
        <ToastContainer />
      </OwnerContext.Provider>
    </>
  );
}
