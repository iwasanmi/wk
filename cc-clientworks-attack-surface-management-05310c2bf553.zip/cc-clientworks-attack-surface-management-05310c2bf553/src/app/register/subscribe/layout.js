"use client";
import Subscription from "../components/subscription";
import { createContext, useContext, useState } from "react";
import { OwnerContext } from "../page";
import { enrollMFA, verifyMFA, supabase } from "../../../../services";
import Modal from "@mui/material/Modal";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Link from "@mui/material/Link";
import Button from "@mui/material/Button";
import { Item } from "../../../../components/details";
import { useRouter } from "next/navigation";
import { loadStripe } from "@stripe/stripe-js";

import { Result, Address, Payment } from "../components/address";
import { pk_stripe } from ".";
import { useEffect } from "react";
import { Billings } from "../components/billings";

import "../../globals.css";
export const BoardContext = createContext();
const Message = (props) => {
  return <p className="color-red">{props.message}</p>;
};

export const MFAComponent = (props) => {
  const [error, setError] = useState(false);
  const [verifyCode, setVerifyCode] = useState("");
  const [open, setOpen] = useState(true);
  const handleClose = () => setOpen(true);

  const onSubmitClicked = async () => {
    setError("");
    try {
      await verifyMFA(props.factorId, verifyCode)();
      setOpen(false);
    } catch (error) {
      setError(true);
    }
  };

  useEffect(() => {}, []);

  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box
        item
        xs={4}
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50% ,-50% )",
          width: "400px",
          height: "300px",
          display: "flex",
          gap: 2,
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          border: 1,
          borderColor: "white",
          borderRadius: 5,
        }}
      >
        <Grid item xs={8}>
          <img src={props.qr} />
        </Grid>
        <input
          type="text"
          onChange={(e) => setVerifyCode(e.target.value.trim())}
        />
        <input type="button" value="Submit" onClick={onSubmitClicked} />
        {error ? <Message message="Invalid code .Try again." /> : ""}
      </Box>
    </Modal>
  );
};

export default function Layout({ children }) {
  const { router } = useRouter();
  const [error, setError] = useState(false);
  const [message, setMessage] = useState(
    `Verify email to complete signup process. And login into ASMT account. Or Login and try again.`
  );
  const [iaddress, setIaddress] = useState(false);
  const [iunauthorized, setIunauthorized] = useState(false);
  const [ibilling, setIbilling] = useState(false);
  const [ipackage, setIpackage] = useState(false);
  const [ipay, setIpay] = useState(false);
  const [iresult, setIresult] = useState(false);
  const [initaddress, setInitaddress] = useState();
  const [initpackage, setInitpackage] = useState();
  const [initpay, setInitpay] = useState();
  const [initresult, setInitresult] = useState();
  const [initStripe, setInitstripe] = useState();
  const [stripeSecret, setStripeSecret] = useState(() =>
    loadStripe(
      "pk_test_51NrW2uSE6gO0eGi5GG5gMo0fuceLGMgSMZd0xAj1BTvLghlRr2yHywXzGkhzdJ2N6i1eYenhdEyoIEZ5TyRNHN1N00V6FeeHeI"
    )
  );
  const [modal, setModal] = useState(false);
  const [factorId, setFactorId] = useState();
  const [qr, setQR] = useState(); // holds the QR code image SVG

  useEffect(() => {
    async function modalCode() {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();
        let customer = user.user_metadata.customer;
        if (customer) {
          let url = `http://localhost:3001/v1/billing/?customer=${customer}`;
          let response = await fetch(url);
          let { subscriptions, customerDetails, paymentMethods } =
            await response.json();
          console.log(
            subscriptions,
            customerDetails,
            paymentMethods,
            user,
            "id"
          );

          setIbilling({ subscriptions, customerDetails, paymentMethods });
        }

        ///////////////////////////////////////////
        const { data, error } =
          await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
        const { currentLevel, nextLevel, currentAuthenticationMethods } = data;

        console.log(
          currentLevel,
          nextLevel,
          currentAuthenticationMethods,
          "jk"
        );
        if (nextLevel === "aal1") {
          const { data, error } = await supabase.auth.mfa.enroll({
            factorType: "totp",
          });
          if (error) throw error;
          const {
            id,
            type,
            totp: { qr_code, secret, uri },
          } = data;
          setFactorId(id);
          // Supabase Auth returns an SVG QR code which you can convert into a data
          // URL that you can place in an <img> tag.
          setQR(qr_code);
          setModal(true);
          {
            const { data, error } = await supabase
              .from("Organization")
              .insert([
                {
                  customer_id: customer,
                },
              ])
              .select();
            console.log(data, error, "crorg");
            const org_id = data[0].id;
            {
              const { data, error } = await supabase.from("Profile").insert([
                {
                  user_id: user.id,
                  org_id: org_id,
                },
              ]);
              console.log(data, error, "prins");
            }
          }
        }
      } catch (error) {
        console.log(error, "lay");
        setError(true);
      }
    }
    modalCode();
    ///////////////////////////////////////////
    // const { data, error } = await supabase.from("Profile").select();
    // const profile = data[0];
    // console.log(profile, error, "reg");
    // if (!error) {
    // if (profile?.org_id) {
    // const { data, error } = await supabase
    //   .from("Organization")
    //   .select("customer_id")
    //   .eq("id", profile.org_id);
    // const customer = data[0];
    // if (subscriptions.data.length) {
    // }
    //  else setIaddress(true);
    // } else {
    // if (!profile?.factor_id) {
    //   const factor = data;
    //   if (!error) {
    //     const { data, error } = await supabase
    //       .from("Profile")
    //       .insert([
    //         {
    //           user_id: user.id,
    //           factor_id: factor.id,
    //         },
    //       ])
    //       .select();
    //     else {
    //     }
    //   } else throw error;
    // } else {
    //   setIaddress(true);
    // }
    // }
    // } else throw error;
    ///////////////////////////////////

    async function setSubscribe() {
      try {
        const { data, error } = await supabase.from("Profile").select("org_id");
        console.log(data, error, "setsbs");
      } catch (error) {}
    }
  }, []);

  {
    //         const { user, data, error } = await enrollMFA();
    // console.log(user, "reg");
    // if (!error) {
    //   const factor = data;
    //   if (user) {
    //     if (error) {
    //       console.log(error, "mfe");
    //       throw error;
    //     } else {
    //       const { data, error } = await supabase
    //         .from("Profile")
    //         .select("id")
    //         .eq("user_id", user.id);
    //       const profile = data[0];
    //       console.log(factor, profile, error, "reg");
    //       if (!error) {
    //         if (profile) {
    // const { data, error } = await supabase
    //   .from("Profile")
    //   .upsert([
    //     {
    //       id: profile.id,
    //       user_id: user.id,
    //       factor_id: factor.id,
    //     },
    //   ])
    //   .select();
    //   return;
    // } else {
    //   const { data, error } = await supabase
    //     .from("Profile")
    //     .insert([
    //       {
    //         user_id: user.id,
    //         factor_id: factor.id,
    //       },
    //     ])
    //     .select();
    // }
    // if (error) throw error;
    // else {
    //   console.log(data[0], "fct upd");
    //   setFactorId(factor.id);
    // Supabase Auth returns an SVG QR code which you can convert into a data
    // URL that you can place in an <img> tag.
    //   setQR(factor.totp.qr_code);
    //   setModal(true);
    // }
    //         }
    //       }
    //     }
    //   } else throw error;
    // } catch (error) {
    //   console.log(error, "lay");
    //   setError(true);
    // }
    // }
  }

  return (
    <BoardContext.Provider
      value={{
        initaddress,
        initpackage,
        initpay,
        initresult,
        stripeSecret,
        initStripe,
        setInitstripe,
        setStripeSecret,
        setIaddress,
        setIpackage,
        setIpay,
        setIbilling,
        setIresult,
        setInitaddress,
        setInitpackage,
        setInitpay,
        setInitresult,
        iresult,
        ipay,
        ipackage,
        iaddress,
      }}
    >
      <div className="billing">
        {iresult && <Result />}
        {ipackage && <Subscription />}
        {iaddress && <Address />}
        {ibilling && <Billings {...ibilling} />}
        {ipay && (
          <>
            <Box fullWidth sx={{ padding: 1, width: "50%" }}>
              <Payment error={setError} message={setMessage} />
            </Box>
          </>
        )}
        {modal && <MFAComponent qr={qr} factorId={factorId} />}
        {error && <Message message={message} />}
      </div>
    </BoardContext.Provider>
  );
}
