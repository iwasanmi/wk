import { loadStripe } from "@stripe/stripe-js";
export const sk_stripe = loadStripe(
  "sk_test_51NrW2uSE6gO0eGi59a2sCVTCfjKXWSUZaY0dYwzPfqhW6zxh51vJXFgYTaVMMt6mROixs8G0qKCMAJmiOUbKXKmb00FSoK9Gly"
);

export const pk_stripe = loadStripe(
  "pk_test_51NrW2uSE6gO0eGi5GG5gMo0fuceLGMgSMZd0xAj1BTvLghlRr2yHywXzGkhzdJ2N6i1eYenhdEyoIEZ5TyRNHN1N00V6FeeHeI"
);
// console.log(pk_stripe, "dsds");
const appearance = {
  theme: "stripe",
};
export const options = { appearance };

//////////////////////////////////////////////////////////////////

// const b_elements = sk_stripe.elements({ clientSecret, appearance });

//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////
// const f_elements = pk_stripe.elements({ clientSecret, appearance });

////////////////////////////////////////////////////////////////

// const elements = stripe.elements({ clientSecret });
// const addressElement = elements.create("address", options);
// const paymentElement = elements.create("payment");
// addressElement.mount("#address-element");
// paymentElement.mount("#payment-element");
